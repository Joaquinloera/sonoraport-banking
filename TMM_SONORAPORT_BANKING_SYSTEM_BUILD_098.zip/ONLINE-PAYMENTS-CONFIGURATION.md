# J.P. Morgan Online Payments configuration

This package removes the verification-account requirement when `JPMORGAN_PRODUCT_MODE=online_payments`.

Required Netlify values for the product gate:

- `JPMORGAN_PRODUCT_MODE=online_payments`
- `JPMORGAN_API_BASE_URL` — the base URL shown for the project environment
- `JPMORGAN_CREATE_PAYMENT_PATH` — the Online Payments payment-request path from the project API reference
- `JPMORGAN_MERCHANT_ID` — the merchant ID assigned/shown for the project
- `JPMORGAN_SCOPE=jpm:payments:sandbox` for the sandbox project shown in the Quick Start
- `JPMORGAN_MINOR_VERSION` when required by the selected API version

The Account Access button now checks OAuth plus these Online Payments product settings. It does not create a payment. Callback and production cutover gates remain locked until their real configuration passes.
