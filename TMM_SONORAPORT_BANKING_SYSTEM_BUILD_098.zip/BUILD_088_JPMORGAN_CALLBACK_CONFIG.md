# BUILD 088 — JPMorgan Callback Configuration

Patched from BUILD 087.

Configured deployment variables:
- `JPMORGAN_API_BASE_URL=https://api.payments.jpmorgan.com/embedded/v1`
- `ENABLE_JPMORGAN_CALLBACKS=true`

Both `.env.example` and `.env.production.example` contain these values.
