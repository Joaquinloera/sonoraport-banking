# Step 11 — Customer Account Controls and Ledger Integrity

Run `supabase/SONORAPORT-JPMORGAN-STEP11-LEDGER-INTEGRITY.sql` before enabling this step.

The payment function now atomically verifies account ownership, requires a fresh provider-balance snapshot, subtracts existing holds, blocks overdrafts, creates a unique reservation, and writes a balanced double-entry journal before contacting the provider. If provider submission fails, the reservation is released.

Required environment variable:

`JPMORGAN_BALANCE_MAX_AGE_SECONDS=300`

A trusted balance-refresh process must upsert `provider_balance_snapshots` after retrieving balances directly from the authorized provider API. Browser code cannot write snapshots, reservations, or ledger entries.
