# JoshGPT repair

- Detects placeholder OPENAI_API_KEY values.
- Uses the Responses API with `store: false`.
- Defaults to `gpt-5-mini` unless OPENAI_MODEL is configured.
- Sends a bounded 10-message conversation history.
- Handles mobile visual viewport and keyboard resizing.
- Preserves loading, duplicate-send prevention, fallback guidance, and clear errors.
