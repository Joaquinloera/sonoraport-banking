# BUILD 073 — Card Contrast

Parent: BUILD 072

- Lightened Black/Business card surface while retaining black/gold identity.
- Increased masked-number contrast.
- Increased PERSONAL/BUSINESS and network-label contrast.
- Preserved Gold card visual treatment with explicit dark foreground.
- No banking, issuance, payment, ledger, or authentication logic changed.
