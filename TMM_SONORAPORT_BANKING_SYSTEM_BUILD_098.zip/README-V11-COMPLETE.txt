SONORAPORT AI BANKING — V11 COMPLETE PORTAL

This combined release includes the working public website plus the consolidated Client Portal updates.

Portal features included:
- authenticated profile display
- real application tracking and status references
- real overview counts
- accounts and balances read from Supabase
- transaction history read from Supabase
- transfer request workflow (requires two active accounts)
- card request workflow
- quick product application workflow
- independent section loading and visible error handling
- manual Refresh Data button
- improved mobile tables and tabs

IMPORTANT:
The portal does not invent balances, account numbers, approvals, card numbers, or transactions. Those records must be created through authorized backend/admin processes.

Optional database repair:
Run supabase/SONORAPORT-V11-COMPLETE-PORTAL.sql once if this project has not already received the application table and RLS repairs.
