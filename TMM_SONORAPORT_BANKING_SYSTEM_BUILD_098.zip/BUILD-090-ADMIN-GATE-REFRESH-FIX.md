# BUILD 090 — Admin Gate Refresh Fix

- Fixes Admin Portal `Refresh configuration` resetting verification cards to `Not tested` / `Locked`.
- Refresh now re-runs provider auth, account access, payment readiness, callback verification, production cutover, and operations health checks.
- Status cards are rebuilt from current server responses instead of the default unverified object returned by the base status endpoint.
- No payment is created by the provider verification checks.
