SONORAPORT V17 BANKING OPERATIONS

DATABASE:
The V14 Transactions SQL patch must be run first. If Supabase already showed Success, do not run it again.

DEPLOYMENT:
Upload this entire ZIP to the existing Netlify site as a new manual deploy.
Do not extract individual files for Netlify.

VERIFY:
1. Open client-portal.html and sign in as the customer.
2. Tap Transactions.
3. Confirm the gold label says V17 BANKING OPERATIONS.
4. The Deposit or Withdraw form must appear above Transaction History on a phone.
5. Post a $100 sandbox deposit to Savings Account.
