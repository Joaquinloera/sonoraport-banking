import {getBearer,getSupabaseUser,json,methodNotAllowed,requestId,serverError,unauthorized} from './lib/shared.mjs';
import {requireAdminAuthority} from './lib/admin-authority.mjs';
import {dbRest} from './lib/card-store.mjs';
export async function handler(event){const cid=requestId(event);if(event.httpMethod!=='GET')return methodNotAllowed(['GET']);try{const user=await getSupabaseUser(getBearer(event));if(!user)return unauthorized('Administrator authentication required.','AUTH_REQUIRED',cid);await requireAdminAuthority(user);const [profiles,apps,accounts,debit,credit,transfers,transactions,messages,audit]=await Promise.all([
 dbRest('profiles?select=id,email,full_name,role,created_at&order=created_at.desc'),
 dbRest('bank_account_applications?select=id,user_id,account_name,account_type,legal_name,status,decision_note,created_at,updated_at,reviewed_at&order=created_at.desc'),
 dbRest('bank_accounts?select=id,user_id,account_name,account_type,currency,current_balance,available_balance,status,created_at&order=created_at.desc'),
 dbRest('debit_cards?select=id,user_id,linked_account_id,last_four,network,status,is_locked,issuer_provider,issuer_state,lifecycle_status,replacement_requested_at,closure_requested_at,created_at&order=created_at.desc'),
 dbRest('credit_cards?select=id,user_id,linked_account_id,last_four,network,status,is_locked,product_name,product_code,issuer_provider,issuer_state,lifecycle_status,replacement_requested_at,closure_requested_at,created_at&order=created_at.desc'),
 dbRest('transfer_requests?select=id,user_id,from_account_id,to_account_id,external_recipient_name,transfer_type,amount,currency,status,created_at&order=created_at.desc'),
 dbRest('transactions?select=id,user_id,account_id,bank_account_id,transaction_type,description,amount,direction,status,reference,created_at&order=created_at.desc'),
 dbRest('secure_messages?select=id,sender_id,recipient_id,subject,message,is_read,created_at&order=created_at.desc'),
 dbRest('audit_events?select=id,user_id,event_type,entity_type,entity_id,details,created_at&order=created_at.desc&limit=200')]);
 const cards=[...(debit||[]).map(x=>({...x,product:x.network?`${x.network} Debit`:'Debit Card'})),...(credit||[]).map(x=>({...x,product:x.product_name||x.product_code||`${x.network||''} Credit`.trim()}))];
 return json(200,{profiles:profiles||[],applications:apps||[],accounts:accounts||[],cards,transfers:transfers||[],transactions:transactions||[],messages:messages||[],audit:audit||[],correlationId:cid});}catch(e){return serverError(e,cid)}}
