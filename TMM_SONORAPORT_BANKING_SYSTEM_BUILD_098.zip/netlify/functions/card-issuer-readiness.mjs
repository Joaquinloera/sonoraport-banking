import { getBearer, getSupabaseUser, requestId, unauthorized, serverError } from './lib/shared.mjs';
import { configuredIssuers, authenticateIssuer, issuerConfigurationState } from './lib/card-issuer-router.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';
const json=(statusCode,body)=>({statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(body)});
export async function handler(event){
  const correlationId=requestId(event);
  try{
    const user=await getSupabaseUser(getBearer(event));
    if(!user)return unauthorized('Authentication required.','AUTH_REQUIRED',correlationId);
    await requireAdminAuthority(user);
    const issuers=configuredIssuers();
    const primary=issuers[0];
    if(!primary)return json(200,{configured:false,authenticated:false,authStatus:'not_configured',products:[],correlationId});
    const state=issuerConfigurationState(primary);
    const auth=state.configured?await authenticateIssuer(primary):{ok:false,reason:'not_configured'};
    return json(200,{configured:state.configured,authenticated:auth.ok,authStatus:auth.ok?'pass':auth.reason,issuer:primary.name,createPath:primary.createPath,products:primary.products,missing:state.missing,correlationId});
  }catch(e){return serverError(e,correlationId);}
}
