import { badRequest, cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const ACTIONS = new Set(['approve','suspend','reject','close']);
function db() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Beneficiary database configuration is missing.'), { status: 503, code: 'BENEFICIARY_DATABASE_MISSING' });
  return { base, headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Accept: 'application/json' } };
}
function allowed(email) {
  const admins = new Set(String(process.env.JPMORGAN_BENEFICIARY_ADMIN_EMAILS || '').split(',').map(v => v.trim().toLowerCase()).filter(Boolean));
  return admins.has(String(email || '').toLowerCase());
}
async function getOne(id) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: '*', id: `eq.${id}`, limit: '1' });
  const r = await fetch(`${base}/rest/v1/payment_beneficiaries?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to load beneficiary.'), { status: r.status, code: 'BENEFICIARY_LOOKUP_FAILED' });
  return rows?.[0] || null;
}
export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','PATCH'].includes(event.httpMethod)) return methodNotAllowed(['GET','PATCH']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user || !allowed(user.email)) return unauthorized('Authorized beneficiary administrator access is required.', 'BENEFICIARY_ADMIN_REQUIRED', correlationId);
    const { base, headers } = db();
    if (event.httpMethod === 'GET') {
      const status = cleanText(event.queryStringParameters?.status || 'pending_review', 30);
      const q = new URLSearchParams({ select: 'id,profile_id,display_name,destination_type,country_code,currency,status,risk_score,risk_reasons,approved_at,activates_at,created_at,updated_at', status: `eq.${status}`, order: 'created_at.asc', limit: '200' });
      const r = await fetch(`${base}/rest/v1/payment_beneficiaries?${q}`, { headers });
      const rows = await r.json().catch(() => []);
      if (!r.ok) throw Object.assign(new Error('Unable to load beneficiary queue.'), { status: r.status, code: 'BENEFICIARY_ADMIN_QUERY_FAILED' });
      return json(200, { beneficiaries: rows, correlationId }, { 'cache-control': 'no-store' });
    }
    const body = await readJson(event);
    const beneficiaryId = cleanText(body?.beneficiaryId, 80);
    const action = cleanText(body?.action, 20).toLowerCase();
    const note = cleanText(body?.note, 1000);
    if (!/^[0-9a-f-]{36}$/i.test(beneficiaryId) || !ACTIONS.has(action)) return badRequest('Valid beneficiary ID and action are required.', 'BENEFICIARY_ADMIN_FIELDS_INVALID', correlationId);
    const current = await getOne(beneficiaryId);
    if (!current) return json(404, { error: 'Beneficiary not found.', code: 'BENEFICIARY_NOT_FOUND', correlationId });
    const coolingHours = Math.max(0, Number(process.env.JPMORGAN_BENEFICIARY_COOLING_OFF_HOURS) || 24);
    const now = new Date();
    let patch;
    if (action === 'approve') {
      const activatesAt = new Date(now.getTime() + coolingHours * 3600000).toISOString();
      patch = { status: coolingHours > 0 ? 'cooling_off' : 'active', reviewed_by: user.id, approved_at: now.toISOString(), activates_at: activatesAt };
    } else if (action === 'suspend') patch = { status: 'suspended', reviewed_by: user.id, suspended_at: now.toISOString() };
    else if (action === 'reject') patch = { status: 'rejected', reviewed_by: user.id };
    else patch = { status: 'closed', reviewed_by: user.id };
    const r = await fetch(`${base}/rest/v1/payment_beneficiaries?id=eq.${encodeURIComponent(beneficiaryId)}`, { method: 'PATCH', headers: { ...headers, Prefer: 'return=representation' }, body: JSON.stringify(patch) });
    const rows = await r.json().catch(() => null);
    if (!r.ok) throw Object.assign(new Error(rows?.message || 'Unable to update beneficiary.'), { status: r.status, code: 'BENEFICIARY_ADMIN_UPDATE_FAILED' });
    const updated = rows?.[0] || rows;
    await fetch(`${base}/rest/v1/payment_beneficiary_events`, { method: 'POST', headers, body: JSON.stringify({ beneficiary_id: beneficiaryId, profile_id: current.profile_id, actor_user_id: user.id, event_type: `beneficiary.${action}`, old_status: current.status, new_status: patch.status, details: { note, coolingHours }, correlation_id: correlationId }) });
    await appendAuditEvent({ correlationId, actorUserId: user.id, actorEmail: user.email, action: `beneficiary.${action}`, outcome: patch.status, resourceId: beneficiaryId, details: { previousStatus: current.status, note, coolingHours } });
    return json(200, { beneficiary: updated, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) { return serverError(error, correlationId); }
}
