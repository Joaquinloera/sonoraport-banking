import { getBearer, getLinkedProviderAccount, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { configuredPath, jpmorganRequest } from './lib/jpmorgan.mjs';

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in to view balances.', 'AUTH_REQUIRED', correlationId);

    const localAccountId = event.queryStringParameters?.linkedAccountId || '';
    const linked = await getLinkedProviderAccount(token, 'jpmorgan', localAccountId, user.id);
    if (!linked) return unauthorized('No active J.P. Morgan account is linked to this profile.', 'PROVIDER_ACCOUNT_NOT_LINKED', correlationId);

    const path = configuredPath('JPMORGAN_BALANCES_PATH', '/accounts/{accountId}/balances')
      .replace('{accountId}', encodeURIComponent(linked.provider_account_id));
    const data = await jpmorganRequest(path, { correlationId });
    return ok({
      provider: 'J.P. Morgan',
      linkedAccount: { id: linked.id, name: linked.display_name, type: linked.account_type, last4: linked.last4 },
      balances: data,
      correlationId,
    });
  } catch (error) { return serverError(error, correlationId); }
}
