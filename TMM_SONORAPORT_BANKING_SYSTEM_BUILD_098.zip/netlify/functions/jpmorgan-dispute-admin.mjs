import { cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const allowedTransitions = {
  submitted: new Set(['under_review','information_required','rejected']),
  under_review: new Set(['information_required','resolved_customer','resolved_merchant','rejected']),
  information_required: new Set(['under_review','resolved_customer','resolved_merchant','rejected']),
  resolved_customer: new Set(['closed']),
  resolved_merchant: new Set(['closed']),
  rejected: new Set(['closed']),
  closed: new Set(),
};

function isAdmin(email) {
  const allowed = String(process.env.JPMORGAN_DISPUTE_ADMIN_EMAILS || process.env.JPMORGAN_AUDIT_ADMIN_EMAILS || '')
    .split(',').map((value) => value.trim().toLowerCase()).filter(Boolean);
  return allowed.includes(String(email || '').toLowerCase());
}

function db() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Dispute administration database configuration is missing.'), { status: 503, code: 'DISPUTE_ADMIN_DATABASE_MISSING' });
  return { base, key, headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Accept: 'application/json' } };
}

async function listCases(status = '') {
  const { base, headers } = db();
  const params = new URLSearchParams({
    select: 'id,profile_id,payment_id,reason_code,customer_statement,status,provider_case_id,resolution_notes,resolution_code,assigned_to,information_due_at,last_reviewed_at,created_at,updated_at,resolved_at',
    order: 'created_at.desc',
    limit: '200',
  });
  if (status) params.set('status', `eq.${status}`);
  const response = await fetch(`${base}/rest/v1/payment_disputes?${params}`, { headers });
  const rows = await response.json().catch(() => []);
  if (!response.ok) throw Object.assign(new Error('Unable to load dispute cases.'), { status: response.status, code: 'DISPUTE_ADMIN_QUERY_FAILED' });
  return rows;
}

async function getCase(id) {
  const { base, headers } = db();
  const params = new URLSearchParams({ select: '*', id: `eq.${id}`, limit: '1' });
  const response = await fetch(`${base}/rest/v1/payment_disputes?${params}`, { headers });
  const rows = await response.json().catch(() => []);
  if (!response.ok) throw Object.assign(new Error('Unable to load dispute case.'), { status: response.status, code: 'DISPUTE_ADMIN_LOOKUP_FAILED' });
  return rows?.[0] || null;
}

async function updateCase(id, patch) {
  const { base, headers } = db();
  const response = await fetch(`${base}/rest/v1/payment_disputes?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { ...headers, Prefer: 'return=representation' },
    body: JSON.stringify(patch),
  });
  const rows = await response.json().catch(() => null);
  if (!response.ok) throw Object.assign(new Error(rows?.message || 'Unable to update dispute case.'), { status: response.status, code: 'DISPUTE_ADMIN_UPDATE_FAILED' });
  return rows?.[0] || rows;
}

async function addEvent(record) {
  const { base, headers } = db();
  const response = await fetch(`${base}/rest/v1/payment_dispute_events`, {
    method: 'POST', headers: { ...headers, Prefer: 'return=representation' }, body: JSON.stringify(record),
  });
  if (!response.ok) throw Object.assign(new Error('Unable to record dispute event.'), { status: response.status, code: 'DISPUTE_EVENT_WRITE_FAILED' });
}

function validUuid(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','PATCH'].includes(event.httpMethod)) return methodNotAllowed(['GET','PATCH']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to administer disputes.', 'AUTH_REQUIRED', correlationId);
    if (!isAdmin(user.email)) return json(403, { error: 'Dispute administrator access is required.', code: 'DISPUTE_ADMIN_REQUIRED', correlationId });

    if (event.httpMethod === 'GET') {
      const status = cleanText(event.queryStringParameters?.status, 40);
      if (status && !Object.hasOwn(allowedTransitions, status)) return json(400, { error: 'Invalid dispute status.', code: 'INVALID_DISPUTE_STATUS', correlationId });
      const cases = await listCases(status);
      return json(200, { cases, count: cases.length, correlationId }, { 'cache-control': 'no-store' });
    }

    const body = await readJson(event);
    const disputeId = cleanText(body?.disputeId, 80);
    const newStatus = cleanText(body?.status, 40);
    const note = cleanText(body?.note, 3000);
    const providerCaseId = cleanText(body?.providerCaseId, 160);
    const resolutionCode = cleanText(body?.resolutionCode, 100);
    const informationDueAt = cleanText(body?.informationDueAt, 60);

    if (!validUuid(disputeId)) return json(400, { error: 'A valid dispute ID is required.', code: 'INVALID_DISPUTE_ID', correlationId });
    const existing = await getCase(disputeId);
    if (!existing) return json(404, { error: 'Dispute case not found.', code: 'DISPUTE_NOT_FOUND', correlationId });
    if (!Object.hasOwn(allowedTransitions, newStatus)) return json(400, { error: 'Invalid target status.', code: 'INVALID_TARGET_STATUS', correlationId });
    if (!allowedTransitions[existing.status]?.has(newStatus)) return json(409, { error: `Cannot move a dispute from ${existing.status} to ${newStatus}.`, code: 'INVALID_STATUS_TRANSITION', correlationId });
    if (['resolved_customer','resolved_merchant','rejected'].includes(newStatus) && note.length < 20) return json(400, { error: 'Resolution notes must contain at least 20 characters.', code: 'RESOLUTION_NOTES_REQUIRED', correlationId });

    const now = new Date().toISOString();
    const patch = {
      status: newStatus,
      updated_at: now,
      last_reviewed_at: now,
      assigned_to: user.id,
      ...(note ? { resolution_notes: note } : {}),
      ...(providerCaseId ? { provider_case_id: providerCaseId } : {}),
      ...(resolutionCode ? { resolution_code: resolutionCode } : {}),
      ...(newStatus === 'information_required' && informationDueAt ? { information_due_at: informationDueAt } : {}),
      ...(['resolved_customer','resolved_merchant','rejected'].includes(newStatus) ? { resolved_at: now } : {}),
      ...(newStatus === 'closed' ? { closed_by: user.id } : {}),
    };

    const updated = await updateCase(disputeId, patch);
    const eventType = newStatus === 'information_required' ? 'information_requested' : newStatus;
    await addEvent({ dispute_id: disputeId, actor_user_id: user.id, event_type: eventType, note: note || null, provider_case_id: providerCaseId || null, previous_status: existing.status, new_status: newStatus, correlation_id: correlationId });
    await appendAuditEvent({ correlationId, actorUserId: user.id, action: 'payment.dispute_admin_updated', outcome: newStatus, resourceId: disputeId, details: { previousStatus: existing.status, newStatus, providerCaseId: providerCaseId || null, resolutionCode: resolutionCode || null } });
    return json(200, { dispute: updated, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
