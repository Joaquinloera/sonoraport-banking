import { cleanText, getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, supabaseUserSelect, unauthorized } from './lib/shared.mjs';

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in to view transfer status.', 'AUTH_REQUIRED', correlationId);

    const paymentId = cleanText(event.queryStringParameters?.paymentId, 80);
    const query = [
      'select=payment_id,provider_account_link_id,amount,currency,status,provider_status,provider_payment_id,correlation_id,created_at,updated_at,settled_at,released_at,failure_reason',
      `profile_id=eq.${encodeURIComponent(user.id)}`,
      paymentId ? `payment_id=eq.${encodeURIComponent(paymentId)}` : 'order=created_at.desc',
      paymentId ? 'limit=1' : 'limit=100',
    ].join('&');

    const rows = await supabaseUserSelect(token, 'customer_transaction_history', query);
    const transfers = (Array.isArray(rows) ? rows : []).map((row) => ({
      paymentId: row.payment_id,
      linkedAccountId: row.provider_account_link_id,
      amount: row.amount,
      currency: row.currency,
      state: row.status,
      providerState: row.provider_status || null,
      providerReference: row.provider_payment_id || null,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      settledAt: row.settled_at || null,
      releasedAt: row.released_at || null,
      failureReason: row.failure_reason || null,
    }));

    return ok({ transfers, count: transfers.length, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
