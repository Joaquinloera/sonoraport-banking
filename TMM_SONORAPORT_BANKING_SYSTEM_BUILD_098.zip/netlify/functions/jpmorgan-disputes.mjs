import { badRequest, cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const allowedReasons = new Set(['unauthorized','duplicate','incorrect_amount','service_not_received','refund_not_received','other']);

function dbConfig() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Dispute database configuration is missing.'), { status: 503, code: 'DISPUTE_DATABASE_MISSING' });
  return { base, key };
}

async function paymentForUser(paymentId, profileId) {
  const { base, key } = dbConfig();
  const params = new URLSearchParams({ select: 'id,status,amount,currency,created_at', id: `eq.${paymentId}`, profile_id: `eq.${profileId}`, limit: '1' });
  const response = await fetch(`${base}/rest/v1/payment_reservations?${params}`, { headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' } });
  const rows = await response.json().catch(() => []);
  if (!response.ok) throw Object.assign(new Error('Unable to verify transaction ownership.'), { status: response.status, code: 'DISPUTE_PAYMENT_LOOKUP_FAILED' });
  return rows?.[0] || null;
}

async function listDisputes(profileId) {
  const { base, key } = dbConfig();
  const params = new URLSearchParams({ select: 'id,payment_id,reason_code,customer_statement,status,provider_case_id,resolution_notes,created_at,updated_at,resolved_at', profile_id: `eq.${profileId}`, order: 'created_at.desc', limit: '100' });
  const response = await fetch(`${base}/rest/v1/payment_disputes?${params}`, { headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' } });
  const rows = await response.json().catch(() => []);
  if (!response.ok) throw Object.assign(new Error('Unable to load disputes.'), { status: response.status, code: 'DISPUTE_QUERY_FAILED' });
  return rows;
}

async function createDispute({ profileId, paymentId, reasonCode, statement, correlationId }) {
  const { base, key } = dbConfig();
  const response = await fetch(`${base}/rest/v1/payment_disputes`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Prefer: 'return=representation' },
    body: JSON.stringify({ profile_id: profileId, payment_id: paymentId, reason_code: reasonCode, customer_statement: statement, correlation_id: correlationId }),
  });
  const rows = await response.json().catch(() => null);
  if (response.status === 409) throw Object.assign(new Error('A dispute already exists for this transaction.'), { status: 409, code: 'DISPUTE_ALREADY_EXISTS' });
  if (!response.ok) throw Object.assign(new Error(rows?.message || 'Unable to create dispute.'), { status: response.status, code: 'DISPUTE_CREATE_FAILED' });
  return rows?.[0] || rows;
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','POST'].includes(event.httpMethod)) return methodNotAllowed(['GET','POST']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to manage disputes.', 'AUTH_REQUIRED', correlationId);
    if (event.httpMethod === 'GET') {
      const disputes = await listDisputes(user.id);
      return json(200, { disputes, count: disputes.length, correlationId }, { 'cache-control': 'no-store' });
    }
    const body = await readJson(event);
    const paymentId = cleanText(body?.paymentId, 80);
    const reasonCode = cleanText(body?.reasonCode, 60).toLowerCase();
    const statement = cleanText(body?.statement, 2000);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(paymentId)) return badRequest('A valid payment ID is required.', 'INVALID_PAYMENT_ID', correlationId);
    if (!allowedReasons.has(reasonCode)) return badRequest('Select a valid dispute reason.', 'INVALID_DISPUTE_REASON', correlationId);
    if (statement.length < 20) return badRequest('Provide at least 20 characters describing the dispute.', 'DISPUTE_STATEMENT_TOO_SHORT', correlationId);
    const payment = await paymentForUser(paymentId, user.id);
    if (!payment) return json(404, { error: 'Transaction not found.', code: 'PAYMENT_NOT_FOUND', correlationId });
    if (!['settled','failed'].includes(payment.status)) return json(409, { error: 'Only final transactions can be disputed.', code: 'PAYMENT_NOT_FINAL', correlationId });
    const dispute = await createDispute({ profileId: user.id, paymentId, reasonCode, statement, correlationId });
    await appendAuditEvent({ correlationId, actorUserId: user.id, action: 'payment.dispute_submitted', outcome: 'accepted', resourceId: paymentId, details: { reasonCode } });
    return json(201, { dispute, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
