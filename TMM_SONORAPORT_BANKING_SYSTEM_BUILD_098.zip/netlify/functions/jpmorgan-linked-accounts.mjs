import { getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, supabaseUserSelect, unauthorized } from './lib/shared.mjs';

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in to view linked accounts.', 'AUTH_REQUIRED', correlationId);

    const rows = await supabaseUserSelect(token, 'provider_accounts', [
      'select=id,provider,account_type,display_name,last4,status,created_at',
      'provider=eq.jpmorgan',
      `profile_id=eq.${encodeURIComponent(user.id)}`,
      'status=eq.active',
      'order=created_at.asc',
    ].join('&'));

    return ok({
      linkedAccounts: rows.map((row) => ({
        id: row.id,
        provider: 'J.P. Morgan',
        name: row.display_name || 'Linked account',
        type: row.account_type || '',
        last4: row.last4 || '',
        status: row.status,
      })),
      correlationId,
    });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
