import { ok, getBearer, getSupabaseUser, requestId, unauthorized, serverError } from './lib/shared.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';
import { jpmorganEnabled, getJpmorganAccessToken, jpmorganRequest, configuredPath, envValue, normalizedApiOrigin } from './lib/jpmorgan.mjs';

const isTrue = (value) => String(value || '').toLowerCase() === 'true';
const has = (name) => Boolean(envValue(name));

export async function handler(event = {}) {
  const enabled = jpmorganEnabled();
  const productMode = String(envValue('JPMORGAN_PRODUCT_MODE') || 'online_payments').trim().toLowerCase();
  const onlinePaymentsMode = ['online_payments', 'online-payments', 'onlinepayments', 'cards'].includes(productMode);
  const paths = {
    onboardClient: envValue('JPMORGAN_ONBOARD_CLIENT_PATH') || '/clients',
    balances: envValue('JPMORGAN_BALANCES_PATH') || '/accounts/{accountId}/balances',
    payments: envValue('JPMORGAN_CREATE_PAYMENT_PATH') || '/transactions',
  };

  // BUILD 092: capability configuration is intentionally independent from
  // provider authentication. A locally configured route is not proof that the
  // provider accepted OAuth, account access, or a payment request.
  const apiBaseConfigured = Boolean(normalizedApiOrigin(envValue('JPMORGAN_API_BASE_URL')));
  // BUILD 093: use the same effective routes as the operational handlers.
  // An omitted override means the deployed default route is active; it is not
  // equivalent to a missing route. Provider verification remains separate.
  const effectiveBalancesPath = configuredPath('JPMORGAN_BALANCES_PATH', '/accounts/{accountId}/balances');
  const effectivePaymentPath = configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions');
  const balancesPathConfigured = effectiveBalancesPath.startsWith('/');
  const paymentPathConfigured = effectivePaymentPath.startsWith('/');
  const paymentScopeConfigured = has('JPMORGAN_SCOPE');
  const products = {
    embeddedPayments: enabled,
    balances: apiBaseConfigured && balancesPathConfigured,
    payments: apiBaseConfigured && paymentPathConfigured && paymentScopeConfigured,
    callbacks: isTrue(process.env.ENABLE_JPMORGAN_CALLBACKS) &&
      Boolean(envValue('JPMORGAN_CALLBACK_VERIFICATION_MODE')) &&
      Boolean(envValue('JPMORGAN_CALLBACK_HMAC_SECRET')),
    cardProcessing: isTrue(process.env.JPMORGAN_ORBITAL_CONFIGURED),
    onlinePayments: onlinePaymentsMode,
  };

  const security = {
    mtls: has('JPMORGAN_MTLS_CERT') && has('JPMORGAN_MTLS_KEY'),
    configurationId: has('JPMORGAN_CONFIGURATION_ID'),
  };

  const verify = event?.queryStringParameters?.verify || new URLSearchParams(event?.rawQuery || '').get('verify');
  const configurationWarnings = [];
  for (const name of ['JPMORGAN_ENVIRONMENT','JPMORGAN_CLIENT_ID','JPMORGAN_TOKEN_URL','JPMORGAN_API_BASE_URL']) {
    const raw = String(process.env[name] || '').trim();
    if (raw.startsWith(`${name} =`) || raw.startsWith(`${name}=`)) configurationWarnings.push(`${name} contains a variable assignment instead of only its value.`);
  }
  const provider = { checked: false, token: false, accountAccess: false, paymentReadiness: false, verifiedAt: null };
  const readiness = {
    enabled,
    productionLabel: /prod|production|live/i.test(envValue('JPMORGAN_ENVIRONMENT')),
    tokenEndpointConfigured: has('JPMORGAN_TOKEN_URL') || has('JPM_TOKEN_URL') || (has('JPMORGAN_API_BASE_URL') && has('JPMORGAN_TOKEN_PATH')),
    clientCredentialsConfigured: has('JPMORGAN_CLIENT_ID') && has('JPMORGAN_CLIENT_SECRET'),
    configurationIdConfigured: has('JPMORGAN_CONFIGURATION_ID'),
    mtlsConfigured: has('JPMORGAN_MTLS_CERT') && has('JPMORGAN_MTLS_KEY'),
    callbackVerificationConfigured: products.callbacks,
    productMode,
    merchantIdConfigured: has('JPMORGAN_MERCHANT_ID'),
    apiBaseConfigured,
    balancesApiConfigured: products.balances,
    balancesPathConfigured,
    bankPaymentsApiConfigured: products.payments,
    paymentPathConfigured,
    paymentScopeConfigured,
    onlinePaymentsConfigurationComplete: products.payments,
    onlinePaymentsPathConfigured: paymentPathConfigured,
  };
  if (verify === 'token' || verify === 'account' || verify === 'payment' || verify === 'discover') {
    provider.checked = true;
    const correlationId = requestId(event);
    try {
      const user = await getSupabaseUser(getBearer(event));
      if (!user) return unauthorized('Administrator authentication required for provider verification.', 'AUTH_REQUIRED', correlationId);
      await requireAdminAuthority(user);
      await getJpmorganAccessToken();
      provider.token = true;

      if (verify === 'account' || verify === 'payment' || verify === 'discover') {
        if (verify === 'discover') {
          const discoveryPath = String(envValue('JPMORGAN_ACCOUNT_DISCOVERY_PATH') || '').trim();
          if (!discoveryPath) {
            const missing = new Error('Set JPMORGAN_ACCOUNT_DISCOVERY_PATH to the provider-approved account discovery endpoint.');
            missing.code = 'JPMORGAN_ACCOUNT_DISCOVERY_PATH_MISSING';
            missing.status = 503;
            missing.blockers = ['JPMORGAN_ACCOUNT_DISCOVERY_PATH'];
            throw missing;
          }
          if (!discoveryPath.startsWith('/')) {
            const invalid = new Error('JPMORGAN_ACCOUNT_DISCOVERY_PATH must start with /.');
            invalid.code = 'JPMORGAN_ACCOUNT_DISCOVERY_PATH_INVALID';
            invalid.status = 503;
            invalid.blockers = ['JPMORGAN_ACCOUNT_DISCOVERY_PATH'];
            throw invalid;
          }
          const discovered = await jpmorganRequest(discoveryPath, { correlationId: `discover-${Date.now()}` });
          const rows = Array.isArray(discovered) ? discovered : (discovered?.accounts || discovered?.items || discovered?.data || []);
          provider.accountAccess = true;
          provider.accountDiscovery = true;
          provider.discoveredCount = Array.isArray(rows) ? rows.length : null;
          provider.configurationMode = 'provider_read_only';
        } else if (onlinePaymentsMode) {
          const merchantId = String(envValue('JPMORGAN_MERCHANT_ID')).trim();
          const paymentPath = configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions');
          const apiBase = String(envValue('JPMORGAN_API_BASE_URL')).trim();
          const scope = String(envValue('JPMORGAN_SCOPE')).trim();
          const blockers = [];

          if (!apiBase) blockers.push('JPMORGAN_API_BASE_URL');
          if (!paymentPath) blockers.push('JPMORGAN_CREATE_PAYMENT_PATH');
          if (!scope) blockers.push('JPMORGAN_SCOPE');

          if (apiBase) {
            const apiOrigin = normalizedApiOrigin(apiBase);
            if (!apiOrigin) {
              try {
                const parsed = new URL(apiBase);
                if (parsed.protocol !== 'https:') blockers.push('JPMORGAN_API_BASE_URL must use HTTPS');
                else if ((parsed.pathname && parsed.pathname !== '/') || parsed.search || parsed.hash || parsed.username || parsed.password) blockers.push('JPMORGAN_API_BASE_URL must be a base origin without an API path');
                else blockers.push('JPMORGAN_API_BASE_URL is not a valid HTTPS URL');
              } catch {
                blockers.push('JPMORGAN_API_BASE_URL is not a valid URL');
              }
            }
          }
          if (paymentPath && !paymentPath.startsWith('/')) blockers.push('JPMORGAN_CREATE_PAYMENT_PATH must start with /');

          if (blockers.length) {
            const missing = new Error(`Online Payments configuration needs attention: ${blockers.join(', ')}`);
            missing.code = 'JPMORGAN_ONLINE_PAYMENTS_CONFIGURATION_MISSING';
            missing.status = 503;
            missing.blockers = blockers;
            throw missing;
          }

          // Non-transactional verification: OAuth was accepted and the product
          // configuration is structurally valid. No charge or payment is created.
          provider.accountAccess = true;
          provider.productAccess = true;
          provider.productMode = 'online_payments';
          provider.merchantIdConfigured = Boolean(merchantId);
          provider.configurationMode = 'non_transactional';
          provider.configuration = {
            apiOriginValid: true,
            apiOrigin: normalizedApiOrigin(apiBase),
            paymentPathValid: true,
            scopeConfigured: true,
          };
        } else {
          const verificationAccountId = String(envValue('JPMORGAN_VERIFICATION_ACCOUNT_ID')).trim();
          if (!verificationAccountId) {
            const missing = new Error('Set JPMORGAN_VERIFICATION_ACCOUNT_ID to an approved provider account identifier.');
            missing.code = 'JPMORGAN_VERIFICATION_ACCOUNT_MISSING';
            missing.status = 503;
            throw missing;
          }
          const balancePath = configuredPath('JPMORGAN_BALANCES_PATH', '/accounts/{accountId}/balances')
            .replace('{accountId}', encodeURIComponent(verificationAccountId));
          await jpmorganRequest(balancePath, { correlationId: `verify-${Date.now()}` });
          provider.accountAccess = true;
        }
      }

      if (verify === 'payment') {
        const paymentPath = configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions');
        const merchantId = String(envValue('JPMORGAN_MERCHANT_ID') || '').trim();
        const allowedCurrencies = String(envValue('JPMORGAN_ALLOWED_CURRENCIES') || 'USD')
          .split(',').map((value) => value.trim().toUpperCase()).filter(Boolean);
        const allowedMethods = String(envValue('JPMORGAN_ALLOWED_PAYMENT_METHODS') || 'ACH,WIRE')
          .split(',').map((value) => value.trim().toUpperCase()).filter(Boolean);
        const maxPaymentAmount = Number(envValue('JPMORGAN_MAX_PAYMENT_AMOUNT') || 100000);
        const callbackReady = products.callbacks;
        const blockers = [];
        const warnings = [];

        if (!paymentPath) blockers.push('JPMORGAN_CREATE_PAYMENT_PATH');
        else if (!paymentPath.startsWith('/')) blockers.push('JPMORGAN_CREATE_PAYMENT_PATH must start with /');
        if (!allowedCurrencies.length) blockers.push('JPMORGAN_ALLOWED_CURRENCIES');
        if (!allowedMethods.length) blockers.push('JPMORGAN_ALLOWED_PAYMENT_METHODS');
        if (!Number.isFinite(maxPaymentAmount) || maxPaymentAmount <= 0) blockers.push('JPMORGAN_MAX_PAYMENT_AMOUNT must be greater than 0');
        if (!merchantId) warnings.push('JPMORGAN_MERCHANT_ID is not configured');
        if (!callbackReady) warnings.push('Callback verification is not configured');

        if (blockers.length) {
          const invalid = new Error(`Payment readiness needs attention: ${blockers.join(', ')}`);
          invalid.code = 'JPMORGAN_PAYMENT_CONFIGURATION_INCOMPLETE';
          invalid.status = 503;
          invalid.blockers = blockers;
          throw invalid;
        }

        provider.paymentReadiness = true;
        provider.paymentControls = {
          endpointConfigured: true,
          paymentPath,
          merchantIdConfigured: Boolean(merchantId),
          allowedCurrencies,
          allowedMethods,
          maxPaymentAmount,
          idempotencyConfigured: true,
          callbackVerificationConfigured: callbackReady,
          warnings,
          dryRun: true,
        };
      }

      provider.verifiedAt = new Date().toISOString();
    } catch (error) {
      provider.accountAccess = false;
      provider.code = error?.code || 'JPMORGAN_VERIFICATION_FAILED';
      provider.error = verify === 'payment' ? 'Payment readiness verification failed.' : verify === 'account' ? 'Account access verification failed.' : 'Token verification failed.';
      provider.httpStatus = Number(error?.providerStatus || error?.status) || null;
      provider.providerCode = error?.providerCode || null;
      provider.authMethod = error?.authMethod || null;
      provider.blockers = Array.isArray(error?.blockers) ? error.blockers : [];
    }
  }

  return ok({
    enabled,
    environment: envValue('JPMORGAN_ENVIRONMENT') || 'not configured',
    products,
    security,
    provider,
    readiness,
    paths,
    configurationWarnings,
    productMode,
    relationshipStatus: envValue('JPMORGAN_RELATIONSHIP_STATUS') || 'Not configured',
    note: 'Product flags mean the deployed server code is configured. Provider token verification is separate and must pass before API operations can succeed.',
  });
}
