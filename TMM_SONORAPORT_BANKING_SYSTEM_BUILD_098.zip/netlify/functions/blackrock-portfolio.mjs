import { badRequest, forbidden, methodNotAllowed, ok, serverError } from './lib/shared.mjs';
import { blackRockRequest } from './lib/blackrock.mjs';

function executive(event) {
  return process.env.EXECUTIVE_ACCESS_TOKEN && event.headers?.['x-executive-token'] === process.env.EXECUTIVE_ACCESS_TOKEN;
}

export async function handler(event) {
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  if (!executive(event)) return forbidden();
  try {
    const portfolioId = String(event.queryStringParameters?.portfolioId || '').trim();
    if (!portfolioId) return badRequest('portfolioId is required.');
    if (!process.env.BLACKROCK_PORTFOLIO_PATH) return badRequest('BLACKROCK_PORTFOLIO_PATH has not been assigned.');
    const path = process.env.BLACKROCK_PORTFOLIO_PATH.replace('{portfolioId}', encodeURIComponent(portfolioId));
    return ok({ portfolio: await blackRockRequest(path) });
  } catch (error) {
    return serverError(error);
  }
}
