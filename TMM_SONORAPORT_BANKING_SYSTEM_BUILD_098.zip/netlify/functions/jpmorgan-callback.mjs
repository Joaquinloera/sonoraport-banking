import crypto from 'node:crypto';
import { badRequest, cleanText, json, methodNotAllowed, ok, readJson, requestId, serverError } from './lib/shared.mjs';
import { getCertificationByExternalId, updateCertification } from './lib/certification-store.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';
import { finalizePaymentReservation } from './lib/ledger-control.mjs';

function timingSafeEqualText(left, right) {
  const a = Buffer.from(String(left || ''), 'utf8');
  const b = Buffer.from(String(right || ''), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function verifyConfiguredHmac(event, signature) {
  const secret = process.env.JPMORGAN_CALLBACK_HMAC_SECRET || '';
  if (!secret) return false;
  const expected = crypto.createHmac('sha256', secret).update(event.body || '').digest('hex');
  const normalized = String(signature || '').replace(/^sha256=/i, '').trim().toLowerCase();
  return timingSafeEqualText(expected, normalized);
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);

  try {
    if (process.env.ENABLE_JPMORGAN_CALLBACKS !== 'true') {
      return ok({ received: false, reason: 'Callbacks disabled', correlationId });
    }

    const verificationMode = process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE || '';
    if (verificationMode !== 'hmac-sha256') {
      return json(503, {
        error: 'Callback verification is not configured.',
        code: 'CALLBACK_VERIFICATION_NOT_CONFIGURED',
        correlationId,
      });
    }

    const signature = event.headers?.['x-jpm-signature'] || event.headers?.['x-signature'] || '';
    const timestampText = event.headers?.['x-jpm-timestamp'] || event.headers?.['x-timestamp'] || '';
    if (!signature || !timestampText) {
      return json(401, { error: 'Missing callback verification headers.', code: 'CALLBACK_HEADERS_MISSING', correlationId });
    }

    const timestamp = Number(timestampText);
    const timestampMs = timestamp > 1e12 ? timestamp : timestamp * 1000;
    if (!Number.isFinite(timestampMs) || Math.abs(Date.now() - timestampMs) > 5 * 60 * 1000) {
      return json(401, { error: 'Callback timestamp is outside the accepted window.', code: 'CALLBACK_TIMESTAMP_INVALID', correlationId });
    }

    if (!verifyConfiguredHmac(event, signature)) {
      return json(401, { error: 'Callback signature verification failed.', code: 'CALLBACK_SIGNATURE_INVALID', correlationId });
    }

    const payload = await readJson(event);
    const eventType = String(payload?.eventType || payload?.type || '').trim();
    const eventId = String(payload?.id || payload?.eventId || '').trim();
    if (!eventType || !eventId) {
      return badRequest('Callback event type and ID are required.', 'CALLBACK_PAYLOAD_INVALID', correlationId);
    }

    const externalPaymentId = cleanText(
      payload?.externalPaymentId || payload?.data?.externalPaymentId || payload?.payment?.externalPaymentId || payload?.transaction?.externalPaymentId,
      180,
    );
    const providerPaymentId = cleanText(
      payload?.paymentId || payload?.transactionId || payload?.data?.paymentId || payload?.data?.transactionId || payload?.payment?.id || payload?.transaction?.id,
      180,
    );
    const providerStatus = cleanText(
      payload?.status || payload?.data?.status || payload?.payment?.status || payload?.transaction?.status || eventType,
      60,
    ).toLowerCase();

    let ledgerUpdated = false;
    if (externalPaymentId && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(externalPaymentId)) {
      const settledStatuses = new Set(['completed', 'complete', 'settled', 'paid', 'succeeded', 'success']);
      const failedStatuses = new Set(['failed', 'rejected', 'returned', 'cancelled', 'canceled', 'declined', 'expired']);
      if (settledStatuses.has(providerStatus)) {
        await finalizePaymentReservation({ paymentId: externalPaymentId, outcome: 'settled', providerStatus, providerPaymentId, correlationId });
        ledgerUpdated = true;
      } else if (failedStatuses.has(providerStatus)) {
        await finalizePaymentReservation({ paymentId: externalPaymentId, outcome: 'failed', providerStatus, providerPaymentId, failureReason: eventType, correlationId });
        ledgerUpdated = true;
      }
    }

    let certificationUpdated = false;
    if (externalPaymentId) {
      const certification = await getCertificationByExternalId(externalPaymentId);
      if (certification) {
        if (certification.callback_event_id === eventId) {
          return ok({ received: true, duplicate: true, certificationUpdated: false, correlationId });
        }
        await updateCertification(externalPaymentId, {
          provider_payment_id: providerPaymentId || certification.provider_payment_id || null,
          status: providerStatus || certification.status,
          callback_event_id: eventId,
          callback_received_at: new Date().toISOString(),
        });
        certificationUpdated = true;
      }
    }

    await appendAuditEvent({ correlationId, action: 'payment.callback_verified', outcome: 'accepted', resourceId: externalPaymentId || providerPaymentId || eventId, details: { eventType, eventId, providerPaymentId, providerStatus, returned: providerStatus === 'returned', certificationUpdated, ledgerUpdated } });
    console.log(JSON.stringify({ level: 'info', source: 'jpmorgan-callback', correlationId, eventType, eventId, externalPaymentId: externalPaymentId || undefined, certificationUpdated }));
    return ok({ received: true, certificationUpdated, ledgerUpdated, correlationId });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
