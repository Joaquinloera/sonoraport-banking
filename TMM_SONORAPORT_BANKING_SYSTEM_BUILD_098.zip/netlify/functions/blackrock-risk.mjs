import { badRequest, forbidden, methodNotAllowed, ok, readJson, serverError } from './lib/shared.mjs';
import { blackRockRequest } from './lib/blackrock.mjs';

function executive(event) {
  return process.env.EXECUTIVE_ACCESS_TOKEN && event.headers?.['x-executive-token'] === process.env.EXECUTIVE_ACCESS_TOKEN;
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);
  if (!executive(event)) return forbidden();
  try {
    if (!process.env.BLACKROCK_RISK_PATH) return badRequest('BLACKROCK_RISK_PATH has not been assigned.');
    const body = await readJson(event);
    if (!body.portfolioId) return badRequest('portfolioId is required.');
    const result = await blackRockRequest(process.env.BLACKROCK_RISK_PATH, {
      method: 'POST',
      body: {
        portfolioId: String(body.portfolioId).slice(0, 200),
        asOfDate: body.asOfDate || undefined,
        measures: Array.isArray(body.measures) ? body.measures.slice(0, 25) : undefined,
      },
    });
    return ok({ risk: result });
  } catch (error) {
    return serverError(error);
  }
}
