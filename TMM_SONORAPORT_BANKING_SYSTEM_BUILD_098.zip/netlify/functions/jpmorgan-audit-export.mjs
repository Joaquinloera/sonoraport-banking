import { forbidden, getBearer, getSupabaseUser, json, methodNotAllowed, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { isAuditAdmin } from './lib/audit-log.mjs';

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before exporting audit evidence.', 'AUTH_REQUIRED', correlationId);
    if (!isAuditAdmin(user)) return forbidden('Audit export requires an authorized compliance administrator.', 'AUDIT_ADMIN_REQUIRED', correlationId);

    const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!base || !key) throw Object.assign(new Error('Audit database configuration is missing.'), { status: 503, code: 'AUDIT_DATABASE_MISSING' });
    const limit = Math.min(5000, Math.max(1, Number(event.queryStringParameters?.limit) || 1000));
    const response = await fetch(`${base}/rest/v1/jpmorgan_audit_events?select=*&order=sequence_no.asc&limit=${limit}`, {
      headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' },
    });
    const rows = await response.json().catch(() => []);
    if (!response.ok) throw Object.assign(new Error(rows?.message || 'Unable to export audit evidence.'), { status: response.status, code: 'AUDIT_EXPORT_FAILED' });

    return json(200, {
      generatedAt: new Date().toISOString(),
      provider: 'J.P. Morgan',
      eventCount: Array.isArray(rows) ? rows.length : 0,
      events: rows,
      correlationId,
    }, { 'Content-Disposition': `attachment; filename="jpmorgan-audit-${Date.now()}.json"` });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
