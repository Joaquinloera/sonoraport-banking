import crypto from 'node:crypto';
import { badRequest, cleanText, getBearer, getLinkedProviderAccount, getSupabaseUser, json, methodNotAllowed, ok, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { configuredPath, jpmorganRequest } from './lib/jpmorgan.mjs';
import { paymentOperationsBlocked } from './lib/operations-control.mjs';
import { createCertification, getCertificationByExternalId, updateCertification } from './lib/certification-store.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const CONFIRMATION = 'AUTHORIZE CONTROLLED TEST PAYMENT';

function configuration() {
  const amount = Number(process.env.JPMORGAN_CERTIFICATION_AMOUNT || '0.01');
  const currency = cleanText(process.env.JPMORGAN_CERTIFICATION_CURRENCY || 'USD', 3).toUpperCase();
  const paymentMethod = cleanText(process.env.JPMORGAN_CERTIFICATION_PAYMENT_METHOD || 'ACH', 40).toUpperCase();
  const destinationId = cleanText(process.env.JPMORGAN_CERTIFICATION_DESTINATION_ID, 180);
  const runId = cleanText(process.env.JPMORGAN_CERTIFICATION_RUN_ID, 120);
  const enabled = process.env.JPMORGAN_ENABLE_CONTROLLED_TEST_PAYMENT === 'true';
  const callbacksReady = process.env.ENABLE_JPMORGAN_CALLBACKS === 'true' &&
    process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE === 'hmac-sha256' &&
    Boolean(process.env.JPMORGAN_CALLBACK_HMAC_SECRET);
  return { amount, currency, paymentMethod, destinationId, runId, enabled, callbacksReady };
}

function safeConfig(config) {
  return {
    enabled: config.enabled,
    callbacksReady: config.callbacksReady,
    amount: Number.isFinite(config.amount) ? config.amount.toFixed(2) : '',
    currency: config.currency,
    paymentMethod: config.paymentMethod,
    destinationConfigured: Boolean(config.destinationId),
    runIdConfigured: Boolean(config.runId),
    confirmationText: CONFIRMATION,
  };
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET', 'POST'].includes(event.httpMethod)) return methodNotAllowed(['GET', 'POST']);
  try {
    // Configuration may always be inspected. Only an actual certification POST
    // is blocked by operations controls.
    if (event.httpMethod === 'POST') {
      const operationsLock = paymentOperationsBlocked(correlationId);
      if (operationsLock) return operationsLock;
    }

    const config = configuration();
    if (event.httpMethod === 'GET') {
      const safe = safeConfig(config);
      const coreReady = Boolean(safe.amount && safe.currency && safe.paymentMethod);
      return ok({
        certification: safe,
        coreReady,
        providerActivationPending: !safe.enabled || !safe.callbacksReady || !safe.destinationConfigured || !safe.runIdConfigured,
        correlationId,
      });
    }

    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before running payment certification.', 'AUTH_REQUIRED', correlationId);

    if (!config.enabled) return json(423, { error: 'Controlled payment certification is locked.', code: 'CERTIFICATION_LOCKED', correlationId });
    if (!config.callbacksReady) return json(423, { error: 'Verified callbacks are required before certification.', code: 'CERTIFICATION_CALLBACKS_REQUIRED', correlationId });
    if (!config.destinationId || !config.runId || !Number.isFinite(config.amount) || config.amount <= 0) {
      return json(503, { error: 'Controlled payment certification is not fully configured.', code: 'CERTIFICATION_CONFIGURATION_MISSING', correlationId });
    }

    const maxAmount = Math.max(0.01, Number(process.env.JPMORGAN_CERTIFICATION_MAX_AMOUNT) || 1);
    if (config.amount > maxAmount) {
      return json(423, { error: 'Certification amount exceeds the server safety limit.', code: 'CERTIFICATION_AMOUNT_BLOCKED', correlationId });
    }

    const body = await readJson(event);
    if (cleanText(body.confirmation, 80) !== CONFIRMATION) {
      return badRequest('Exact authorization phrase is required.', 'CERTIFICATION_CONFIRMATION_REQUIRED', correlationId);
    }

    const linked = await getLinkedProviderAccount(token, 'jpmorgan', cleanText(body.linkedAccountId, 80), user.id);
    if (!linked) return unauthorized('No active J.P. Morgan source account is linked to this profile.', 'PROVIDER_ACCOUNT_NOT_LINKED', correlationId);

    const externalPaymentId = crypto.createHash('sha256')
      .update(`${config.runId}:${user.id}:${linked.provider_account_id}:${config.destinationId}:${config.amount}:${config.currency}:${config.paymentMethod}`)
      .digest('hex')
      .slice(0, 48);

    const existing = await getCertificationByExternalId(externalPaymentId);
    if (existing) {
      return ok({ certification: { status: existing.status, externalPaymentId, providerPaymentId: existing.provider_payment_id || null, duplicateBlocked: true }, correlationId });
    }

    const destinationFingerprint = crypto.createHash('sha256').update(config.destinationId).digest('hex').slice(0, 16);
    await createCertification({
      profile_id: user.id,
      linked_account_id: linked.id,
      external_payment_id: externalPaymentId,
      destination_fingerprint: destinationFingerprint,
      amount: config.amount.toFixed(2),
      currency: config.currency,
      payment_method: config.paymentMethod,
      status: 'submitting',
      correlation_id: correlationId,
    });

    const payload = {
      externalPaymentId,
      sourceAccountId: linked.provider_account_id,
      destinationId: config.destinationId,
      amount: { value: config.amount.toFixed(2), currency: config.currency },
      paymentMethod: config.paymentMethod,
      memo: 'SonoraPort controlled production certification',
      metadata: { customerId: user.id, linkedAccountId: linked.id, certification: true },
    };

    try {
      await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'certification.payment_authorized', outcome: 'authorized', resourceId: externalPaymentId, details: { amount: config.amount.toFixed(2), currency: config.currency, paymentMethod: config.paymentMethod, linkedAccountId: linked.id } });
      const providerData = await jpmorganRequest(configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions'), {
        method: 'POST',
        body: payload,
        idempotencyKey: externalPaymentId,
        correlationId,
      });
      const providerPaymentId = cleanText(providerData?.id || providerData?.paymentId || providerData?.transactionId, 180);
      await updateCertification(externalPaymentId, {
        provider_payment_id: providerPaymentId || null,
        status: cleanText(providerData?.status || 'submitted', 60).toLowerCase(),
        provider_response_received_at: new Date().toISOString(),
      });
      await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'certification.payment_submitted', outcome: 'submitted', resourceId: externalPaymentId, details: { providerPaymentId: providerPaymentId || null, providerStatus: cleanText(providerData?.status || 'submitted', 60).toLowerCase() } });
      return json(201, {
        certification: { status: cleanText(providerData?.status || 'submitted', 60).toLowerCase(), externalPaymentId, providerPaymentId: providerPaymentId || null, duplicateBlocked: false },
        correlationId,
      });
    } catch (error) {
      await updateCertification(externalPaymentId, { status: 'submission_failed', failure_code: cleanText(error?.code, 80) });
      throw error;
    }
  } catch (error) {
    return serverError(error, correlationId);
  }
}
