import { cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { jpmorganRequest } from './lib/jpmorgan.mjs';
import { getLatestCertificationForProfile, updateCertification } from './lib/certification-store.mjs';

const TERMINAL_SUCCESS = new Set(['completed', 'settled', 'succeeded', 'paid']);
const TERMINAL_FAILURE = new Set(['failed', 'rejected', 'cancelled', 'canceled', 'returned', 'reversed']);
const normalizeStatus = (value) => cleanText(value, 60).toLowerCase();

function statusPath(providerPaymentId) {
  const template = process.env.JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE || '';
  if (!template || !template.includes('{paymentId}')) {
    const error = new Error('Set JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE with {paymentId}.');
    error.status = 503;
    error.code = 'JPMORGAN_STATUS_PATH_MISSING';
    throw error;
  }
  return template.replace('{paymentId}', encodeURIComponent(providerPaymentId));
}

function readProviderFields(data) {
  const root = data?.payment || data?.transaction || data?.data || data || {};
  const amountNode = root?.amount || root?.paymentAmount || {};
  return {
    status: normalizeStatus(root?.status || root?.state || data?.status || data?.state),
    amount: Number(amountNode?.value ?? amountNode?.amount ?? root?.amountValue ?? NaN),
    currency: cleanText(amountNode?.currency || root?.currency, 3).toUpperCase(),
    externalPaymentId: cleanText(root?.externalPaymentId || root?.clientReferenceId || data?.externalPaymentId, 180),
    providerPaymentId: cleanText(root?.id || root?.paymentId || root?.transactionId || data?.id, 180),
  };
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before reconciling certification.', 'AUTH_REQUIRED', correlationId);

    const record = await getLatestCertificationForProfile(user.id);
    if (!record) return json(404, { error: 'No certification payment exists.', code: 'CERTIFICATION_NOT_FOUND', correlationId });
    if (!record.provider_payment_id) return json(409, { error: 'Provider payment ID has not been recorded.', code: 'PROVIDER_PAYMENT_ID_MISSING', correlationId });

    const providerData = await jpmorganRequest(statusPath(record.provider_payment_id), { method: 'GET', correlationId });
    const provider = readProviderFields(providerData);
    const expectedAmount = Number(record.amount);
    const amountMatches = !Number.isFinite(provider.amount) || Math.abs(provider.amount - expectedAmount) < 0.005;
    const currencyMatches = !provider.currency || provider.currency === String(record.currency).toUpperCase();
    const externalIdMatches = !provider.externalPaymentId || provider.externalPaymentId === record.external_payment_id;
    const providerIdMatches = !provider.providerPaymentId || provider.providerPaymentId === record.provider_payment_id;
    const integrityPassed = amountMatches && currencyMatches && externalIdMatches && providerIdMatches;

    let reconciliationStatus = 'pending';
    if (!integrityPassed) reconciliationStatus = 'mismatch';
    else if (TERMINAL_SUCCESS.has(provider.status) && record.callback_received_at) reconciliationStatus = 'settled';
    else if (TERMINAL_FAILURE.has(provider.status)) reconciliationStatus = 'failed';
    else if (TERMINAL_SUCCESS.has(provider.status) && !record.callback_received_at) reconciliationStatus = 'awaiting_callback';

    await updateCertification(record.external_payment_id, {
      provider_status: provider.status || null,
      reconciliation_status: reconciliationStatus,
      reconciliation_checked_at: new Date().toISOString(),
      reconciliation_details: {
        amountMatches,
        currencyMatches,
        externalIdMatches,
        providerIdMatches,
        callbackVerified: Boolean(record.callback_received_at),
      },
      settled_at: reconciliationStatus === 'settled' ? new Date().toISOString() : record.settled_at || null,
    });

    return ok({
      reconciliation: {
        status: reconciliationStatus,
        providerStatus: provider.status || 'unknown',
        integrityPassed,
        callbackVerified: Boolean(record.callback_received_at),
        settled: reconciliationStatus === 'settled',
        checks: { amountMatches, currencyMatches, externalIdMatches, providerIdMatches },
      },
      correlationId,
    });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
