import { badRequest, cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const reasons = new Set(['duplicate','service_not_received','canceled_service','incorrect_amount','refund_promised','other']);
function db() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Refund database configuration is missing.'), { status: 503, code: 'REFUND_DATABASE_MISSING' });
  return { base, headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Accept: 'application/json' } };
}
async function paymentForUser(id, profileId) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: 'id,profile_id,status,amount,currency,settled_at', id: `eq.${id}`, profile_id: `eq.${profileId}`, limit: '1' });
  const r = await fetch(`${base}/rest/v1/payment_reservations?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to verify payment.'), { status: r.status, code: 'REFUND_PAYMENT_LOOKUP_FAILED' });
  return rows?.[0] || null;
}
async function list(profileId) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: 'id,payment_id,request_type,requested_amount,currency,reason_code,customer_note,status,provider_status,provider_reference,failure_reason,created_at,updated_at,completed_at', profile_id: `eq.${profileId}`, order: 'created_at.desc', limit: '100' });
  const r = await fetch(`${base}/rest/v1/payment_refund_requests?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to load refund requests.'), { status: r.status, code: 'REFUND_QUERY_FAILED' });
  return rows;
}
export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','POST'].includes(event.httpMethod)) return methodNotAllowed(['GET','POST']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to manage refunds.', 'AUTH_REQUIRED', correlationId);
    if (event.httpMethod === 'GET') return json(200, { refunds: await list(user.id), correlationId }, { 'cache-control': 'no-store' });
    const body = await readJson(event);
    const paymentId = cleanText(body?.paymentId, 80);
    const reasonCode = cleanText(body?.reasonCode, 60).toLowerCase();
    const note = cleanText(body?.note, 2000);
    const amount = Number(body?.amount);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(paymentId)) return badRequest('A valid payment ID is required.', 'INVALID_PAYMENT_ID', correlationId);
    if (!reasons.has(reasonCode)) return badRequest('Select a valid refund reason.', 'INVALID_REFUND_REASON', correlationId);
    if (note.length < 10) return badRequest('Provide at least 10 characters explaining the request.', 'REFUND_NOTE_TOO_SHORT', correlationId);
    const payment = await paymentForUser(paymentId, user.id);
    if (!payment) return json(404, { error: 'Payment not found.', code: 'PAYMENT_NOT_FOUND', correlationId });
    if (payment.status !== 'settled') return json(409, { error: 'Only settled payments can be refunded.', code: 'PAYMENT_NOT_SETTLED', correlationId });
    const requestedAmount = Number.isFinite(amount) && amount > 0 ? amount : Number(payment.amount);
    if (requestedAmount > Number(payment.amount)) return badRequest('Refund amount cannot exceed the settled payment amount.', 'REFUND_AMOUNT_EXCEEDS_PAYMENT', correlationId);
    const { base, headers } = db();
    const r = await fetch(`${base}/rest/v1/payment_refund_requests`, { method: 'POST', headers: { ...headers, Prefer: 'return=representation' }, body: JSON.stringify({ profile_id: user.id, payment_id: paymentId, request_type: 'refund', requested_amount: requestedAmount.toFixed(2), currency: payment.currency, reason_code: reasonCode, customer_note: note, correlation_id: correlationId }) });
    const rows = await r.json().catch(() => null);
    if (r.status === 409) return json(409, { error: 'A refund request already exists for this payment.', code: 'REFUND_ALREADY_EXISTS', correlationId });
    if (!r.ok) throw Object.assign(new Error(rows?.message || 'Unable to create refund request.'), { status: r.status, code: 'REFUND_CREATE_FAILED' });
    const refund = rows?.[0] || rows;
    await appendAuditEvent({ correlationId, actorUserId: user.id, action: 'payment.refund_requested', outcome: 'submitted', resourceId: paymentId, details: { refundRequestId: refund?.id, amount: requestedAmount.toFixed(2), currency: payment.currency, reasonCode } });
    return json(201, { refund, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) { return serverError(error, correlationId); }
}
