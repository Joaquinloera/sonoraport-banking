import {cleanText,getBearer,getSupabaseUser,methodNotAllowed,readJson,requestId,unauthorized,badRequest,serverError} from './lib/shared.mjs';
import {ownedCard,patchOwnedCard} from './lib/card-store.mjs';
const json=(s,b)=>({statusCode:s,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(b)});
const blocked=new Set(['closed','closing','replaced','replacement_requested','replacement_pending','closure_requested']);
export async function handler(event){
  const cid=requestId(event);
  if(event.httpMethod!=='POST')return methodNotAllowed(['POST']);
  try{
    const user=await getSupabaseUser(getBearer(event));
    if(!user)return unauthorized('Sign in before changing card lifecycle.','AUTH_REQUIRED',cid);
    const body=await readJson(event);
    const cardId=cleanText(body.cardId,80),action=cleanText(body.action,20).toLowerCase();
    if(!cardId||!['replace','close'].includes(action))return badRequest('Card and supported lifecycle action are required.','CARD_LIFECYCLE_INVALID',cid);
    const found=await ownedCard(user.id,cardId);
    if(!found)return unauthorized('Card is unavailable for this profile.','CARD_NOT_AUTHORIZED',cid);
    const {table,card}=found;
    const lifecycle=String(card.lifecycle_status||'current').toLowerCase();
    if(blocked.has(lifecycle)||card.replacement_requested_at||card.closure_requested_at)return json(409,{error:'Card already has a pending or terminal lifecycle request.',code:'CARD_LIFECYCLE_CONFLICT',correlationId:cid});
    const now=new Date().toISOString();
    const patch=action==='replace'?{replacement_requested_at:now,lifecycle_status:'replacement_requested',updated_at:now}:{closure_requested_at:now,lifecycle_status:'closing',updated_at:now};
    // Compare-and-set closes the race between two authenticated requests that read the same old card state.
    const updated=await patchOwnedCard(table,user.id,cardId,patch,card.lifecycle_status??null);
    if(!Array.isArray(updated)||updated.length!==1)return json(409,{error:'Card changed while processing this request. Refresh its status.',code:'CARD_LIFECYCLE_STALE',correlationId:cid});
    return json(202,{ok:true,action,status:patch.lifecycle_status,message:action==='replace'?'Replacement request recorded for operations/provider processing.':'Closure request recorded for operations/provider processing.',providerCompleted:false,correlationId:cid});
  }catch(e){return serverError(e,cid)}
}
