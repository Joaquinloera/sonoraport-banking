import crypto from 'node:crypto';
import { handler as callbackHandler } from './jpmorgan-callback.mjs';
import { getBearer, getSupabaseUser, json, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

function sign(body, secret) {
  return crypto.createHmac('sha256', secret).update(body).digest('hex');
}

async function invokeCallback({ body, signature, timestamp }) {
  return callbackHandler({
    httpMethod: 'POST',
    body,
    headers: {
      'x-jpm-signature': signature,
      'x-jpm-timestamp': String(timestamp),
      'x-request-id': `callback-self-test-${Date.now()}`,
    },
  });
}

function parseResponse(response) {
  try { return JSON.parse(response?.body || '{}'); } catch { return {}; }
}

export async function handler(event = {}) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);

  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Administrator authentication required for callback verification.', 'AUTH_REQUIRED', correlationId);
    await requireAdminAuthority(user);
    const providerCallbacksEnabled = String(process.env.ENABLE_JPMORGAN_CALLBACKS || '').toLowerCase() === 'true';
    const configuredMode = process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE === 'hmac-sha256';
    const configuredSecret = String(process.env.JPMORGAN_CALLBACK_HMAC_SECRET || '');

    // The self-test can validate the deployed callback handler before the provider
    // registers the public callback URL. In that case it uses a temporary secret
    // only for this isolated invocation and restores the server environment after.
    const secret = configuredSecret || crypto.randomBytes(32).toString('hex');
    const original = {
      enabled: process.env.ENABLE_JPMORGAN_CALLBACKS,
      mode: process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE,
      secret: process.env.JPMORGAN_CALLBACK_HMAC_SECRET,
    };
    process.env.ENABLE_JPMORGAN_CALLBACKS = 'true';
    process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE = 'hmac-sha256';
    process.env.JPMORGAN_CALLBACK_HMAC_SECRET = secret;

    const body = JSON.stringify({
      eventId: `self-test-${crypto.randomUUID()}`,
      eventType: 'payment.status.updated',
      paymentId: 'redacted-self-test',
      status: 'TEST_ONLY',
    });
    const timestamp = Math.floor(Date.now() / 1000);

    const validResponse = await invokeCallback({ body, signature: sign(body, secret), timestamp });
    const validPayload = parseResponse(validResponse);

    const forgedResponse = await invokeCallback({ body, signature: sign(`${body}-forged`, secret), timestamp });
    const forgedPayload = parseResponse(forgedResponse);

    const staleTimestamp = timestamp - (10 * 60);
    const replayResponse = await invokeCallback({ body, signature: sign(body, secret), timestamp: staleTimestamp });
    const replayPayload = parseResponse(replayResponse);

    const validAccepted = validResponse?.statusCode === 200 && validPayload?.received === true;
    const forgedRejected = forgedResponse?.statusCode === 401 && forgedPayload?.code === 'CALLBACK_SIGNATURE_INVALID';
    const replayRejected = replayResponse?.statusCode === 401 && replayPayload?.code === 'CALLBACK_TIMESTAMP_INVALID';
    const verified = validAccepted && forgedRejected && replayRejected;

    return ok({
      verified,
      coreControlsPassed: verified,
      providerRegistrationPending: !(providerCallbacksEnabled && configuredMode && Boolean(configuredSecret)),
      checks: {
        validSignatureAccepted: validAccepted,
        forgedSignatureRejected: forgedRejected,
        staleTimestampRejected: replayRejected,
      },
      verifiedAt: new Date().toISOString(),
      correlationId,
      note: providerCallbacksEnabled && configuredMode && configuredSecret
        ? 'Configured callback controls passed. No payment was created.'
        : 'Callback security core controls passed locally. Provider callback registration is still pending. No payment was created.',
    });
  } catch (error) {
    return serverError(error, correlationId);
  } finally {
    if (typeof original !== 'undefined') {
      if (original.enabled === undefined) delete process.env.ENABLE_JPMORGAN_CALLBACKS; else process.env.ENABLE_JPMORGAN_CALLBACKS = original.enabled;
      if (original.mode === undefined) delete process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE; else process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE = original.mode;
      if (original.secret === undefined) delete process.env.JPMORGAN_CALLBACK_HMAC_SECRET; else process.env.JPMORGAN_CALLBACK_HMAC_SECRET = original.secret;
    }
  }
}
