import { getBearer, getSupabaseUser, json, methodNotAllowed, requestId, unauthorized, serverError } from './lib/shared.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

export async function handler(event){
  const correlationId=requestId(event);
  if(event.httpMethod!=='GET') return methodNotAllowed(['GET']);
  try{
    const user=await getSupabaseUser(getBearer(event));
    if(!user) return unauthorized('Administrator authentication required.','AUTH_REQUIRED',correlationId);
    const profile=await requireAdminAuthority(user);
    return json(200,{authorized:true,profile:{id:profile.id,email:profile.email||user.email||'',full_name:profile.full_name||'',role:profile.role},correlationId});
  }catch(e){return serverError(e,correlationId)}
}
