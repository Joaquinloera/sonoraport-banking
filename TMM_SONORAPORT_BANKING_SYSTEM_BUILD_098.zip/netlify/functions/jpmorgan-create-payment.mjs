import crypto from 'node:crypto';
import { badRequest, cleanText, getBearer, getLinkedProviderAccount, getSupabaseUser, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { configuredPath, jpmorganRequest } from './lib/jpmorgan.mjs';
import { paymentOperationsBlocked } from './lib/operations-control.mjs';
import { assessPaymentRisk } from './lib/payment-risk.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';
import { reserveProviderPayment, updatePaymentReservation } from './lib/ledger-control.mjs';
import { getActiveBeneficiary, markBeneficiaryUsed } from './lib/beneficiary-control.mjs';
import { requireActiveCustomer } from './lib/onboarding-control.mjs';

async function createReviewRecord(record) {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Review database configuration is missing.'), { status: 503, code: 'REVIEW_DATABASE_MISSING' });
  const response = await fetch(`${base}/rest/v1/payment_approval_requests`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, apikey: key, 'Content-Type': 'application/json', Prefer: 'return=representation' },
    body: JSON.stringify(record),
  });
  const data = await response.json().catch(() => []);
  if (!response.ok) throw Object.assign(new Error(data?.message || 'Unable to create payment review record.'), { status: response.status, code: 'REVIEW_RECORD_FAILED' });
  return Array.isArray(data) ? data[0] : data;
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);
  try {
    const operationsLock = paymentOperationsBlocked(correlationId);
    if (operationsLock) return operationsLock;

    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before creating a payment.', 'AUTH_REQUIRED', correlationId);

    await requireActiveCustomer(user.id);

    const body = await readJson(event);
    const amount = Number(body.amount);
    const currency = cleanText(body.currency, 3).toUpperCase();
    const beneficiaryId = cleanText(body.beneficiaryId, 80);
    const paymentMethod = cleanText(body.paymentMethod || 'ACH', 40).toUpperCase();
    const memo = cleanText(body.memo, 140);
    const maxPaymentAmount = Math.max(0.01, Number(process.env.JPMORGAN_MAX_PAYMENT_AMOUNT) || 100000);
    const allowedCurrencies = new Set(String(process.env.JPMORGAN_ALLOWED_CURRENCIES || 'USD').split(',').map((value) => value.trim().toUpperCase()).filter(Boolean));
    const allowedMethods = new Set(String(process.env.JPMORGAN_ALLOWED_PAYMENT_METHODS || 'ACH,WIRE').split(',').map((value) => value.trim().toUpperCase()).filter(Boolean));

    if (!Number.isFinite(amount) || amount <= 0 || amount > maxPaymentAmount || !currency || !beneficiaryId) {
      return badRequest(`Valid amount up to ${maxPaymentAmount.toFixed(2)}, currency, and verified beneficiary are required.`, 'PAYMENT_FIELDS_INVALID', correlationId);
    }
    if (!allowedCurrencies.has(currency)) return badRequest('Currency is not enabled for payments.', 'PAYMENT_CURRENCY_NOT_ALLOWED', correlationId);
    if (!allowedMethods.has(paymentMethod)) return badRequest('Payment method is not enabled.', 'PAYMENT_METHOD_NOT_ALLOWED', correlationId);

    const beneficiary = await getActiveBeneficiary({ beneficiaryId, profileId: user.id, currency });
    if (!beneficiary) return badRequest('The selected beneficiary is not active, is still in its cooling-off period, or does not support this currency.', 'BENEFICIARY_NOT_ACTIVE', correlationId);

    const linked = await getLinkedProviderAccount(token, 'jpmorgan', cleanText(body.linkedAccountId, 80), user.id);
    if (!linked) return unauthorized('No active J.P. Morgan source account is linked to this profile.', 'PROVIDER_ACCOUNT_NOT_LINKED', correlationId);

    const paymentId = crypto.randomUUID();
    const risk = assessPaymentRisk({ amount, currency, paymentMethod });
    if (risk.blocked) {
      await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.risk_assessment', outcome: 'blocked', resourceId: paymentId, details: { amount: amount.toFixed(2), currency, paymentMethod, riskScore: risk.score, reasons: risk.reasons } });
      return badRequest('This payment is blocked by transaction-monitoring policy.', 'PAYMENT_RISK_BLOCKED', correlationId);
    }

    if (risk.heldForReview) {
      const review = await createReviewRecord({
        id: paymentId,
        requester_profile_id: user.id,
        linked_account_id: linked.id,
        provider_account_id: linked.provider_account_id,
        destination_id: beneficiary.provider_destination_id,
        amount: amount.toFixed(2),
        currency,
        payment_method: paymentMethod,
        memo,
        risk_score: risk.score,
        risk_reasons: risk.reasons,
        required_approvals: risk.requiredApprovals,
        status: 'pending_approval',
        correlation_id: correlationId,
      });
      await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.approval_requested', outcome: 'held_for_review', resourceId: review?.id || paymentId, details: { amount: amount.toFixed(2), currency, paymentMethod, riskScore: risk.score, reasons: risk.reasons, requiredApprovals: risk.requiredApprovals } });
      return {
        statusCode: 202,
        headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
        body: JSON.stringify({ heldForReview: true, reviewId: review?.id || paymentId, status: 'pending_approval', risk: { score: risk.score, reasons: risk.reasons, requiredApprovals: risk.requiredApprovals }, correlationId }),
      };
    }

    const reservation = await reserveProviderPayment({
      paymentId, profileId: user.id, linkedAccountId: linked.id, amount, currency, correlationId,
    });
    await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.funds_reserved', outcome: 'reserved', resourceId: paymentId, details: { amount: amount.toFixed(2), currency, linkedAccountId: linked.id, journalId: reservation?.journalId } });

    // Payment method/direction are descriptive lifecycle metadata; provider status remains authoritative.
    const dbBase = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
    const dbKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (dbBase && dbKey) {
      await fetch(`${dbBase}/rest/v1/payment_reservations?id=eq.${encodeURIComponent(paymentId)}&profile_id=eq.${encodeURIComponent(user.id)}`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${dbKey}`, apikey: dbKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_method: paymentMethod, direction: 'outgoing' }),
      }).catch(() => null);
    }

    const payload = {
      externalPaymentId: paymentId,
      sourceAccountId: linked.provider_account_id,
      destinationId: beneficiary.provider_destination_id,
      amount: { value: amount.toFixed(2), currency },
      paymentMethod,
      memo,
      metadata: { customerId: user.id, linkedAccountId: linked.id, source: 'SonoraPort AI Banking' },
    };
    await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.submission_requested', outcome: 'authorized', resourceId: paymentId, details: { amount: amount.toFixed(2), currency, paymentMethod, linkedAccountId: linked.id } });
    let data;
    try {
      data = await jpmorganRequest(configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions'), {
        method: 'POST', body: payload, idempotencyKey: paymentId, correlationId,
      });
      await updatePaymentReservation(paymentId, 'submitted', cleanText(data?.id || data?.paymentId || data?.transactionId, 180));
      await markBeneficiaryUsed(beneficiary.id).catch(() => null);
    } catch (providerError) {
      await updatePaymentReservation(paymentId, 'released').catch(() => null);
      await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.funds_released', outcome: 'provider_submission_failed', resourceId: paymentId, details: { code: providerError?.code || 'PROVIDER_ERROR' } });
      throw providerError;
    }
    await appendAuditEvent({ correlationId, actorProfileId: user.id, actorEmail: user.email, action: 'payment.provider_submitted', outcome: 'submitted', resourceId: paymentId, details: { providerPaymentId: cleanText(data?.id || data?.paymentId || data?.transactionId, 180), providerStatus: cleanText(data?.status, 80), riskScore: risk.score } });
    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
      body: JSON.stringify({ provider: 'J.P. Morgan', payment: data, risk: { score: risk.score, reasons: risk.reasons }, correlationId }),
    };
  } catch (error) { return serverError(error, correlationId); }
}
