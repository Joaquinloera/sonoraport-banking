import { cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const transitions = {
  submitted: new Set(['under_review','rejected','canceled']),
  under_review: new Set(['approved','rejected','canceled']),
  approved: new Set(['provider_submitted','canceled']),
  provider_submitted: new Set(['completed','failed']),
  completed: new Set(), rejected: new Set(), failed: new Set(), canceled: new Set(),
};
function isAdmin(email) {
  const allowed = String(process.env.JPMORGAN_REFUND_ADMIN_EMAILS || process.env.JPMORGAN_DISPUTE_ADMIN_EMAILS || '')
    .split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
  return allowed.includes(String(email || '').toLowerCase());
}
function db() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Refund administration database configuration is missing.'), { status: 503, code: 'REFUND_ADMIN_DATABASE_MISSING' });
  return { base, headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Accept: 'application/json' } };
}
async function getOne(id) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: '*', id: `eq.${id}`, limit: '1' });
  const r = await fetch(`${base}/rest/v1/payment_refund_requests?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to load refund request.'), { status: r.status, code: 'REFUND_ADMIN_LOOKUP_FAILED' });
  return rows?.[0] || null;
}
async function list(status) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: 'id,profile_id,payment_id,dispute_id,request_type,requested_amount,currency,reason_code,customer_note,status,provider_request_id,provider_status,provider_reference,failure_reason,reviewed_by,approved_by,created_at,updated_at,completed_at', order: 'created_at.desc', limit: '200' });
  if (status) q.set('status', `eq.${status}`);
  const r = await fetch(`${base}/rest/v1/payment_refund_requests?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to load refund requests.'), { status: r.status, code: 'REFUND_ADMIN_QUERY_FAILED' });
  return rows;
}
async function rpc(name, body) {
  const { base, headers } = db();
  const r = await fetch(`${base}/rest/v1/rpc/${name}`, { method: 'POST', headers, body: JSON.stringify(body) });
  const data = await r.json().catch(() => null);
  if (!r.ok) throw Object.assign(new Error(data?.message || 'Refund ledger update failed.'), { status: r.status, code: 'REFUND_LEDGER_FAILED' });
  return data;
}
export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','PATCH'].includes(event.httpMethod)) return methodNotAllowed(['GET','PATCH']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to administer refunds.', 'AUTH_REQUIRED', correlationId);
    if (!isAdmin(user.email)) return json(403, { error: 'Refund administrator access is required.', code: 'REFUND_ADMIN_REQUIRED', correlationId });
    if (event.httpMethod === 'GET') {
      const status = cleanText(event.queryStringParameters?.status, 40);
      if (status && !Object.hasOwn(transitions, status)) return json(400, { error: 'Invalid refund status.', code: 'INVALID_REFUND_STATUS', correlationId });
      const refunds = await list(status);
      return json(200, { refunds, count: refunds.length, correlationId }, { 'cache-control': 'no-store' });
    }
    const body = await readJson(event);
    const refundRequestId = cleanText(body?.refundRequestId, 80);
    const status = cleanText(body?.status, 40);
    const providerRequestId = cleanText(body?.providerRequestId, 160);
    const providerStatus = cleanText(body?.providerStatus, 100);
    const providerReference = cleanText(body?.providerReference, 160);
    const failureReason = cleanText(body?.failureReason, 500);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(refundRequestId)) return json(400, { error: 'A valid refund request ID is required.', code: 'INVALID_REFUND_REQUEST_ID', correlationId });
    const existing = await getOne(refundRequestId);
    if (!existing) return json(404, { error: 'Refund request not found.', code: 'REFUND_NOT_FOUND', correlationId });
    if (!Object.hasOwn(transitions, status) || !transitions[existing.status]?.has(status)) return json(409, { error: `Cannot move a refund from ${existing.status} to ${status}.`, code: 'INVALID_REFUND_TRANSITION', correlationId });
    if (status === 'provider_submitted' && !providerRequestId) return json(400, { error: 'Provider request ID is required.', code: 'PROVIDER_REQUEST_ID_REQUIRED', correlationId });
    if (status === 'failed' && failureReason.length < 5) return json(400, { error: 'A failure reason is required.', code: 'FAILURE_REASON_REQUIRED', correlationId });
    const now = new Date().toISOString();
    const patch = { status, updated_at: now, reviewed_by: user.id, reviewed_at: now,
      ...(status === 'approved' ? { approved_by: user.id, approved_at: now } : {}),
      ...(status === 'provider_submitted' ? { provider_request_id: providerRequestId, provider_submitted_at: now } : {}),
      ...(providerStatus ? { provider_status: providerStatus } : {}),
      ...(providerReference ? { provider_reference: providerReference } : {}),
      ...(failureReason ? { failure_reason: failureReason } : {}) };
    const { base, headers } = db();
    const r = await fetch(`${base}/rest/v1/payment_refund_requests?id=eq.${encodeURIComponent(refundRequestId)}`, { method: 'PATCH', headers: { ...headers, Prefer: 'return=representation' }, body: JSON.stringify(patch) });
    const rows = await r.json().catch(() => null);
    if (!r.ok) throw Object.assign(new Error(rows?.message || 'Unable to update refund request.'), { status: r.status, code: 'REFUND_ADMIN_UPDATE_FAILED' });
    let ledger = null;
    if (['completed','failed','rejected'].includes(status)) ledger = await rpc('finalize_refund_ledger', { p_refund_request_id: refundRequestId, p_outcome: status, p_provider_status: providerStatus || null, p_provider_reference: providerReference || null, p_failure_reason: failureReason || null, p_correlation_id: correlationId });
    await appendAuditEvent({ correlationId, actorUserId: user.id, action: 'payment.refund_admin_updated', outcome: status, resourceId: refundRequestId, details: { previousStatus: existing.status, newStatus: status, providerRequestId: providerRequestId || null, providerReference: providerReference || null } });
    return json(200, { refund: rows?.[0] || rows, ledger, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) { return serverError(error, correlationId); }
}
