import crypto from 'node:crypto';
import { getBearer,getSupabaseUser,json,methodNotAllowed,readJson,requestId,serverError,unauthorized,cleanText } from './lib/shared.mjs';
import { getOperatorRoles } from './lib/operator-access.mjs';
import { authAssurance,deviceIdFromEvent,hashDeviceId,recordSecurityEvent,validateDeviceId } from './lib/operator-session.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

function db(){const base=String(process.env.SUPABASE_URL||'').replace(/\/$/,'');const key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!base||!key)throw Object.assign(new Error('Operator security database configuration is missing.'),{status:503,code:'OPERATOR_SECURITY_DATABASE_MISSING'});return{base,headers:{Authorization:`Bearer ${key}`,apikey:key,'content-type':'application/json',Accept:'application/json'}}}
function ip(event){return cleanText(event?.headers?.['x-nf-client-connection-ip']||event?.headers?.['x-forwarded-for']||'',120).split(',')[0].trim()}
function ua(event){return cleanText(event?.headers?.['user-agent']||'',500)}

export async function handler(event){
  const correlationId=requestId(event);
  if(!['GET','POST','DELETE'].includes(event.httpMethod))return methodNotAllowed(['GET','POST','DELETE']);
  try{
    const token=getBearer(event);const user=await getSupabaseUser(token);if(!user)return unauthorized('Sign in required.','AUTH_REQUIRED',correlationId);
    const roles=await getOperatorRoles(user);if(!roles.length)return json(403,{error:'Operator role required.',code:'OPERATOR_ROLE_REQUIRED',correlationId});
    const assurance=authAssurance(token);const rawDevice=deviceIdFromEvent(event);
    if(!validateDeviceId(rawDevice))return json(400,{error:'A valid x-sonoraport-device-id header is required.',code:'DEVICE_ID_INVALID',correlationId});
    const deviceHash=hashDeviceId(rawDevice);const {base,headers}=db();
    if(event.httpMethod==='GET'){
      const q=new URLSearchParams({select:'id,device_label,active,risk_state,created_at,last_seen_at,expires_at,revoked_at',user_id:`eq.${user.id}`,device_hash:`eq.${deviceHash}`,order:'created_at.desc',limit:'1'});
      const r=await fetch(`${base}/rest/v1/operator_secure_sessions?${q}`,{headers});const rows=await r.json().catch(()=>[]);if(!r.ok)throw Object.assign(new Error('Unable to load operator session.'),{status:r.status,code:'OPERATOR_SESSION_READ_FAILED'});
      return json(200,{mfaLevel:assurance.aal,session:rows[0]||null,roles,correlationId},{'cache-control':'no-store'});
    }
    if(event.httpMethod==='DELETE'){
      const r=await fetch(`${base}/rest/v1/operator_secure_sessions?user_id=eq.${user.id}&device_hash=eq.${deviceHash}&active=eq.true`,{method:'PATCH',headers:{...headers,Prefer:'return=representation'},body:JSON.stringify({active:false,revoked_at:new Date().toISOString(),revoked_reason:'operator_sign_out'})});
      const rows=await r.json().catch(()=>[]);if(!r.ok)throw Object.assign(new Error('Unable to revoke operator session.'),{status:r.status,code:'OPERATOR_SESSION_REVOKE_FAILED'});
      await recordSecurityEvent({userId:user.id,eventType:'operator.session_revoked',outcome:'success',deviceHash,ip:ip(event),userAgent:ua(event),details:{correlationId}});
      return json(200,{revoked:rows.length,correlationId});
    }
    if(assurance.aal!=='aal2'){
      await recordSecurityEvent({userId:user.id,eventType:'operator.session_create',outcome:'mfa_required',deviceHash,ip:ip(event),userAgent:ua(event),details:{correlationId,aal:assurance.aal}});
      return json(403,{error:'Complete multi-factor authentication before creating an operator session.',code:'OPERATOR_MFA_REQUIRED',correlationId});
    }
    const body=await readJson(event);const label=cleanText(body?.deviceLabel||'Registered device',100);const hours=Math.max(1,Math.min(12,Number(process.env.JPMORGAN_OPERATOR_SESSION_HOURS||4)));const expires=new Date(Date.now()+hours*3600000).toISOString();
    const sessionId=crypto.randomUUID();
    await fetch(`${base}/rest/v1/operator_secure_sessions?user_id=eq.${user.id}&device_hash=eq.${deviceHash}&active=eq.true`,{method:'PATCH',headers:{...headers,Prefer:'return=minimal'},body:JSON.stringify({active:false,revoked_at:new Date().toISOString(),revoked_reason:'replaced'})});
    const r=await fetch(`${base}/rest/v1/operator_secure_sessions`,{method:'POST',headers:{...headers,Prefer:'return=representation'},body:JSON.stringify({id:sessionId,user_id:user.id,device_hash:deviceHash,device_label:label,auth_aal:assurance.aal,auth_session_id:assurance.sessionId||null,ip_address:ip(event)||null,user_agent:ua(event)||null,active:true,risk_state:'normal',expires_at:expires,last_seen_at:new Date().toISOString()})});
    const rows=await r.json().catch(()=>[]);if(!r.ok)throw Object.assign(new Error('Unable to create secure operator session.'),{status:r.status,code:'OPERATOR_SESSION_CREATE_FAILED'});
    await recordSecurityEvent({userId:user.id,eventType:'operator.session_created',outcome:'success',deviceHash,ip:ip(event),userAgent:ua(event),details:{correlationId,expiresAt:expires,roles}});
    await appendAuditEvent({correlationId,actorUserId:user.id,actorEmail:user.email,action:'operator.secure_session_created',outcome:'active',resourceId:sessionId,details:{deviceLabel:label,expiresAt:expires,aal:assurance.aal}});
    return json(201,{session:rows[0]||{id:sessionId,expires_at:expires},roles,correlationId});
  }catch(e){return serverError(e,correlationId)}
}
