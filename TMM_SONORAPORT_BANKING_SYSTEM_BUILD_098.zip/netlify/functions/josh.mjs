import crypto from 'node:crypto';
import { cleanText, json, methodNotAllowed, readJson, requestId, serverError } from './lib/shared.mjs';

const MAX_MESSAGE_LENGTH = 4000;
const MAX_HISTORY_MESSAGES = 10;
const OPENAI_URL = 'https://api.openai.com/v1/responses';

function allowedOrigin(event = {}) {
  const configured = String(process.env.SITE_URL || process.env.URL || '').replace(/\/$/, '');
  const origin = String(event.headers?.origin || '').replace(/\/$/, '');
  if (!origin || !configured) return true;
  try {
    return new URL(origin).host === new URL(configured).host;
  } catch {
    return false;
  }
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 25000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === 'AbortError') {
      const timeoutError = new Error('Josh AI request timed out.');
      timeoutError.status = 504;
      timeoutError.code = 'JOSH_TIMEOUT';
      throw timeoutError;
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function extractOutputText(payload = {}) {
  if (typeof payload.output_text === 'string' && payload.output_text.trim()) return payload.output_text.trim();
  for (const item of Array.isArray(payload.output) ? payload.output : []) {
    for (const part of Array.isArray(item?.content) ? item.content : []) {
      if (typeof part?.text === 'string' && part.text.trim()) return part.text.trim();
    }
  }
  return '';
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);
  if (!allowedOrigin(event)) return json(403, { error: 'Request origin is not allowed.', code: 'ORIGIN_FORBIDDEN', correlationId });

  try {
    const body = await readJson(event);
    const message = cleanText(body.message, MAX_MESSAGE_LENGTH);
    if (!message) return json(400, { error: 'Enter a message.', code: 'MESSAGE_REQUIRED', correlationId });

    const apiKey = String(process.env.OPENAI_API_KEY || '').trim();
    const placeholderKey = /^(your\s+new\s+openai\s+api\s+key|replace[_ -]?me|changeme|placeholder)$/i.test(apiKey);
    if (!apiKey || placeholderKey) {
      return json(503, {
        error: placeholderKey ? 'The OPENAI_API_KEY value is placeholder text. Replace it in Netlify with a real OpenAI API key.' : 'Josh AI is not configured on the server.',
        code: 'OPENAI_NOT_CONFIGURED',
        correlationId,
      });
    }

    const model = cleanText(process.env.OPENAI_MODEL || 'gpt-5-mini', 100);
    const history = (Array.isArray(body.history) ? body.history : [])
      .slice(-MAX_HISTORY_MESSAGES)
      .map((item) => ({
        role: item?.role === 'assistant' ? 'assistant' : 'user',
        content: [{ type: item?.role === 'assistant' ? 'output_text' : 'input_text', text: cleanText(item?.text, 2000) }],
      }))
      .filter((item) => item.content[0].text);
    const response = await fetchWithTimeout(OPENAI_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'X-Client-Request-Id': correlationId,
      },
      body: JSON.stringify({
        model,
        store: false,
        max_output_tokens: Math.min(1200, Math.max(100, Number(process.env.OPENAI_MAX_OUTPUT_TOKENS) || 500)),
        input: [
          {
            role: 'system',
            content: [{
              type: 'input_text',
              text: 'You are Josh, the secure website concierge and coding assistant for SonoraPort AI Banking, a division of SonoraPort AI Holding LLC. Help users navigate the website, understand application workflows, and explain technical features. Never request or expose passwords, access tokens, API keys, full card numbers, full bank-account numbers, Social Security numbers, or identity documents. Never claim a payment succeeded unless the banking provider response confirms it.',
            }],
          },
          ...history,
          { role: 'user', content: [{ type: 'input_text', text: message }] },
        ],
      }),
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload?.error?.message || `OpenAI request failed (${response.status}).`);
      error.status = response.status === 429 ? 429 : 502;
      error.code = response.status === 429 ? 'OPENAI_RATE_LIMITED' : 'OPENAI_REQUEST_FAILED';
      throw error;
    }

    const reply = extractOutputText(payload);
    if (!reply) {
      const error = new Error('OpenAI returned no usable response.');
      error.status = 502;
      error.code = 'OPENAI_EMPTY_RESPONSE';
      throw error;
    }

    return json(200, { reply, model, correlationId }, { 'X-Correlation-ID': correlationId });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
