import { getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { getLatestCertificationForProfile } from './lib/certification-store.mjs';

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before checking payment certification.', 'AUTH_REQUIRED', correlationId);
    const record = await getLatestCertificationForProfile(user.id);
    if (!record) return ok({ certification: null, correlationId });
    return ok({ certification: {
      status: record.status,
      externalPaymentId: record.external_payment_id,
      providerPaymentId: record.provider_payment_id || null,
      callbackEventId: record.callback_event_id || null,
      callbackReceivedAt: record.callback_received_at || null,
      amount: record.amount,
      currency: record.currency,
      paymentMethod: record.payment_method,
      createdAt: record.created_at,
      updatedAt: record.updated_at,
      providerStatus: record.provider_status || null,
      reconciliationStatus: record.reconciliation_status || 'not_checked',
      reconciliationCheckedAt: record.reconciliation_checked_at || null,
      settledAt: record.settled_at || null,
    }, correlationId });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
