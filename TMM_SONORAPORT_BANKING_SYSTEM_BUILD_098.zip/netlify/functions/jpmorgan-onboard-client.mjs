import {
  badRequest,
  cleanText,
  getBearer,
  getSupabaseUser,
  methodNotAllowed,
  readJson,
  serverError,
  unauthorized,
  upsertProviderAccountServer,
  requestId,
} from './lib/shared.mjs';
import { configuredPath, jpmorganRequest } from './lib/jpmorgan.mjs';

function firstText(value, keys) {
  for (const key of keys) {
    const candidate = value?.[key];
    if (typeof candidate === 'string' && candidate.trim()) return candidate.trim();
  }
  return '';
}

function findAccountRecord(data) {
  const candidates = [
    data?.account,
    data?.depositAccount,
    data?.client?.account,
    data?.accounts?.[0],
    data?.depositAccounts?.[0],
    data,
  ];
  return candidates.find((item) => item && typeof item === 'object') || {};
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'POST') return methodNotAllowed(['POST']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Sign in before starting provider onboarding.', 'AUTH_REQUIRED', correlationId);

    const body = await readJson(event);
    if (!body.legalName || !body.entityType || !body.country) {
      return badRequest('Legal name, entity type, and country are required.', 'ONBOARDING_FIELDS_REQUIRED', correlationId);
    }

    const payload = {
      externalClientId: user.id,
      legalName: cleanText(body.legalName, 180),
      entityType: cleanText(body.entityType, 80),
      country: cleanText(body.country, 2).toUpperCase(),
      email: cleanText(body.email || user.email, 320),
      businessDescription: cleanText(body.businessDescription, 2000),
      metadata: { source: 'SonoraPort AI Banking' },
    };

    const data = await jpmorganRequest(configuredPath('JPMORGAN_ONBOARD_CLIENT_PATH', '/clients'), {
      method: 'POST',
      body: payload,
      idempotencyKey: `onboard-${user.id}`,
      correlationId,
    });

    const account = findAccountRecord(data);
    const providerAccountId = firstText(account, ['accountId', 'id', 'depositAccountId', 'providerAccountId']);
    const providerClientId = firstText(data, ['clientId', 'id', 'partyId', 'providerClientId']);
    let linkedAccount = null;

    // Only create a usable provider link when JPMorgan returns a concrete account identifier.
    if (providerAccountId) {
      linkedAccount = await upsertProviderAccountServer({
        profile_id: user.id,
        provider: 'jpmorgan',
        provider_client_id: cleanText(providerClientId, 180) || null,
        provider_account_id: cleanText(providerAccountId, 180),
        account_type: cleanText(firstText(account, ['accountType', 'type', 'productType']), 80) || null,
        display_name: cleanText(firstText(account, ['displayName', 'name', 'accountName']), 120) || 'J.P. Morgan account',
        last4: cleanText(firstText(account, ['last4', 'accountNumberLast4']), 4) || null,
        status: 'active',
        metadata: {
          onboardingStatus: firstText(data, ['status', 'onboardingStatus']) || 'submitted',
          source: 'jpmorgan-onboard-client',
        },
      });
    }

    return {
      statusCode: 201,
      headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
      body: JSON.stringify({
        provider: 'J.P. Morgan',
        onboarding: data,
        linkedAccount: linkedAccount
          ? { id: linkedAccount.id, status: linkedAccount.status, last4: linkedAccount.last4 }
          : null,
        linkStatus: providerAccountId ? 'linked' : 'awaiting-provider-account',
        correlationId,
      }),
    };
  } catch (error) {
    return serverError(error, correlationId);
  }
}
