import { getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';

async function loadHistory(profileId, limit) {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Transaction history database configuration is missing.'), { status: 503, code: 'HISTORY_DATABASE_MISSING' });
  const params = new URLSearchParams({
    select: 'payment_id,provider_account_link_id,amount,currency,status,provider_status,provider_payment_id,correlation_id,created_at,updated_at,settled_at,released_at,failure_reason',
    profile_id: `eq.${profileId}`,
    order: 'created_at.desc',
    limit: String(limit),
  });
  const response = await fetch(`${base}/rest/v1/customer_transaction_history?${params}`, {
    headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' },
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) throw Object.assign(new Error(data?.message || 'Unable to load transaction history.'), { status: response.status, code: 'HISTORY_QUERY_FAILED' });
  return Array.isArray(data) ? data : [];
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to view transaction history.', 'AUTH_REQUIRED', correlationId);
    const requested = Number(event.queryStringParameters?.limit || 50);
    const limit = Math.min(100, Math.max(1, Number.isFinite(requested) ? Math.trunc(requested) : 50));
    const transactions = await loadHistory(user.id, limit);
    return ok({ transactions, count: transactions.length, correlationId });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
