import crypto from 'node:crypto';
import {cleanText,getBearer,getSupabaseUser,json,methodNotAllowed,readJson,requestId,serverError,unauthorized} from './lib/shared.mjs';
import {dbRest} from './lib/card-store.mjs';
const productMap={
  'checking account':'checking','savings account':'savings','personal loan':'personal_loan',
  'business account':'business','commercial banking':'commercial_banking'
};
export async function handler(event){
  const cid=requestId(event); if(!['GET','POST'].includes(event.httpMethod))return methodNotAllowed(['GET','POST']);
  try{
    const user=await getSupabaseUser(getBearer(event)); if(!user)return unauthorized('Sign in to manage applications.','AUTH_REQUIRED',cid);
    if(event.httpMethod==='GET'){
      const rows=await dbRest(`bank_account_applications?user_id=eq.${encodeURIComponent(user.id)}&select=id,account_name,account_type,legal_name,status,decision_note,created_at,updated_at,reviewed_at&order=created_at.desc`);
      return json(200,{applications:rows||[],correlationId:cid});
    }
    const b=await readJson(event); const title=cleanText(b.title,80); const accountType=productMap[title.toLowerCase()]||cleanText(b.accountType,60).toLowerCase();
    if(!accountType)return json(400,{error:'Application product is required.',code:'APPLICATION_PRODUCT_REQUIRED',correlationId:cid});
    const legalName=cleanText(b.legalName||user.user_metadata?.full_name||user.email,160);
    const row={user_id:user.id,account_name:title||accountType,account_type:accountType==='commercial_banking'?'business':accountType, currency:'USD',legal_name:legalName,phone:cleanText(user.phone,60)||null,company:cleanText(b.company,160)||null,status:'submitted'};
    if(!['checking','savings','business'].includes(row.account_type))return json(400,{error:'Use the dedicated product application for this request.',code:'APPLICATION_PRODUCT_ROUTE_REQUIRED',correlationId:cid});
    const saved=await dbRest('bank_account_applications',{method:'POST',body:JSON.stringify(row)});
    return json(201,{application:saved?.[0]||saved,correlationId:cid});
  }catch(e){return serverError(e,cid)}
}
