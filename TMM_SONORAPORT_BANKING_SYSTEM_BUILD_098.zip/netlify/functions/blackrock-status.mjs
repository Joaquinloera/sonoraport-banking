import { ok } from './lib/shared.mjs';

export async function handler() {
  return ok({
    enabled: process.env.ENABLE_BLACKROCK === 'true',
    relationshipStatus: process.env.BLACKROCK_RELATIONSHIP_STATUS || 'Not contracted',
    environment: process.env.BLACKROCK_ENVIRONMENT || 'sandbox',
    product: process.env.BLACKROCK_PRODUCT || 'Aladdin Studio',
    configured: Boolean(
      process.env.BLACKROCK_API_BASE_URL &&
      process.env.BLACKROCK_CLIENT_ID &&
      process.env.BLACKROCK_TOKEN_URL
    ),
    capabilities: {
      portfolioData: Boolean(process.env.BLACKROCK_PORTFOLIO_PATH),
      riskAnalytics: Boolean(process.env.BLACKROCK_RISK_PATH),
      holdings: Boolean(process.env.BLACKROCK_HOLDINGS_PATH),
    },
  });
}
