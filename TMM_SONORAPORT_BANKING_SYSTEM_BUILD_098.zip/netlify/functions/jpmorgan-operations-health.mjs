import { getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { paymentOperationsState } from './lib/operations-control.mjs';
import { envValue, paymentApiPath, validApiPath } from './lib/jpmorgan.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

const has = (name) => Boolean(envValue(name));
const isTrue = (value) => String(value || '').trim().toLowerCase() === 'true';
const onlinePaymentsMode = () => ['online_payments','online-payments','onlinepayments','cards']
  .includes(String(envValue('JPMORGAN_PRODUCT_MODE') || 'online_payments').trim().toLowerCase());

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Administrator authentication required for operations health.', 'AUTH_REQUIRED', correlationId);
    await requireAdminAuthority(user);

    const state = paymentOperationsState();
    const onlinePayments = onlinePaymentsMode();
    const productChecks = onlinePayments ? {
      onlinePaymentsBaseUrlConfigured: has('JPMORGAN_API_BASE_URL'),
      onlinePaymentsPathConfigured: validApiPath(paymentApiPath()),
      onlinePaymentsScopeConfigured: has('JPMORGAN_SCOPE'),
    } : {
      verificationAccountConfigured: has('JPMORGAN_VERIFICATION_ACCOUNT_ID'),
      configurationIdConfigured: has('JPMORGAN_CONFIGURATION_ID'),
    };

    const checks = {
      providerEnabled: state.providerEnabled,
      paymentOperationsEnabled: state.operationsEnabled,
      emergencyStopInactive: !state.emergencyStop,
      cutoverApprovedForEnvironment: state.cutoverApproved,
      credentialsConfigured: has('JPMORGAN_CLIENT_ID') && has('JPMORGAN_CLIENT_SECRET'),
      tokenEndpointConfigured: has('JPMORGAN_TOKEN_URL') || has('JPM_TOKEN_URL') || (has('JPMORGAN_API_BASE_URL') && has('JPMORGAN_TOKEN_PATH')),
      ...productChecks,
      callbackVerificationConfigured: isTrue(envValue('ENABLE_JPMORGAN_CALLBACKS')) && has('JPMORGAN_CALLBACK_HMAC_SECRET'),
      transactionStatusConfigured: has('JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE'),
    };
    const failedChecks = Object.entries(checks).filter(([, passed]) => !passed).map(([name]) => name);
    const healthy = failedChecks.length === 0 && state.paymentsAllowed;
    const blockers = [...new Set([...state.blockers, ...failedChecks])];
    const coreChecks = {
      providerEnabled: checks.providerEnabled,
      emergencyStopInactive: checks.emergencyStopInactive,
      credentialsConfigured: checks.credentialsConfigured,
      tokenEndpointConfigured: checks.tokenEndpointConfigured,
      ...productChecks,
    };
    const coreBlockers = Object.entries(coreChecks).filter(([, passed]) => !passed).map(([name]) => name);
    const coreHealthy = coreBlockers.length === 0;

    return ok({
      healthy,
      coreHealthy,
      coreBlockers,
      paymentsAllowed: state.paymentsAllowed && failedChecks.length === 0,
      environment: state.environment,
      productMode: onlinePayments ? 'online_payments' : 'embedded_payments',
      checks,
      blockers,
      emergencyStop: state.emergencyStop,
      signedInProfileAvailable: Boolean(user),
      authRequiredForLiveOperations: false,
      checkedAt: new Date().toISOString(),
      message: healthy
        ? 'Operations controls are healthy and payment submission is unlocked.'
        : `Payment submission remains locked. Remaining blockers: ${blockers.join(', ') || 'none'}.`,
      correlationId,
    });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
