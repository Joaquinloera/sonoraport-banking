import { getBearer, getSupabaseUser, methodNotAllowed, ok, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { getLatestCertificationForProfile } from './lib/certification-store.mjs';
import { envValue, paymentApiPath, validApiPath } from './lib/jpmorgan.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

const isTrue = (v) => String(v || '').trim().toLowerCase() === 'true';
const has = (n) => Boolean(envValue(n));
const onlinePaymentsMode = () => ['online_payments','online-payments','onlinepayments','cards']
  .includes(String(envValue('JPMORGAN_PRODUCT_MODE') || 'online_payments').trim().toLowerCase());

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const token = getBearer(event);
    const user = await getSupabaseUser(token);
    if (!user) return unauthorized('Administrator authentication required for production readiness.', 'AUTH_REQUIRED', correlationId);
    await requireAdminAuthority(user);
    const certification = user ? await getLatestCertificationForProfile(user.id) : null;
    const environment = String(envValue('JPMORGAN_ENVIRONMENT') || '').trim().toLowerCase();
    const onlinePayments = onlinePaymentsMode();
    const productChecks = onlinePayments ? {
      onlinePaymentsBaseUrlConfigured: has('JPMORGAN_API_BASE_URL'),
      onlinePaymentsPathConfigured: validApiPath(paymentApiPath()),
      onlinePaymentsScopeConfigured: has('JPMORGAN_SCOPE'),
    } : {
      verificationAccountConfigured: has('JPMORGAN_VERIFICATION_ACCOUNT_ID'),
      configurationIdConfigured: has('JPMORGAN_CONFIGURATION_ID'),
    };

    const checks = {
      providerEnabled: isTrue(envValue('ENABLE_JPMORGAN')),
      environmentSelected: Boolean(environment),
      productionCutoverApproved: isTrue(envValue('JPMORGAN_PRODUCTION_CUTOVER_APPROVED')),
      credentialsConfigured: has('JPMORGAN_CLIENT_ID') && has('JPMORGAN_CLIENT_SECRET'),
      tokenEndpointConfigured: has('JPMORGAN_TOKEN_URL') || has('JPM_TOKEN_URL') || (has('JPMORGAN_API_BASE_URL') && has('JPMORGAN_TOKEN_PATH')),
      ...productChecks,
      callbackSecurityConfigured: isTrue(envValue('ENABLE_JPMORGAN_CALLBACKS')) && has('JPMORGAN_CALLBACK_VERIFICATION_MODE') && has('JPMORGAN_CALLBACK_HMAC_SECRET'),
      transactionStatusPathConfigured: has('JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE'),
      signedInProfileAvailable: Boolean(user),
      certificationExists: Boolean(certification),
      controlledCertificationSettled: certification?.reconciliation_status === 'settled' && Boolean(certification?.settled_at),
      certificationCallbackVerified: Boolean(certification?.callback_received_at),
    };

    const blockers = Object.entries(checks).filter(([, passed]) => !passed).map(([name]) => name);
    const ready = blockers.length === 0;
    const codeChecks = {
      providerEnabled: checks.providerEnabled,
      environmentSelected: checks.environmentSelected,
      credentialsConfigured: checks.credentialsConfigured,
      tokenEndpointConfigured: checks.tokenEndpointConfigured,
      ...productChecks,
    };
    const codeBlockers = Object.entries(codeChecks).filter(([, passed]) => !passed).map(([name]) => name);
    const coreReady = codeBlockers.length === 0;

    return ok({
      ready,
      coreReady,
      codeBlockers,
      locked: !ready,
      environment: environment || 'not configured',
      productMode: onlinePayments ? 'online_payments' : 'embedded_payments',
      checks,
      blockers,
      authRequiredForFinalCutover: false,
      certification: certification ? {
        status: certification.status,
        reconciliationStatus: certification.reconciliation_status || 'not_checked',
        providerStatus: certification.provider_status || null,
        callbackReceivedAt: certification.callback_received_at || null,
        settledAt: certification.settled_at || null,
      } : null,
      message: ready
        ? 'All configured cutover gates passed.'
        : `Cutover remains locked. Remaining blockers: ${blockers.join(', ') || 'none'}.`,
      correlationId,
    });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
