import crypto from 'node:crypto';
import { getBearer, getSupabaseUser, json, methodNotAllowed, requestId, serverError, unauthorized } from './lib/shared.mjs';

function monthRange(value) {
  const match = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(String(value || ''));
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const start = new Date(Date.UTC(year, month - 1, 1));
  const end = new Date(Date.UTC(year, month, 1));
  return { label: `${match[1]}-${match[2]}`, start: start.toISOString(), end: end.toISOString() };
}

async function queryTransactions(profileId, range) {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Statement database configuration is missing.'), { status: 503, code: 'STATEMENT_DATABASE_MISSING' });
  const params = new URLSearchParams({
    select: 'payment_id,provider_account_link_id,amount,currency,status,provider_status,provider_payment_id,correlation_id,created_at,settled_at,released_at,failure_reason',
    profile_id: `eq.${profileId}`,
    created_at: `gte.${range.start}`,
    order: 'created_at.asc',
  });
  const url = `${base}/rest/v1/customer_statement_transactions?${params.toString()}&created_at=lt.${encodeURIComponent(range.end)}`;
  const response = await fetch(url, { headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' } });
  const data = await response.json().catch(() => null);
  if (!response.ok) throw Object.assign(new Error(data?.message || 'Unable to generate statement.'), { status: response.status, code: 'STATEMENT_QUERY_FAILED' });
  return Array.isArray(data) ? data : [];
}

function summarize(rows) {
  const totals = {};
  for (const row of rows) {
    const currency = String(row.currency || 'USD').toUpperCase();
    totals[currency] ||= { count: 0, settled: 0, failed: 0, pending: 0 };
    totals[currency].count += 1;
    const amount = Number(row.amount || 0);
    if (row.status === 'settled') totals[currency].settled += amount;
    else if (['failed', 'released'].includes(row.status)) totals[currency].failed += amount;
    else totals[currency].pending += amount;
  }
  return totals;
}

function csvCell(value) {
  const text = value == null ? '' : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

function toCsv(rows) {
  const columns = ['payment_id','created_at','amount','currency','status','provider_status','provider_payment_id','settled_at','released_at','failure_reason'];
  return [columns.join(','), ...rows.map((row) => columns.map((key) => csvCell(row[key])).join(','))].join('\n');
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to download a statement.', 'AUTH_REQUIRED', correlationId);
    const now = new Date();
    const defaultMonth = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
    const range = monthRange(event.queryStringParameters?.month || defaultMonth);
    if (!range) return json(400, { error: 'Month must use YYYY-MM format.', code: 'INVALID_STATEMENT_MONTH', correlationId });
    const rows = await queryTransactions(user.id, range);
    const statementId = crypto.createHash('sha256').update(`${user.id}|${range.label}|${JSON.stringify(rows)}`).digest('hex');
    const format = String(event.queryStringParameters?.format || 'json').toLowerCase();
    if (format === 'csv') {
      return {
        statusCode: 200,
        headers: {
          'content-type': 'text/csv; charset=utf-8',
          'content-disposition': `attachment; filename="sonoraport-statement-${range.label}.csv"`,
          'cache-control': 'no-store',
          'x-content-type-options': 'nosniff',
        },
        body: toCsv(rows),
      };
    }
    return json(200, { statementId, month: range.label, generatedAt: new Date().toISOString(), totals: summarize(rows), transactions: rows, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
