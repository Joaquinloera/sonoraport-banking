import crypto from 'node:crypto';
import { badRequest, cleanText, getBearer, getSupabaseUser, json, methodNotAllowed, readJson, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';

const TYPES = new Set(['ach','wire','internal','other']);
function db() {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Beneficiary database configuration is missing.'), { status: 503, code: 'BENEFICIARY_DATABASE_MISSING' });
  return { base, headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Accept: 'application/json' } };
}
function blockedCountries() {
  return new Set(String(process.env.JPMORGAN_BLOCKED_BENEFICIARY_COUNTRIES || '').split(',').map(v => v.trim().toUpperCase()).filter(Boolean));
}
function riskFor({ type, countryCode }) {
  const reasons = [];
  let score = 0;
  if (type === 'wire') { score += 25; reasons.push('wire_destination'); }
  if (countryCode !== 'US') { score += 35; reasons.push('cross_border_destination'); }
  return { score: Math.min(score, 100), reasons };
}
async function list(profileId) {
  const { base, headers } = db();
  const q = new URLSearchParams({ select: 'id,display_name,destination_type,country_code,currency,status,risk_score,risk_reasons,approved_at,activates_at,last_used_at,created_at,updated_at', profile_id: `eq.${profileId}`, order: 'created_at.desc', limit: '200' });
  const r = await fetch(`${base}/rest/v1/payment_beneficiaries?${q}`, { headers });
  const rows = await r.json().catch(() => []);
  if (!r.ok) throw Object.assign(new Error('Unable to load beneficiaries.'), { status: r.status, code: 'BENEFICIARY_QUERY_FAILED' });
  return rows;
}
export async function handler(event) {
  const correlationId = requestId(event);
  if (!['GET','POST'].includes(event.httpMethod)) return methodNotAllowed(['GET','POST']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to manage beneficiaries.', 'AUTH_REQUIRED', correlationId);
    if (event.httpMethod === 'GET') return json(200, { beneficiaries: await list(user.id), correlationId }, { 'cache-control': 'no-store' });

    const body = await readJson(event);
    const displayName = cleanText(body?.displayName, 100);
    const destinationType = cleanText(body?.destinationType, 20).toLowerCase();
    const providerDestinationId = cleanText(body?.providerDestinationId, 180);
    const countryCode = cleanText(body?.countryCode || 'US', 2).toUpperCase();
    const currency = cleanText(body?.currency || 'USD', 3).toUpperCase();
    if (displayName.length < 2 || !TYPES.has(destinationType) || !providerDestinationId || !/^[A-Z]{2}$/.test(countryCode) || !/^[A-Z]{3}$/.test(currency)) {
      return badRequest('Valid beneficiary name, type, destination, country, and currency are required.', 'BENEFICIARY_FIELDS_INVALID', correlationId);
    }
    if (blockedCountries().has(countryCode)) return badRequest('This beneficiary country is blocked by policy.', 'BENEFICIARY_COUNTRY_BLOCKED', correlationId);

    const risk = riskFor({ type: destinationType, countryCode });
    const id = crypto.randomUUID();
    const { base, headers } = db();
    const r = await fetch(`${base}/rest/v1/payment_beneficiaries`, {
      method: 'POST', headers: { ...headers, Prefer: 'return=representation' },
      body: JSON.stringify({ id, profile_id: user.id, display_name: displayName, destination_type: destinationType, provider_destination_id: providerDestinationId, country_code: countryCode, currency, status: 'pending_review', risk_score: risk.score, risk_reasons: risk.reasons, created_by: user.id, correlation_id: correlationId }),
    });
    const rows = await r.json().catch(() => null);
    if (r.status === 409) return json(409, { error: 'This beneficiary already exists.', code: 'BENEFICIARY_ALREADY_EXISTS', correlationId });
    if (!r.ok) throw Object.assign(new Error(rows?.message || 'Unable to create beneficiary.'), { status: r.status, code: 'BENEFICIARY_CREATE_FAILED' });
    const beneficiary = rows?.[0] || rows;
    await fetch(`${base}/rest/v1/payment_beneficiary_events`, { method: 'POST', headers, body: JSON.stringify({ beneficiary_id: id, profile_id: user.id, actor_user_id: user.id, event_type: 'beneficiary.created', new_status: 'pending_review', details: { destinationType, countryCode, currency, risk }, correlation_id: correlationId }) });
    await appendAuditEvent({ correlationId, actorUserId: user.id, actorEmail: user.email, action: 'beneficiary.created', outcome: 'pending_review', resourceId: id, details: { destinationType, countryCode, currency, riskScore: risk.score, reasons: risk.reasons } });
    return json(201, { beneficiary, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) { return serverError(error, correlationId); }
}
