# Build 064 — Funded Visa Debit Transaction Lifecycle

Build 064 continues directly from verified Build 063 and does not redesign the site.

## Added
- Explicit provider-account → customer account linkage for debit funding source resolution.
- Visa Debit-only USD transaction webhook lifecycle: authorization, decline, capture, reversal.
- Atomic idempotency at lifecycle application level using provider + provider event ID.
- Authorization holds reduce available balance only; settled/current balance is unchanged.
- Capture releases the authorization hold, reduces settled balance by captured amount, and releases any excess authorization.
- Reversal releases the open authorization hold without changing settled balance.
- Balanced double-entry journals for authorization holds, capture, and reversal.
- Provider event, transaction, card, authorization/capture/reversal reference, and correlation IDs retained for reconciliation.
- Reconciliation exceptions for missing funded-account linkage, missing holds, account mismatch, currency mismatch, and over-capture.

## Preserved
- Build 063 `/api/funding/webhook`, HMAC verification, funding idempotency, USD funding/reversal logic.
- Build 062 card issuer continuity and `/api/cards/issuance`.
- Visa Credit and Mastercard Credit remain unchanged for later lifecycle builds.

## Deployment dependency
Apply `supabase/SONORAPORT-V29-VISA-DEBIT-FUNDED-LIFECYCLE.sql` before routing provider Visa Debit transaction webhooks to the existing card transaction function. Existing provider-account records must have `linked_account_id` set to the same internal account referenced by the Visa Debit card; the lifecycle deliberately records a reconciliation exception instead of guessing a linkage.
