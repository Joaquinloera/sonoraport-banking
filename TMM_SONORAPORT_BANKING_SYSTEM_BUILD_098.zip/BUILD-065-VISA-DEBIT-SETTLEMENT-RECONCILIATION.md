# BUILD 065 — Visa Debit Settlement/Reconciliation Verification

Continues Build 064 without redesigning portal/authentication surfaces.

Adds a signed provider settlement webhook, idempotent settlement evidence, capture-to-settlement matching, USD/Visa Debit validation, provider settlement/reference/correlation retention, capture ledger balance/total verification, mismatch exceptions, and a balanced network-settlement journal. Customer settled/available balances are not debited again at network settlement; Build 064 capture remains the customer-balance event.

Stable route: `POST /api/cards/settlement/webhook`.
