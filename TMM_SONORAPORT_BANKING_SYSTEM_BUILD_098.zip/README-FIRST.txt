SONORAPORT AI BANKING — SINGLE UPLOAD PACKAGE

1. Upload this ZIP directly to the existing Netlify site's Deploys page.
2. Do not extract it before uploading.
3. The homepage is fully coded HTML/CSS/JavaScript; it is not a screenshot.
4. The Apply page supports direct links such as apply.html?type=personal-loan.
5. The client portal and Supabase support files are included.
6. Never place a Supabase secret/service-role key in browser code. Use only the publishable/anon key in the portal configuration.

Included homepage sections:
AI Banking, Personal Banking, Business Banking, Commercial Finance, Credit Cards,
Cryptocurrency, Precious Metals, Security, Client Portal, JoshGPT, and Online Applications.
