SONORAPORT AI BANKING — STABILIZED SANDBOX RELEASE
Date: July 30, 2026

PURPOSE
This package preserves the working consolidated sandbox banking build and adds a formal stabilization audit, deployment notes, security notes, and regression checklist.

DEPLOYMENT
1. Keep the current Supabase project and database unchanged.
2. Do not rerun the historical SQL files unless rebuilding a brand-new database.
3. Upload this ZIP directly to the existing Netlify site using Deploy manually.
4. Wait for Published.
5. Test using CUSTOMER-ADMIN-REGRESSION-CHECKLIST.txt.

VERIFIED STATIC CHECKS
- 50 HTML pages parsed.
- 14 JavaScript files passed syntax validation.
- 12 CSS files inventoried.
- 10 SQL migration/setup files inventoried.
- 1,483 local href/src/action references checked.
- No missing local references found.
- No duplicate HTML IDs found.
- No service-role keys, secret Supabase keys, private keys, or live payment secrets found.

IMPORTANT LIMITS
This is a sandbox application. It is not a chartered bank, payment processor, insured deposit institution, or production financial system. Sandbox balances and card/account identifiers must not be represented as real funds or real banking credentials.
