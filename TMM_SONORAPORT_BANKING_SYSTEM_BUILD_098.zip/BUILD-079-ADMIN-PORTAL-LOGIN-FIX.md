# BUILD 079 — Admin Portal Login Fix

- Removes the destructive repeated admin re-auth loop.
- Preserves the authenticated Supabase session across the admin handoff.
- Keeps `/api/admin/session-status` as the server-side role authority.
- Does not promote roles in the browser or bypass authorization.
- Returns unauthenticated sessions to the normal sign-in flow without forced local sign-out.
