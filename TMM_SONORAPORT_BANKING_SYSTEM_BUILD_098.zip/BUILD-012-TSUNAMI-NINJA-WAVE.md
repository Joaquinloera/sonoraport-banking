# Build 012 — Tsunami / Volcano / Ninja Wave

- Added provider-backed card activation endpoint.
- Activation requires authenticated ownership and an issuer-provided card reference.
- Issuer activation uses OAuth, idempotency, and correlation IDs.
- Local card state is updated only after an accepted issuer response.
- Customer portal now exposes activation for issued cards that are not active.
- Existing provider issuance, status synchronization, lock/unlock, biometrics, payments, and reconciliation remain intact.
