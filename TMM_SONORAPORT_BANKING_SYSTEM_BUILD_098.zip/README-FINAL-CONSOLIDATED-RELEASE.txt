SONORAPORT AI BANKING — FINAL CONSOLIDATED RELEASE CANDIDATE

DEPLOYMENT
1. The required V17.1 SQL fixes have already been run successfully.
2. Upload this ZIP directly to the existing Netlify site. Do not extract before upload.
3. Confirm FINAL CONSOLIDATED RELEASE appears in the customer and admin portals.

INCLUDED
- Authentication and profile roles
- Customer and admin portals
- Applications and approvals
- Account creation and account detail modal
- Sandbox deposits and withdrawals
- Internal transfers with debit and credit ledger entries
- Transaction history and balances
- Statements, printing, and CSV export
- Notifications and read controls
- Secure messages and profile settings
- Card requests and card controls
- Admin account, card, application, search, message, and audit controls
- Mobile navigation and responsive layouts

IMPORTANT
This is a sandbox platform. It does not move real money or issue real payment-network cards.
