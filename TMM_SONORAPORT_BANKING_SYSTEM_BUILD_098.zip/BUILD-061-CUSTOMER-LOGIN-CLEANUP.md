# Build 061 — Customer Login Cleanup

- Removed the customer-login marketing/explainer column from `sign-in.html`.
- Removed “financial command center”, “Private access”, “Clear status”, and “Unified command” from customer sign-in.
- Customer login now presents the secure sign-in card only.
- Removed the “Portal connection setup” shortcut from the login card.
- Preserved password, passkey/device biometric, password recovery, account creation, and existing auth/session logic.
- Confirmed these removed phrases are not present on the main `index.html`.
- Release cache advanced to v61 on authenticated/auth pages.
