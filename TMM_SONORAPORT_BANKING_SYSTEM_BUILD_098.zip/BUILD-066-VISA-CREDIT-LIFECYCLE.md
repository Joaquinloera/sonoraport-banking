# Build 066 — Visa Credit Lifecycle

Continues from Build 065. Adds an explicit Visa Credit line model and signed provider webhook lifecycle without reusing the funded Visa Debit balance model.

## Added
- `card_credit_accounts`: credit limit, outstanding balance, reserved authorization amount, and computed available credit.
- Visa Credit authorization, authorization decline, capture, and reversal processing.
- Provider-event idempotency and provider transaction/reference/correlation retention.
- Authorization reserves available credit without creating settled customer-account debits.
- Capture releases the reservation and creates cardholder receivable + network settlement payable ledger entries.
- Reversal restores reserved credit without creating a receivable.
- Reconciliation exceptions for missing Visa Credit card/credit line/authorization and over-capture.
- Stable route `/api/cards/visa-credit/webhook`.

## Preserved
Builds 063–065 USD funding, Visa Debit lifecycle, settlement/reconciliation, issuance, authentication, and portal surfaces remain unchanged.

## Deployment dependency
Apply `supabase/SONORAPORT-V31-VISA-CREDIT-LIFECYCLE.sql`, provision each issued Visa Credit card with an approved `card_credit_accounts` row/credit limit, then route only authenticated issuer Visa Credit events to the new webhook. Build 066 does not invent or auto-approve a credit limit.
