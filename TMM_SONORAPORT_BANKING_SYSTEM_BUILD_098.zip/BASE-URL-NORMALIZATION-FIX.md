# JPMorgan API Base URL normalization fix

This build preserves the existing website and payment flow.

Change applied:
- The backend now safely normalizes `JPMORGAN_API_BASE_URL` to its HTTPS origin.
- A value such as `https://api.payments.jpmorgan.com/embedded/v2` is normalized internally to `https://api.payments.jpmorgan.com`.
- The payment endpoint remains controlled by `JPMORGAN_CREATE_PAYMENT_PATH`.
- No design, pages, buttons, approvals, or branding were removed or changed.
