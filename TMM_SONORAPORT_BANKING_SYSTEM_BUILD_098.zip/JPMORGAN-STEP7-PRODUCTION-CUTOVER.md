# JPMorgan Step 7 — Production Cutover Gate

This release adds a read-only production readiness gate. It does not change Netlify variables, switch environments, submit payments, or move funds.

The gate requires all of the following:

- `ENABLE_JPMORGAN=true`
- `JPMORGAN_ENVIRONMENT=production`
- `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=true`
- Production client credentials and token endpoint configured
- Verification account and configuration ID configured
- Callback verification configured
- Transaction status path configured
- A controlled certification record exists
- The certification callback was verified
- Reconciliation marked the certification as settled

Keep `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=false` until the authorized production cutover decision is made. The gate reports blockers without exposing secret values.
