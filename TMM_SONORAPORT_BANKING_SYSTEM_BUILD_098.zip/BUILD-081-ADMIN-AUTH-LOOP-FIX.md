# BUILD 081 — Admin Auth Loop Fix

- Aligns server Supabase user verification with modern publishable-key configuration.
- Retains legacy SUPABASE_ANON_KEY compatibility.
- Stops admin 401 from redirecting back to sign-in indefinitely.
- Adds explicit one-time local session refresh path for rejected/stale sessions.
- Keeps server-side admin role verification authoritative.
