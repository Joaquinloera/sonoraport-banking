# Build 034 — Customer Banking Hardening

- Main public page preserved from Build 033.
- Customer portal mobile navigation hardened.
- Security moved into its own portal tab.
- Passkey wording simplified for customers.
- Statement branding cleaned; no sandbox wording.
- Fixed a null DOM role reference that could interrupt customer profile loading.
- Added mobile table overflow and form/input hardening.
- Cache-busted customer portal assets to v34.
