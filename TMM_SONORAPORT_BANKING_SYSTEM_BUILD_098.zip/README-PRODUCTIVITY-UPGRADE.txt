SONORAPORT AI BANKING — PRODUCTIVITY WORKSPACE UPGRADE

This package adds working Tasks and Calendar modules to the existing secure client portal.

SETUP
1. Deploy the ZIP to Netlify.
2. In Supabase SQL Editor, run supabase/SONORAPORT-PRODUCTIVITY-UPGRADE.sql once.
3. Open the portal, sign in, and use Tasks or Calendar in the top navigation.

SECURITY
- Tasks and events are protected by Row Level Security.
- Users can only read and change records tied to their own authenticated profile.
- Do not place a Supabase service-role key in the browser.
