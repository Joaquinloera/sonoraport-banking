# JPMorgan Gate Fix Report

This build keeps the verified OAuth flow and aligns all readiness gates to the configured product mode.

## Online Payments mode
The following are required for configuration readiness:
- `ENABLE_JPMORGAN=true`
- `JPMORGAN_PRODUCT_MODE=online_payments`
- `JPMORGAN_CLIENT_ID`
- `JPMORGAN_CLIENT_SECRET`
- `JPMORGAN_TOKEN_URL`
- `JPMORGAN_SCOPE`
- `JPMORGAN_API_BASE_URL`
- `JPMORGAN_CREATE_PAYMENT_PATH`

`JPMORGAN_MERCHANT_ID` is reported separately and is not used to block the non-transactional configuration test.

## Callback self-test
- `ENABLE_JPMORGAN_CALLBACKS=true`
- `JPMORGAN_CALLBACK_VERIFICATION_MODE=hmac-sha256`
- `JPMORGAN_CALLBACK_HMAC_SECRET=<long random secret>`

## Certification and cutover
These remain locked until a signed-in user has a linked provider account, the controlled certification is configured, a provider callback is received, and reconciliation marks the certification settled.

The code does not fabricate provider approval or settlement.
