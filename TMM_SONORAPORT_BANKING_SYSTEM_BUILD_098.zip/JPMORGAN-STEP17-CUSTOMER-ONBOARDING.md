# Step 17 — Customer Onboarding and Account Activation

Run `supabase/SONORAPORT-JPMORGAN-STEP17-CUSTOMER-ONBOARDING.sql` after Step 16.

Set `JPMORGAN_ONBOARDING_ADMIN_EMAILS` to a comma-separated list of authorized administrators.

Endpoints:
- `GET|POST /.netlify/functions/jpmorgan-customer-onboarding`
- `GET|PATCH /.netlify/functions/jpmorgan-onboarding-admin`

A payment is blocked unless identity is verified, KYC is approved, sanctions screening is clear, eligibility is approved, and the account is active.
