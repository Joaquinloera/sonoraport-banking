# JoshGPT final mobile repair — v1.5

- Removed the oversized empty chat area on mobile.
- Raised the assistant above every sticky navigation layer.
- Added a dimmed backdrop while the assistant is open.
- Kept the assistant header and close control visible.
- Limited the message area and made it independently scrollable.
- Preserved quick actions, Send, loading state, history, timeouts, and Netlify Function integration.
- Added outside-tap and Escape closing behavior.
- No banking, payment, authentication, or Client Portal logic was changed.
