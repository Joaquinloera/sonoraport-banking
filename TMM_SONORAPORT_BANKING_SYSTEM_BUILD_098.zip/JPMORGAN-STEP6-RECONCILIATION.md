# J.P. Morgan Step 6 — Reconciliation and Settlement Verification

This step compares the provider transaction record with the SonoraPort certification ledger. It never marks a certification settled from the browser alone.

## Before using

1. Run `supabase/SONORAPORT-JPMORGAN-STEP6-RECONCILIATION.sql` in Supabase.
2. Set this Netlify variable to the exact provider status endpoint path format:

`JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE=/transactions/{paymentId}`

Use the path assigned by the approved JPMorgan API product. Keep `{paymentId}` in the template.

## Settlement rule

A certification is marked `settled` only when:

- The provider reports a terminal successful status.
- Amount, currency, external ID, and provider ID do not conflict.
- A verified callback was previously recorded.

Provider success without a verified callback remains `awaiting_callback`. Any identifier or value conflict becomes `mismatch` and must be reviewed.
