# J.P. Morgan Step 13 — Statements, Reconciliation, and Disputes

Run this SQL after Step 12:

`supabase/SONORAPORT-JPMORGAN-STEP13-STATEMENTS-DISPUTES.sql`

Add one Netlify variable for staff reconciliation access:

`JPMORGAN_RECONCILIATION_ADMIN_EMAILS=authorized@email.com`

Endpoints:

- Monthly JSON statement: `/.netlify/functions/jpmorgan-statement?month=2026-07`
- Monthly CSV statement: `/.netlify/functions/jpmorgan-statement?month=2026-07&format=csv`
- Customer disputes: `/.netlify/functions/jpmorgan-disputes`
- Admin reconciliation report: `/.netlify/functions/jpmorgan-reconciliation-report?month=2026-07`

All endpoints require a valid signed-in Supabase access token. Statements and disputes are restricted to the signed-in customer. Reconciliation reports are restricted to listed administrator emails.
