# Payment Readiness Gate Fix

This focused update changes only the Payment Readiness verification path.

It verifies without submitting a payment:
- OAuth authentication and Online Payments product configuration
- payment endpoint path
- allowed currencies
- allowed payment rails
- maximum payment amount
- server-side idempotency control
- merchant configuration status
- callback verification status

Missing required settings are returned as exact blockers. Merchant ID and callback setup are shown as remaining setup warnings rather than hidden generic failures.
