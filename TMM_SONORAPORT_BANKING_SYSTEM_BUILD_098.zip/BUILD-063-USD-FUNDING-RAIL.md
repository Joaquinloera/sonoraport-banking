# Build 063 — USD Funding Rail

Adds an authenticated, idempotent inbound USD funding-event path that binds provider-confirmed deposits/reversals to the linked provider account, updates the provider balance snapshot, and writes a balanced journal for reconciliation.

- `provider-funding-webhook.mjs`: HMAC-verified inbound funding webhook.
- `SONORAPORT-V28-INBOUND-USD-FUNDING.sql`: funding event evidence + RPC.
- `/api/funding/webhook`: stable server route.
- USD-only; duplicate provider event IDs are idempotent.
- Deposit reversals cannot drive available balance below zero.
