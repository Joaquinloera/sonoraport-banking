# BUILD 052 — Stable API Boundary

Parent: BUILD 051

- Normalized remaining browser-facing provider/function calls behind stable `/api/*` routes.
- Added `/api/banking/beneficiaries` → existing beneficiary function.
- Added `/api/integrations/blackrock/status` → existing integration status function.
- Added `/api/assistant` → existing site assistant function.
- Preserved all existing Netlify functions and server-side provider behavior.
- Bumped authenticated banking release assets from v51 to v52.
- Legacy immutable asset fingerprints remain unchanged.
