# Master v2 authentication configuration fix

This release preserves all pages, buttons, branding, and approval flows.

Changes:
- Normalizes accidental Netlify values entered as `VARIABLE_NAME = value`.
- Uses the `JPMORGAN_*` variables as the primary configuration names.
- Keeps `JPM_TOKEN_URL` only as a backward-compatible token URL alias.
- Adds safe configuration warnings to the JPMorgan status response.
- Does not expose client IDs, secrets, tokens, account numbers, or balances.
- Does not bypass provider authentication or production safety gates.

After deployment, retry **Verify JPMorgan connection**.
