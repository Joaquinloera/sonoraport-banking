# SonoraPort AI Banking — Production Activation Handoff

This build keeps the current sandbox connection intact and is prepared to switch automatically when J.P. Morgan issues the approved production configuration.

## Do not guess these values

Enter only values issued or confirmed by J.P. Morgan:

- `JPMORGAN_ENVIRONMENT`
- `JPMORGAN_CLIENT_ID`
- `JPMORGAN_CLIENT_SECRET`
- `JPMORGAN_TOKEN_URL`
- `JPMORGAN_SCOPE`
- `JPMORGAN_API_BASE_URL`
- `JPMORGAN_CREATE_PAYMENT_PATH`
- `JPMORGAN_MERCHANT_ID`
- `JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE`
- `JPMORGAN_CALLBACK_VERIFICATION_MODE`
- `JPMORGAN_CALLBACK_HMAC_SECRET` or provider-issued certificate settings

## Final activation switches

These remain disabled until provider approval and controlled certification are complete:

- `ENABLE_JPMORGAN_CALLBACKS=true`
- `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=true`
- `JPMORGAN_PAYMENT_OPERATIONS_ENABLED=true`
- `JPMORGAN_EMERGENCY_STOP=false`

## Final validation order

1. Verify provider authentication.
2. Verify account access.
3. Verify payment readiness.
4. Verify callback security.
5. Sign in with an approved operator account.
6. Link the approved J.P. Morgan account or merchant profile.
7. Run the controlled certification transaction.
8. Confirm provider callback and transaction status.
9. Check production cutover.
10. Check production operations.

The interface will show production automatically when the environment and provider configuration are changed to approved production values.
