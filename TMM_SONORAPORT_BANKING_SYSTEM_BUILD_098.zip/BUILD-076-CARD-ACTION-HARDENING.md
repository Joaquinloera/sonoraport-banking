# BUILD 076 — Card Action Hardening
Parent: BUILD 075

- Prevents concurrent browser actions against the same card.
- Adds aria-busy state while provider actions are in flight.
- Makes Card Center controls lifecycle-aware for closed/closing/replaced states.
- Keeps provider-backed Activate, Lock/Unlock, and Refresh Status routes unchanged.
- Does not fabricate Replace/Close provider execution; those remain gated on a verified issuer operation.
- Production cutover gate remains unchanged.
