# BUILD 087 — Provider Rail Separation

- Keeps Pathward card-processor configuration distinct from bank-payment configuration.
- Removes PATHWARD_AUTHORIZATION_PATH as an alias for JPMORGAN_CREATE_PAYMENT_PATH.
- Prevents a card authorization endpoint from satisfying bank-payment readiness.
- Updates Admin Operations labels to identify Bank Payments explicitly.
- Does not embed provider credentials, certificates, private keys, or webhook secrets.
