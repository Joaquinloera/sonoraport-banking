SONORAPORT V17.2 INTERACTIVE ACCOUNTS

No new SQL is required.

This build adds working account-card interactions:
- Tap an account card to open details
- Deposit / Withdraw
- Transfer
- View Activity

Deploy the entire ZIP to the existing Netlify site.
