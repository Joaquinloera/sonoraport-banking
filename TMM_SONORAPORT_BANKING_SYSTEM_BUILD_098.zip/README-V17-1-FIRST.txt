SONORAPORT V17.1 — RUN IN THIS ORDER

1. In Supabase SQL Editor, run:
   supabase/SONORAPORT-V17-1-ALL-ACTIONS-FIX.sql
2. Confirm Success.
3. Deploy this complete ZIP to the existing Netlify site.
4. Open the customer portal and confirm the label:
   V17.1 ALL BUTTONS AUDITED
5. Test a $100 Sandbox Deposit into Savings.
6. Test Mark Read on one notification.
7. Then test transfer, card request, message, profile save, and admin controls.
