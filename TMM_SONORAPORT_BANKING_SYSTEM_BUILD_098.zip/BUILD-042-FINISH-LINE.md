# BUILD 042 — FINISH LINE SWARM

Banking-only release wave from Build 041.

- Fixed authentication `next` routing so nested admin paths preserve the complete same-origin path instead of collapsing to the filename.
- Normalized admin unauthenticated redirect to `/sign-in.html?next=/admin-portal.html`.
- Added stable `/api/admin/card-reconciliation` alias and moved the admin reconciliation console onto it.
- Preserved the Build 041 `/api/cards/*` issuance, activation, control, and readiness aliases.
- No provider response, balance, PAN, CVV, settlement, or issuer result is synthesized.
