import assert from 'node:assert/strict';
const originalFetch = globalThis.fetch;
const statusMod = await import('../netlify/functions/jpmorgan-status.mjs');
const balMod = await import('../netlify/functions/jpmorgan-balances.mjs');
const jsonResponse=(s,b)=>new Response(JSON.stringify(b),{status:s,headers:{'content-type':'application/json'}});
function env(){
  Object.assign(process.env,{
    ENABLE_JPMORGAN:'true',JPMORGAN_PRODUCT_MODE:'online_payments',
    JPMORGAN_API_BASE_URL:'https://api.jpm.test',JPMORGAN_TOKEN_URL:'https://auth.jpm.test/token',
    JPMORGAN_CLIENT_ID:'id',JPMORGAN_CLIENT_SECRET:'secret',JPMORGAN_SCOPE:'payments',
    JPMORGAN_CREATE_PAYMENT_PATH:'/transactions',
    SUPABASE_URL:'https://example.supabase.co',SUPABASE_ANON_KEY:'anon',SUPABASE_SERVICE_ROLE_KEY:'service'
  });
}
env();
let r=await statusMod.handler({httpMethod:'GET',queryStringParameters:{}}); let b=JSON.parse(r.body);
assert.equal(b.enabled,true); assert.equal(b.products.payments,true); assert.equal(b.productMode,'online_payments');
assert.equal(b.paths.payments,'/transactions');
let calls=[];
globalThis.fetch=async(url,opts={})=>{
  calls.push(String(url));
  const s=String(url);
  if(s.endsWith('/auth/v1/user')) return jsonResponse(200,{id:'u1'});
  if(s.includes('/rest/v1/provider_accounts')) return jsonResponse(200,[{id:'l1',provider_account_id:'a1',status:'active'}]);
  if(s==='https://auth.jpm.test/token') return jsonResponse(200,{access_token:'t',expires_in:300});
  if(s==='https://api.jpm.test/accounts/a1/balances') return jsonResponse(200,{available:1});
  throw new Error('unexpected '+s);
};
process.env.JPMORGAN_BALANCES_PATH='/accounts/{accountId}/balances';
r=await balMod.handler({httpMethod:'GET',headers:{authorization:'Bearer x'},queryStringParameters:{}}); assert.equal(r.statusCode,200);
assert.ok(calls.includes('https://auth.jpm.test/token')); assert.ok(calls.includes('https://api.jpm.test/accounts/a1/balances'));
globalThis.fetch=originalFetch;
console.log(JSON.stringify({passed:3,failed:0,checks:['status product mode','payment path configuration','linked balance provider call']},null,2));
