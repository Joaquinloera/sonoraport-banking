import fs from 'node:fs';
const portal=fs.readFileSync('portal-assets/live-portal.js','utf8');
const fn=fs.readFileSync('netlify/functions/card-lifecycle-request.mjs','utf8');
const toml=fs.readFileSync('netlify.toml','utf8');
const checks=[
 ['lock guard',portal.includes('`card:${c.dataset.cardLock}`')],
 ['lifecycle UI',portal.includes('data-card-lifecycle')&&portal.includes('replacement_requested_at')&&portal.includes('closure_requested_at')],
 ['stable lifecycle route',portal.includes("'/api/cards/lifecycle-request'")&&toml.includes('/api/cards/lifecycle-request')],
 ['auth ownership',fn.includes('getSupabaseUser')&&fn.includes('ownedCard(user.id,cardId)')],
 ['no fake provider completion',fn.includes('providerCompleted:false')],
 ['pending timestamps',fn.includes('replacement_requested_at')&&fn.includes('closure_requested_at')]
];
for(const [n,ok] of checks){if(!ok){console.error('FAIL',n);process.exit(1)}console.log('PASS',n)}
