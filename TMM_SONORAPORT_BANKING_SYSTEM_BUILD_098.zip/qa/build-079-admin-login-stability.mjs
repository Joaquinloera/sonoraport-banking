import fs from 'node:fs';
const auth=fs.readFileSync('portal-assets/auth.js','utf8');
const admin=fs.readFileSync('portal-assets/admin-portal.js','utf8');
const login=fs.readFileSync('admin/login.html','utf8');
for(const [ok,msg] of [
 [!auth.includes('sonoraport_admin_reauth'),'legacy destructive reauth removed'],
 [!admin.includes('reauth=1'),'admin portal no reauth loop'],
 [login.includes('next=/admin-portal.html')&&!login.includes('reauth=1'),'admin login stable handoff'],
 [admin.includes('/api/admin/session-status'),'server role verification retained']
]) if(!ok) throw new Error(msg);
console.log('BUILD 079 admin login stability: PASS');
