import fs from 'node:fs'; const r=p=>fs.readFileSync(p,'utf8'); const must=(t,a,l)=>a.forEach(x=>{if(!t.includes(x))throw new Error(`${l}: missing ${x}`)});
const sql=r('supabase/SONORAPORT-V32-MASTERCARD-CREDIT-LIFECYCLE.sql'), hook=r('netlify/functions/mastercard-credit-transaction-webhook.mjs'), cfg=r('netlify.toml');
must(sql,['apply_mastercard_credit_transaction_event',"lower(card_type)='mastercard_credit'",'INSUFFICIENT_AVAILABLE_CREDIT','mastercard_credit_authorization_reserve','mastercard_credit_capture','mastercard_credit_reversal','cardholder_receivable','network_settlement_payable','CAPTURE_EXCEEDS_AUTHORIZATION','MASTERCARD_CREDIT_CARD_NOT_LINKED'],'V32');
must(hook,['CARD_ISSUER_WEBHOOK_SECRET','apply_mastercard_credit_transaction_event',"product!=='MASTERCARD_CREDIT'","currency!=='USD'"],'hook'); must(cfg,['/api/cards/mastercard-credit/webhook','mastercard-credit-transaction-webhook'],'route');
console.log('BUILD_067_MASTERCARD_CREDIT_CONTRACT::PASS');
