import fs from 'node:fs';
const auth=fs.readFileSync('portal-assets/auth.js','utf8');
const admin=fs.readFileSync('portal-assets/admin-portal.js','utf8');
const shared=fs.readFileSync('netlify/functions/lib/shared.mjs','utf8');
const authority=fs.readFileSync('netlify/functions/lib/admin-authority.mjs','utf8');
const checks=[
 ['server supports publishable key',shared.includes('SUPABASE_PUBLISHABLE_KEY')],
 ['server retains anon compatibility',shared.includes('SUPABASE_ANON_KEY')],
 ['admin 401 does not redirect',!admin.includes("if(r.status===401){location.replace")],
 ['admin 401 has stable gate',admin.includes("if(r.status===401){showAccessGate")],
 ['explicit refresh clears stale local session',auth.includes("params.get('refresh')==='1'")&&auth.includes("signOut({scope:'local'})")],
 ['refresh flag removed after one use',auth.includes("params.delete('refresh')")],
 ['normal session handoff retained',auth.includes("data?.session&&document.body.dataset.page!=='reset'")],
 ['executive role retained',authority.includes("'executive'")],
 ['browser cannot promote role',!admin.includes('update({role')&&!auth.includes('update({role')],
];
const bad=checks.filter(([,ok])=>!ok); for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} ${n}`); if(bad.length) process.exit(1); console.log(`BUILD_081_ADMIN_LOOP::PASS ${checks.length}/${checks.length}`);
