import fs from 'node:fs'; const r=p=>fs.readFileSync(p,'utf8'); const must=(t,a,l)=>a.forEach(x=>{if(!t.includes(x))throw new Error(`${l}: missing ${x}`)});
const sql=r('supabase/SONORAPORT-V31-VISA-CREDIT-LIFECYCLE.sql'), hook=r('netlify/functions/visa-credit-transaction-webhook.mjs'), cfg=r('netlify.toml');
must(sql,['card_credit_accounts','credit_limit','outstanding_balance','reserved_amount','apply_visa_credit_transaction_event','INSUFFICIENT_AVAILABLE_CREDIT','visa_credit_authorization_reserve','cardholder_receivable','network_settlement_payable','CAPTURE_EXCEEDS_AUTHORIZATION','unique(provider,provider_event_id)'],'V31');
must(hook,['CARD_ISSUER_WEBHOOK_SECRET','apply_visa_credit_transaction_event',"product!=='VISA_CREDIT'","currency!=='USD'"],'hook'); must(cfg,['/api/cards/visa-credit/webhook','visa-credit-transaction-webhook'],'route');
console.log('BUILD_066_VISA_CREDIT_CONTRACT::PASS');
