import assert from 'node:assert/strict';

Object.assign(process.env, {
  ENABLE_JPMORGAN: 'true',
  JPMORGAN_PRODUCT_MODE: 'online_payments',
  JPMORGAN_API_BASE_URL: 'https://api.payments.example',
  JPMORGAN_CREATE_PAYMENT_PATH: '/api/v2/payments',
  JPMORGAN_SCOPE: 'jpm:payments:configured',
  JPMORGAN_TOKEN_URL: 'https://auth.payments.example/token',
  JPMORGAN_CLIENT_ID: 'client-id',
  JPMORGAN_CLIENT_SECRET: 'client-secret',
  SUPABASE_URL: 'https://supabase.example',
  SUPABASE_PUBLISHABLE_KEY: 'publishable-test-key',
  SUPABASE_SERVICE_ROLE_KEY: 'service-role-test-key',
});

globalThis.fetch = async (url) => {
  const u=String(url);
  if (u === 'https://supabase.example/auth/v1/user') return new Response(JSON.stringify({ id:'admin-user', email:'admin@example.test' }),{status:200,headers:{'content-type':'application/json'}});
  if (u.startsWith('https://supabase.example/rest/v1/profiles?')) return new Response(JSON.stringify([{id:'admin-user',email:'admin@example.test',full_name:'Test Admin',role:'executive'}]),{status:200,headers:{'content-type':'application/json'}});
  if (u === 'https://auth.payments.example/token') return new Response(JSON.stringify({ access_token:'token', expires_in:300 }),{status:200,headers:{'content-type':'application/json'}});
  throw new Error(`Unexpected request: ${url}`);
};

const { handler } = await import('../netlify/functions/jpmorgan-status.mjs');
let response = await handler({ httpMethod:'GET', queryStringParameters:{verify:'account'} });
let body=JSON.parse(response.body);
assert.equal(response.statusCode,401);
assert.equal(body.code,'AUTH_REQUIRED');

response = await handler({ httpMethod:'GET', headers:{authorization:'Bearer admin-test-token'}, queryStringParameters:{verify:'account'} });
body=JSON.parse(response.body);
assert.equal(response.statusCode,200);
assert.equal(body.provider.token,true);
assert.equal(body.provider.accountAccess,true);
assert.equal(body.provider.configuration.apiOriginValid,true);
assert.equal(body.provider.configuration.paymentPathValid,true);
assert.equal(body.provider.configuration.scopeConfigured,true);

process.env.JPMORGAN_API_BASE_URL='https://api.payments.example/embedded/v2';
response=await handler({ httpMethod:'GET',headers:{authorization:'Bearer admin-test-token'},queryStringParameters:{verify:'account'} });
body=JSON.parse(response.body);
assert.equal(body.provider.accountAccess,false);
assert.ok(body.provider.blockers.includes('JPMORGAN_API_BASE_URL must be a base origin without an API path'));
console.log(JSON.stringify({passed:3,failed:0,checks:['anonymous verification denied','authorized Online Payments account gate','exact malformed base URL blocker']},null,2));
