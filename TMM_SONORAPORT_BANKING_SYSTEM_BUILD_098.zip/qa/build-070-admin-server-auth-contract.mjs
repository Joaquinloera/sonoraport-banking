import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const fn=read('netlify/functions/admin-session-status.mjs');
const js=read('portal-assets/admin-portal.js');
const toml=read('netlify.toml');
const checks=[
 ['server validates bearer',fn.includes('getSupabaseUser(getBearer(event))')],
 ['service role stays server side',fn.includes('SUPABASE_SERVICE_ROLE_KEY')&&!js.includes('SUPABASE_SERVICE_ROLE_KEY')],
 ['allowed roles explicit', ['owner','admin','staff','reviewer'].every(r=>fn.includes(`'${r}'`))],
 ['no browser role promotion',!js.includes(".update({role")&&!js.includes("role:'admin'")],
 ['stable session route',toml.includes('/api/admin/session-status')&&toml.includes('admin-session-status')],
 ['portal uses server authorization',js.includes("fetch('/api/admin/session-status'")],
 ['distinct role errors',fn.includes('ADMIN_PROFILE_MISSING')&&fn.includes('ADMIN_ROLE_REQUIRED')&&fn.includes('ADMIN_ROLE_CONFIG_MISSING')]
];
const failed=checks.filter(([,ok])=>!ok);if(failed.length){console.error(failed);process.exit(1)}console.log('BUILD_070_ADMIN_SERVER_AUTH_CONTRACT::PASS');
