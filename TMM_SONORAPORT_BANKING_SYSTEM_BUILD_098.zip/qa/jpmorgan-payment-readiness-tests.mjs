import assert from 'node:assert/strict';

Object.assign(process.env, {
  ENABLE_JPMORGAN: 'true',
  JPMORGAN_PRODUCT_MODE: 'online_payments',
  JPMORGAN_API_BASE_URL: 'https://api.payments.example',
  JPMORGAN_CREATE_PAYMENT_PATH: '/api/v2/payments',
  JPMORGAN_SCOPE: 'jpm:payments:configured',
  JPMORGAN_TOKEN_URL: 'https://auth.payments.example/token',
  JPMORGAN_CLIENT_ID: 'client-id',
  JPMORGAN_CLIENT_SECRET: 'client-secret',
  JPMORGAN_ALLOWED_CURRENCIES: 'USD,EUR',
  JPMORGAN_ALLOWED_PAYMENT_METHODS: 'ACH,WIRE',
  JPMORGAN_MAX_PAYMENT_AMOUNT: '25000',
  SUPABASE_URL: 'https://supabase.example',
  SUPABASE_PUBLISHABLE_KEY: 'publishable-test-key',
  SUPABASE_SERVICE_ROLE_KEY: 'service-role-test-key',
});
delete process.env.JPMORGAN_MERCHANT_ID;
delete process.env.ENABLE_JPMORGAN_CALLBACKS;
delete process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE;
delete process.env.JPMORGAN_CALLBACK_HMAC_SECRET;

globalThis.fetch = async (url) => {
  if (String(url) === 'https://supabase.example/auth/v1/user') {
    return new Response(JSON.stringify({ id: 'admin-user', email: 'admin@example.test' }), { status: 200, headers: { 'content-type': 'application/json' } });
  }
  if (String(url).startsWith('https://supabase.example/rest/v1/profiles?')) {
    return new Response(JSON.stringify([{ id: 'admin-user', email: 'admin@example.test', full_name: 'Test Admin', role: 'executive' }]), { status: 200, headers: { 'content-type': 'application/json' } });
  }
  if (String(url) === 'https://auth.payments.example/token') {
    return new Response(JSON.stringify({ access_token: 'token', expires_in: 300 }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  }
  throw new Error(`Unexpected request: ${url}`);
};

const { handler } = await import('../netlify/functions/jpmorgan-status.mjs');
let response = await handler({ httpMethod: 'GET', headers: { authorization: 'Bearer admin-test-token' }, queryStringParameters: { verify: 'payment' } });
let body = JSON.parse(response.body);
assert.equal(response.statusCode, 200);
assert.equal(body.provider.token, true);
assert.equal(body.provider.accountAccess, true);
assert.equal(body.provider.paymentReadiness, true);
assert.deepEqual(body.provider.paymentControls.allowedCurrencies, ['USD', 'EUR']);
assert.deepEqual(body.provider.paymentControls.allowedMethods, ['ACH', 'WIRE']);
assert.equal(body.provider.paymentControls.maxPaymentAmount, 25000);
assert.equal(body.provider.paymentControls.idempotencyConfigured, true);
assert.ok(body.provider.paymentControls.warnings.includes('JPMORGAN_MERCHANT_ID is not configured'));
assert.ok(body.provider.paymentControls.warnings.includes('Callback verification is not configured'));

process.env.JPMORGAN_MAX_PAYMENT_AMOUNT = '0';
response = await handler({ httpMethod: 'GET', headers: { authorization: 'Bearer admin-test-token' }, queryStringParameters: { verify: 'payment' } });
body = JSON.parse(response.body);
assert.equal(body.provider.paymentReadiness, false);
assert.ok(body.provider.blockers.includes('JPMORGAN_MAX_PAYMENT_AMOUNT must be greater than 0'));

console.log(JSON.stringify({ passed: 2, failed: 0, checks: ['payment readiness controls and warnings', 'exact invalid max amount blocker'] }, null, 2));
