import fs from 'node:fs';
const fn=fs.readFileSync('netlify/functions/card-lifecycle-request.mjs','utf8');
const store=fs.readFileSync('netlify/functions/lib/card-store.mjs','utf8');
const checks=[
 ['pending/terminal states reject new requests',fn.includes('replacement_requested')&&fn.includes('closure_requested')&&fn.includes('CARD_LIFECYCLE_CONFLICT')],
 ['pending timestamps reject cross-action requests',fn.includes('card.replacement_requested_at||card.closure_requested_at')],
 ['atomic conditional update',fn.includes('patchOwnedCard(table,user.id,cardId,patch,card.lifecycle_status??null)')],
 ['stale update returns conflict',fn.includes('updated.length!==1')&&fn.includes('CARD_LIFECYCLE_STALE')],
 ['ownership required',fn.includes('ownedCard(user.id,cardId)')],
 ['compare-and-set filter',store.includes('lifecycle_status=eq.')&&store.includes('lifecycle_status=is.null')],
 ['provider completion not fabricated',fn.includes('providerCompleted:false')]
];
for(const [name,ok] of checks){console.log((ok?'PASS ':'FAIL ')+name);if(!ok)process.exitCode=1}
