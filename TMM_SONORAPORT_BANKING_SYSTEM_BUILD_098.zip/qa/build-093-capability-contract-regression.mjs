import assert from 'node:assert/strict';
const mod = await import('../netlify/functions/jpmorgan-status.mjs');

for (const key of [
  'JPMORGAN_BALANCES_PATH','PATHWARD_BALANCES_PATH','BANK_PROVIDER_BALANCES_PATH',
  'JPMORGAN_CREATE_PAYMENT_PATH','PATHWARD_CREATE_PAYMENT_PATH','BANK_PROVIDER_CREATE_PAYMENT_PATH',
  'BANK_PROVIDER_PAYMENT_PATH','JPMORGAN_PAYMENT_PATH'
]) delete process.env[key];

Object.assign(process.env, {
  ENABLE_JPMORGAN: 'true',
  JPMORGAN_PRODUCT_MODE: 'online_payments',
  JPMORGAN_ENVIRONMENT: 'production',
  JPMORGAN_API_BASE_URL: 'https://api.provider.test',
  JPMORGAN_TOKEN_URL: 'https://auth.provider.test/token',
  JPMORGAN_CLIENT_ID: 'id',
  JPMORGAN_CLIENT_SECRET: 'secret',
  JPMORGAN_SCOPE: 'payments',
});

let r = await mod.handler({ httpMethod: 'GET', queryStringParameters: {} });
let b = JSON.parse(r.body);
assert.equal(b.paths.balances, '/accounts/{accountId}/balances');
assert.equal(b.paths.payments, '/transactions');
assert.equal(b.readiness.balancesPathConfigured, true);
assert.equal(b.readiness.paymentPathConfigured, true);
assert.equal(b.readiness.balancesApiConfigured, true);
assert.equal(b.readiness.bankPaymentsApiConfigured, true);
assert.equal(b.provider.checked, false);
assert.equal(b.provider.token, false);
assert.equal(b.provider.accountAccess, false);
assert.equal(b.provider.paymentReadiness, false);

process.env.JPMORGAN_CREATE_PAYMENT_PATH = 'transactions';
r = await mod.handler({ httpMethod: 'GET', queryStringParameters: {} });
b = JSON.parse(r.body);
assert.equal(b.readiness.paymentPathConfigured, false);
assert.equal(b.readiness.bankPaymentsApiConfigured, false);

console.log(JSON.stringify({passed:10,failed:0,build:'093',checks:['effective default balance route','effective default payment route','capability flags','provider gates remain unverified','invalid override remains blocked']},null,2));
