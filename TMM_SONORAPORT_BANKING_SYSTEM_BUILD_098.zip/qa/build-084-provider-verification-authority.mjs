import assert from 'node:assert/strict';
Object.assign(process.env,{ENABLE_JPMORGAN:'true',JPMORGAN_PRODUCT_MODE:'online_payments',JPMORGAN_API_BASE_URL:'https://api.payments.example',JPMORGAN_CREATE_PAYMENT_PATH:'/payments',JPMORGAN_SCOPE:'payments',JPMORGAN_TOKEN_URL:'https://auth.payments.example/token',JPMORGAN_CLIENT_ID:'id',JPMORGAN_CLIENT_SECRET:'secret'});
const {handler}=await import('../netlify/functions/jpmorgan-status.mjs');
const r=await handler({httpMethod:'GET',queryStringParameters:{verify:'token'},headers:{}});
assert.equal(r.statusCode,401);
const b=JSON.parse(r.body);assert.equal(b.code,'AUTH_REQUIRED');
console.log('BUILD_084_PROVIDER_VERIFICATION_AUTHORITY::PASS');
