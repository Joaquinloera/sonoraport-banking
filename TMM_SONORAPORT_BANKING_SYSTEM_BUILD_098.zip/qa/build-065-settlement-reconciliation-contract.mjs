import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8'); const must=(t,ns,l)=>{for(const n of ns)if(!t.includes(n))throw new Error(`${l}: missing ${n}`)};
const sql=read('supabase/SONORAPORT-V30-VISA-DEBIT-SETTLEMENT-RECONCILIATION.sql'); const hook=read('netlify/functions/card-settlement-webhook.mjs'); const cfg=read('netlify.toml'); const v29=read('supabase/SONORAPORT-V29-VISA-DEBIT-FUNDED-LIFECYCLE.sql');
must(v29,['apply_visa_debit_transaction_event','visa_debit_capture','card_lifecycle_applications'],'Build 064 continuity');
must(sql,['card_settlement_events','unique(provider,provider_event_id)','unique(provider,provider_settlement_id,provider_transaction_id)','CAPTURE_NOT_FOUND','SETTLEMENT_AMOUNT_MISMATCH','CAPTURE_LEDGER_UNBALANCED','CAPTURE_LEDGER_TOTAL_MISMATCH','provider_settlement_payable','visa_debit_network_settlement','provider_reference_id','correlation_id'],'Settlement reconciliation SQL');
must(hook,['CARD_ISSUER_WEBHOOK_SECRET','apply_visa_debit_settlement_event',"currency!=='USD'","product!=='VISA_DEBIT'",'providerSettlementId'],'Settlement webhook');
must(cfg,['/api/cards/settlement/webhook','card-settlement-webhook'],'Stable settlement route');
console.log('BUILD_065_SETTLEMENT_RECONCILIATION_CONTRACT::PASS');
