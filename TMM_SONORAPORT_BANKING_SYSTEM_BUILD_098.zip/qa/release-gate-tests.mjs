import assert from 'node:assert/strict';
import { issuerConfigurationState, configuredIssuers } from '../netlify/functions/lib/card-issuer-router.mjs';

const saved={...process.env};
try {
  process.env.CARD_ISSUER_PRIORITY='PRIMARY,SECONDARY';
  process.env.CARD_ISSUER_ENABLED='true';
  process.env.CARD_ISSUER_BASE_URL='https://issuer.invalid';
  process.env.CARD_ISSUER_TOKEN_URL='https://issuer.invalid/oauth/token';
  process.env.CARD_ISSUER_CLIENT_ID='test-client';
  process.env.CARD_ISSUER_CLIENT_SECRET='test-secret';
  process.env.CARD_ISSUER_PRODUCTS='VISA_DEBIT,VISA_CREDIT';
  process.env.CARD_ISSUER_SECONDARY_ENABLED='false';
  const issuers=configuredIssuers();
  assert.equal(issuers.length,2);
  assert.equal(issuerConfigurationState(issuers[0]).configured,true);
  assert.equal(issuerConfigurationState(issuers[1]).configured,false);
  assert.deepEqual(issuers[0].products,['VISA_DEBIT','VISA_CREDIT']);
  console.log('RELEASE_GATE::ISSUER_ROUTER_CONFIG::PASS');
} finally {
  for (const k of Object.keys(process.env)) if (!(k in saved)) delete process.env[k];
  Object.assign(process.env,saved);
}
