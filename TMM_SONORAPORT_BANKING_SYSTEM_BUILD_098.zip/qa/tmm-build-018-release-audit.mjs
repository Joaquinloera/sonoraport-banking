import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const has=p=>fs.existsSync(path.join(root,p));
const admin=fs.readFileSync(path.join(root,'admin-portal.html'),'utf8');
const checks={
  adminProviderHealth:/Provider Health/.test(admin),
  adminPaymentsOperations:/Payments Operations/.test(admin),
  adminSecurityBiometrics:/Security & Biometrics/.test(admin),
  adminAccountDiscovery:/Authenticated Account Discovery/.test(admin),
  biometricReadiness:has('assets/js/tmm-native-passkey.js'),
  issuerRouter:has('netlify/functions/lib/card-issuer-router.mjs'),
  issuerReadiness:has('netlify/functions/card-issuer-router-readiness.mjs'),
  cardIssuance:has('netlify/functions/card-issuance-request.mjs'),
  cardActivation:has('netlify/functions/card-activation.mjs'),
  providerStatus:has('netlify/functions/jpmorgan-status.mjs')
};
const pass=Object.values(checks).every(Boolean);
fs.writeFileSync('TMM_BUILD_018_AUDIT.json',JSON.stringify({build:'018',pass,checks},null,2)+'\n');
console.log(JSON.stringify({build:'018',pass,checks},null,2));
if(!pass)process.exit(1);
