import fs from 'node:fs';
const p=fs.readFileSync('portal-assets/live-portal.js','utf8');
const files=['netlify/functions/card-issuance-request.mjs','netlify/functions/card-activation.mjs','netlify/functions/card-control.mjs','netlify/functions/card-status-sync.mjs'];
for(const f of files){if(!fs.existsSync(f))throw new Error(`missing ${f}`)}
for(const x of ['/api/cards/issuance','/api/cards/activate','/api/cards/control','/api/cards/status-sync','data-card-sync','apiError(data'])if(!p.includes(x))throw new Error(`portal missing ${x}`);
if(!p.includes("safeCurrentCards"))throw new Error('current card normalization missing');
console.log('BUILD 075 card lifecycle UI: PASS');
