import fs from 'node:fs';
const req=(p,s)=>{const x=fs.readFileSync(p,'utf8');for(const needle of s){if(!x.includes(needle))throw new Error(`${p}: missing ${needle}`)}};
const exists=p=>{if(!fs.existsSync(p))throw new Error(`missing ${p}`)};
[
'netlify/functions/jpmorgan-linked-accounts.mjs','netlify/functions/card-issuance-request.mjs','netlify/functions/card-activation.mjs','netlify/functions/card-control.mjs','netlify/functions/card-transaction-webhook.mjs','netlify/functions/card-reconciliation-admin.mjs','netlify/functions/external-transfer-status.mjs'
].forEach(exists);
[
'supabase/SONORAPORT-V22-PROVIDER-CARD-ISSUANCE.sql','supabase/SONORAPORT-V23-CARD-LIFECYCLE.sql','supabase/SONORAPORT-V24-CARD-TRANSACTION-LIFECYCLE.sql','supabase/SONORAPORT-V25-CARD-LEDGER-RECONCILIATION.sql','supabase/SONORAPORT-V26-CARD-SPEND-CONTROLS.sql','supabase/SONORAPORT-V27-EXTERNAL-TRANSFER-LIFECYCLE.sql','supabase/SONORAPORT-V28-INBOUND-USD-FUNDING.sql','supabase/SONORAPORT-V29-VISA-DEBIT-FUNDED-LIFECYCLE.sql'
].forEach(exists);
req('netlify/functions/card-transaction-webhook.mjs',['timingSafeEqual','CARD_ISSUER_WEBHOOK_SECRET','apply_visa_debit_transaction_event','provider_event_id','VISA_DEBIT','USD']);
req('netlify/functions/card-issuance-request.mjs',['Authorization','provider','card']);
req('netlify/functions/card-activation.mjs',['Authorization','provider']);
req('netlify/functions/external-transfer-status.mjs',['getBearer','getSupabaseUser','profile_id=eq.']);
console.log('END_TO_END_BANKING_CONTRACT::PASS');
console.log('CHAIN::SUPABASE_AUTH>USD_FUNDING>VISA_DEBIT>AUTH_HOLD>CAPTURE_OR_REVERSAL>LEDGER>RECONCILIATION');
