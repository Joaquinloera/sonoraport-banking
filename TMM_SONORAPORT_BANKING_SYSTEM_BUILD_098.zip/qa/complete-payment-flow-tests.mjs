import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../jpmorgan.html', import.meta.url), 'utf8');
const js = fs.readFileSync(new URL('../assets/js/jpmorgan.js', import.meta.url), 'utf8');
const createPayment = fs.readFileSync(new URL('../netlify/functions/jpmorgan-create-payment.mjs', import.meta.url), 'utf8');
const callback = fs.readFileSync(new URL('../netlify/functions/jpmorgan-callback.mjs', import.meta.url), 'utf8');
const readiness = fs.readFileSync(new URL('../netlify/functions/jpmorgan-production-readiness.mjs', import.meta.url), 'utf8');

const checks = [
  ['Payment form submits beneficiaryId', /name="beneficiaryId"/.test(html)],
  ['Beneficiary enrollment UI exists', /id="jpmBeneficiaryForm"/.test(html)],
  ['Beneficiary loader exists', /id="jpmLoadBeneficiaries"/.test(html)],
  ['Frontend calls beneficiary endpoint', /jpmorgan-beneficiaries/.test(js)],
  ['Payment backend requires active beneficiary', /getActiveBeneficiary/.test(createPayment)],
  ['Payment backend uses idempotency', /idempotencyKey:\s*paymentId/.test(createPayment)],
  ['Payment backend reserves funds', /reserveProviderPayment/.test(createPayment)],
  ['Callback finalizes ledger reservation', /finalizePaymentReservation/.test(callback)],
  ['Cutover checks certification settlement', /controlledCertificationSettled/.test(readiness)],
];
for (const [name, passed] of checks) assert.equal(passed, true, name);
console.log(JSON.stringify({ passed: checks.length, failed: 0, checks: checks.map(([name]) => name) }, null, 2));
