import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
const portal=read('portal-assets/live-portal.js'),admin=read('portal-assets/admin-portal.js'),auth=read('netlify/functions/lib/admin-authority.mjs'),toml=read('netlify.toml'),app=read('netlify/functions/customer-application.mjs'),dash=read('netlify/functions/admin-dashboard-data.mjs'),review=read('netlify/functions/admin-application-review.mjs');
const checks=[
 ['executive admin authority',auth.includes("'executive'")],
 ['current application boundary',portal.includes("fetch('/api/applications'")&&app.includes('bank_account_applications')],
 ['current customer accounts/cards',portal.includes("currentRows('bank_accounts')")&&portal.includes("currentRows('debit_cards')")&&portal.includes("currentRows('credit_cards')")],
 ['current transaction/transfer reads',portal.includes("currentRows('transactions')")&&portal.includes("currentRows('transfer_requests')")],
 ['current internal transfer rpc',portal.includes("sb.rpc('internal_transfer'")&&!portal.includes("sb.rpc('submit_internal_transfer'")],
 ['notification undefined guard removed',!portal.includes("mark_all_notifications_read")],
 ['admin current dashboard',admin.includes("fetch('/api/admin/dashboard-data'")&&dash.includes('bank_account_applications')&&dash.includes('bank_accounts')&&dash.includes('debit_cards')&&dash.includes('credit_cards')],
 ['admin current review',admin.includes("fetch('/api/admin/application-review'")&&review.includes('sp_review_account_application')],
 ['routes installed',toml.includes('/api/applications')&&toml.includes('/api/admin/dashboard-data')&&toml.includes('/api/admin/application-review')],
 ['no legacy admin money reads',!admin.includes("q('applications')")&&!admin.includes("q('accounts')")&&!admin.includes("q('cards')")],
 ['no legacy admin money mutations',!admin.includes('set_account_status')&&!admin.includes('set_card_status')&&!admin.includes('review_application')]
];
let bad=0; for(const [n,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${n}`);if(!ok)bad++;} if(bad)process.exit(1);
