import assert from 'node:assert/strict';
import crypto from 'node:crypto';

const originalEnv = { ...process.env };
const originalFetch = globalThis.fetch;
const results = [];
const record = (name, fn) => Promise.resolve().then(fn).then(() => results.push({ name, status: 'PASS' })).catch((e) => results.push({ name, status: 'FAIL', error: e.message }));
const jsonResponse = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });

function resetEnv() {
  for (const k of Object.keys(process.env)) if (!(k in originalEnv)) delete process.env[k];
  Object.assign(process.env, originalEnv);
  process.env.ENABLE_JPMORGAN = 'true';
  process.env.JPMORGAN_PAYMENT_OPERATIONS_ENABLED = 'true';
  process.env.JPMORGAN_EMERGENCY_STOP = 'false';
  process.env.JPMORGAN_API_BASE_URL = 'https://sandbox.jpm.test';
  process.env.JPMORGAN_TOKEN_PATH = '/oauth/token';
  process.env.JPMORGAN_CLIENT_ID = 'test-client';
  process.env.JPMORGAN_CLIENT_SECRET = 'test-secret';
  process.env.JPMORGAN_BALANCES_PATH = '/accounts/{accountId}/balances';
  process.env.JPMORGAN_CREATE_PAYMENT_PATH = '/payments';
  process.env.JPMORGAN_ONBOARD_CLIENT_PATH = '/clients';
  process.env.SUPABASE_URL = 'https://example.supabase.co';
  process.env.SUPABASE_ANON_KEY = 'anon-test';
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-test';
  process.env.JPMORGAN_AUDIT_SIGNING_KEY = 'audit-test';
}
resetEnv();

const statusMod = await import('../netlify/functions/jpmorgan-status.mjs');
const balMod = await import('../netlify/functions/jpmorgan-balances.mjs');
const payMod = await import('../netlify/functions/jpmorgan-create-payment.mjs');
const cbMod = await import('../netlify/functions/jpmorgan-callback.mjs');

await record('Status reports enabled with complete configuration', async () => {
  resetEnv();
  const r = await statusMod.handler(); const b = JSON.parse(r.body);
  assert.equal(r.statusCode, 200); assert.equal(b.enabled, true);
});

await record('Balances rejects unauthenticated access', async () => {
  resetEnv();
  globalThis.fetch = async () => jsonResponse(401, {});
  const r = await balMod.handler({ httpMethod: 'GET', headers: {} });
  assert.equal(r.statusCode, 401);
});

await record('Balances resolves owned provider account and calls provider', async () => {
  resetEnv();
  const calls = [];
  globalThis.fetch = async (url, opts = {}) => {
    calls.push({ url: String(url), opts });
    const s = String(url);
    if (s.endsWith('/auth/v1/user')) return jsonResponse(200, { id: 'user-1', email: 'u@test.invalid' });
    if (s.includes('/rest/v1/provider_accounts')) return jsonResponse(200, [{ id: 'link-1', profile_id: 'user-1', provider_account_id: 'acct-123', display_name: 'Operating', account_type: 'checking', last4: '0123', status: 'active' }]);
    if (s.endsWith('/oauth/token')) return jsonResponse(200, { access_token: 'provider-token', expires_in: 300 });
    if (s.endsWith('/accounts/acct-123/balances')) return jsonResponse(200, { available: 125.50, currency: 'USD' });
    throw new Error(`Unexpected fetch ${url}`);
  };
  const r = await balMod.handler({ httpMethod: 'GET', headers: { authorization: 'Bearer user-token' }, queryStringParameters: {} });
  const b = JSON.parse(r.body);
  assert.equal(r.statusCode, 200); assert.equal(b.linkedAccount.last4, '0123'); assert.equal(b.balances.available, 125.5);
  assert.ok(calls.some((c) => c.url.endsWith('/accounts/acct-123/balances')));
});

await record('Payment rejects invalid amount before provider call', async () => {
  resetEnv();
  globalThis.fetch = async (url) => {
    const s = String(url);
    if (s.endsWith('/auth/v1/user')) return jsonResponse(200, { id: 'user-1' });
    if (s.includes('/rest/v1/customer_onboarding_cases')) return jsonResponse(200, [{ identity_status: 'verified', kyc_status: 'approved', sanctions_status: 'clear', eligibility_status: 'eligible', account_status: 'active' }]);
    throw new Error(`Provider should not be called: ${url}`);
  };
  const r = await payMod.handler({ httpMethod: 'POST', headers: { authorization: 'Bearer user-token' }, body: JSON.stringify({ amount: 0, currency: 'USD', beneficiaryId: '11111111-1111-4111-8111-111111111111' }) });
  assert.equal(r.statusCode, 400);
});

await record('Payment uses linked provider account and idempotency header', async () => {
  resetEnv();
  let providerRequest;
  globalThis.fetch = async (url, opts = {}) => {
    const s = String(url);
    if (s.endsWith('/auth/v1/user')) return jsonResponse(200, { id: 'user-1', email: 'u@test.invalid' });
    if (s.includes('/rest/v1/customer_onboarding_cases')) return jsonResponse(200, [{ identity_status: 'verified', kyc_status: 'approved', sanctions_status: 'clear', eligibility_status: 'eligible', account_status: 'active' }]);
    if (s.includes('/rest/v1/payment_beneficiaries?')) return jsonResponse(200, [{ id: '11111111-1111-4111-8111-111111111111', profile_id: 'user-1', provider_destination_id: 'dest-1', currency: 'USD', status: 'active' }]);
    if (s.includes('/rest/v1/provider_accounts')) return jsonResponse(200, [{ id: 'link-1', profile_id: 'user-1', provider_account_id: 'acct-123', status: 'active' }]);
    if (s.includes('/rest/v1/rpc/reserve_provider_payment')) return jsonResponse(200, { journalId: 'journal-1' });
    if (s.includes('/rest/v1/rpc/update_payment_reservation')) return jsonResponse(200, { ok: true });
    if (s.includes('/rest/v1/jpmorgan_audit_events?select=event_hash')) return jsonResponse(200, []);
    if (s.endsWith('/rest/v1/jpmorgan_audit_events')) return jsonResponse(201, [{ id: 'audit-1' }]);
    if (s.includes('/rest/v1/payment_beneficiaries?id=eq.')) return jsonResponse(200, []);
    if (s.endsWith('/payments')) { providerRequest = { url: s, opts }; return jsonResponse(201, { id: 'pay-1', status: 'submitted' }); }
    if (s.endsWith('/oauth/token')) return jsonResponse(200, { access_token: 'provider-token', expires_in: 300 });
    throw new Error(`Unexpected fetch ${url}`);
  };
  const r = await payMod.handler({ httpMethod: 'POST', headers: { authorization: 'Bearer user-token' }, body: JSON.stringify({ amount: '25.00', currency: 'USD', beneficiaryId: '11111111-1111-4111-8111-111111111111', paymentMethod: 'ACH' }) });
  const b = JSON.parse(r.body);
  assert.equal(r.statusCode, 201); assert.equal(b.payment.status, 'submitted');
  assert.equal(providerRequest.opts.method, 'POST'); assert.ok(providerRequest.opts.headers['Idempotency-Key']);
  const payload = JSON.parse(providerRequest.opts.body); assert.equal(payload.sourceAccountId, 'acct-123'); assert.equal(payload.amount.value, '25.00');
});

await record('Callback rejects invalid signature', async () => {
  resetEnv(); process.env.ENABLE_JPMORGAN_CALLBACKS = 'true'; process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE = 'hmac-sha256'; process.env.JPMORGAN_CALLBACK_HMAC_SECRET = 'callback-secret';
  const body = JSON.stringify({ id: 'evt-1', eventType: 'payment.updated' });
  const r = await cbMod.handler({ httpMethod: 'POST', headers: { 'x-jpm-signature': 'bad', 'x-jpm-timestamp': String(Math.floor(Date.now() / 1000)) }, body });
  assert.equal(r.statusCode, 401);
});

await record('Callback accepts valid fresh HMAC signature', async () => {
  resetEnv(); process.env.ENABLE_JPMORGAN_CALLBACKS = 'true'; process.env.JPMORGAN_CALLBACK_VERIFICATION_MODE = 'hmac-sha256'; process.env.JPMORGAN_CALLBACK_HMAC_SECRET = 'callback-secret';
  globalThis.fetch = async (url, opts = {}) => {
    const s = String(url);
    if (s.includes('/rest/v1/jpmorgan_audit_events?select=event_hash')) return jsonResponse(200, []);
    if (s.endsWith('/rest/v1/jpmorgan_audit_events')) return jsonResponse(201, [{ id: 'audit-1' }]);
    throw new Error(`Unexpected fetch ${url}`);
  };
  const body = JSON.stringify({ id: 'evt-1', eventType: 'payment.updated' });
  const sig = crypto.createHmac('sha256', 'callback-secret').update(body).digest('hex');
  const r = await cbMod.handler({ httpMethod: 'POST', headers: { 'x-jpm-signature': sig, 'x-jpm-timestamp': String(Math.floor(Date.now() / 1000)) }, body });
  assert.equal(r.statusCode, 200); assert.equal(JSON.parse(r.body).received, true);
});

globalThis.fetch = originalFetch;
const failures = results.filter((r) => r.status === 'FAIL');
console.log(JSON.stringify({ results, passed: results.length - failures.length, failed: failures.length }, null, 2));
if (failures.length) process.exit(1);
