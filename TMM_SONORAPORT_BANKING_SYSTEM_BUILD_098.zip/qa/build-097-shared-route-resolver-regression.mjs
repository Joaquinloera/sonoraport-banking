import assert from 'node:assert/strict';
import fs from 'node:fs';
import { configuredPath, paymentApiPath, balancesApiPath, validApiPath } from '../netlify/functions/lib/jpmorgan.mjs';

const saved = { ...process.env };
try {
  delete process.env.JPMORGAN_CREATE_PAYMENT_PATH;
  delete process.env.PATHWARD_CREATE_PAYMENT_PATH;
  delete process.env.BANK_PROVIDER_CREATE_PAYMENT_PATH;
  delete process.env.BANK_PROVIDER_PAYMENT_PATH;
  delete process.env.JPMORGAN_PAYMENT_PATH;
  delete process.env.JPMORGAN_BALANCES_PATH;
  delete process.env.PATHWARD_BALANCES_PATH;
  delete process.env.BANK_PROVIDER_BALANCES_PATH;

  assert.equal(paymentApiPath(), '/transactions');
  assert.equal(balancesApiPath(), '/accounts/{accountId}/balances');
  assert.equal(validApiPath(paymentApiPath()), true);
  assert.equal(validApiPath(balancesApiPath()), true);

  process.env.JPMORGAN_CREATE_PAYMENT_PATH = '/v2/payments';
  assert.equal(paymentApiPath(), '/v2/payments');
  assert.equal(configuredPath('JPMORGAN_CREATE_PAYMENT_PATH', '/transactions'), '/v2/payments');

  process.env.JPMORGAN_CREATE_PAYMENT_PATH = 'https://wrong.example/payments';
  assert.equal(validApiPath(paymentApiPath()), false);

  const targets = [
    'jpmorgan-production-config.mjs',
    'jpmorgan-production-readiness.mjs',
    'production-cutover-summary.mjs',
    'jpmorgan-operations-health.mjs',
  ];
  for (const name of targets) {
    const src = fs.readFileSync(new URL(`../netlify/functions/${name}`, import.meta.url), 'utf8');
    assert.equal(src.includes("has('JPMORGAN_CREATE_PAYMENT_PATH')"), false, `${name} still has stale raw path gate`);
    assert.equal(src.includes('paymentApiPath()'), true, `${name} does not consume shared payment resolver`);
  }
  console.log('BUILD 097 shared route resolver regression: PASS');
} finally {
  process.env = saved;
}
