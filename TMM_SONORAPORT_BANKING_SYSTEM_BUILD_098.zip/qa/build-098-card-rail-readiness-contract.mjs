import fs from 'node:fs';
const report=fs.readFileSync(new URL('../netlify/functions/production-readiness-report.mjs',import.meta.url),'utf8');
const contract=JSON.parse(fs.readFileSync(new URL('../config/sonoraport-visa-debit-card-issuer.json',import.meta.url),'utf8'));
const tests=[
 ['card checks exist',report.includes('const cardChecks={')],
 ['card blockers exist',report.includes('const cardBlockers=')],
 ['card readiness uses card blockers',report.includes('readyForControlledIssuanceVerification:cardBlockers.length===0')],
 ['overall readiness remains separate',report.includes('readyForOverallProduction:blockers.length===0')],
 ['bank payment gate retained',report.includes("paymentProviderEnabled:yes('ENABLE_JPMORGAN')")],
 ['production cutover retained',report.includes("productionCutoverApproved:yes('JPMORGAN_PRODUCTION_CUTOVER_APPROVED')")],
 ['visa debit contract product',contract.product==='VISA_DEBIT'],
 ['secrets forbidden in repo',contract.environment_contract.secret_values_must_not_be_committed===true]
];
let failed=0;
for(const [name,ok] of tests){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);
console.log(`${tests.length}/${tests.length} BUILD 098 card-rail readiness checks PASS`);
