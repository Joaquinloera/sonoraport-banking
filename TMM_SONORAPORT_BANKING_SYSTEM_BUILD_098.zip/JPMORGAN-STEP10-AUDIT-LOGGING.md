# JPMorgan Step 10 — Audit Logging and Compliance Evidence

1. Run `supabase/SONORAPORT-JPMORGAN-STEP10-AUDIT-LOGGING.sql` in Supabase SQL Editor.
2. Add a strong random Netlify secret named `JPMORGAN_AUDIT_SIGNING_KEY`.
3. Add authorized compliance email addresses to `JPMORGAN_AUDIT_ADMIN_EMAILS`, comma separated.
4. Deploy the package only after the SQL migration succeeds.

The audit table is service-role only. Each event includes the previous event hash and an HMAC event hash, creating a tamper-evident chain. The export endpoint is `/.netlify/functions/jpmorgan-audit-export` and requires a signed-in user whose email is listed in `JPMORGAN_AUDIT_ADMIN_EMAILS`.
