# Build 036 — Brand + Card Swarm
- Added customer-facing Visa, Mastercard, Zelle, BBB, and Fortune 500 brand rail to public home and authenticated customer portal.
- Preserved Build 035 card request/issuance workflow and Visa/Mastercard product selection.
- Preserved main banking/auth/provider code.
