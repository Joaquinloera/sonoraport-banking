# Build 022 — Card Ledger + Reconciliation
- Signature-verified issuer events remain idempotent.
- Authorization holds are linked to provider-issued cards and customer accounts.
- Capture/clearing/reversal/refund advance the hold lifecycle only after provider events.
- Missing holds, currency mismatches, and captures above authorization create Admin reconciliation exceptions.
- Duplicate provider events do not post twice.
- PAN/CVV are never stored by this layer.
