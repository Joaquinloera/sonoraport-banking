# Build 071 — Authority + Evidence Provenance

Parent: BUILD 070

## Admin authority unification
- Extracts the BUILD 070 server-side profile/role verification into one reusable authority module.
- Admin session status, production cutover summary, issuer readiness, and issuer-router readiness now use the same server-side role decision.
- Authorized operations roles remain: owner, admin, staff, reviewer.
- Browser sessions cannot self-promote or supply their own role.

## Connected-document provenance
- Connected Google Drive banking documents were reviewed as documentary/configuration inputs.
- Written balances, account-status statements, and institutional relationship claims are not converted into live balances by this build.
- Production/live status remains dependent on authenticated provider responses, deployed database state, webhook verification, and reconciliation evidence.
- No Drive document secrets, account references, balances, or personal details are embedded in this archive.
