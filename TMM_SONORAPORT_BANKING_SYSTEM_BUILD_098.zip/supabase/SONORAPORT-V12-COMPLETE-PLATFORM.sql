-- SONORAPORT V12 COMPLETE PLATFORM
-- Sandbox ledger and workflow only. No external banking rails or real card issuance.
-- Safe to run more than once.

create extension if not exists pgcrypto;

create table if not exists public.accounts(
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  type text not null,
  balance numeric(14,2) not null default 0 check(balance >= 0),
  status text not null default 'active',
  last4 text,
  created_at timestamptz not null default now()
);
create table if not exists public.transactions(
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  account_id uuid references public.accounts(id) on delete cascade,
  description text not null,
  kind text not null,
  amount numeric(14,2) not null,
  status text not null default 'posted',
  created_at timestamptz not null default now()
);
create table if not exists public.transfers(
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  from_account_id uuid references public.accounts(id),
  to_account_id uuid references public.accounts(id),
  from_name text,
  to_name text,
  amount numeric(14,2) not null check(amount > 0),
  status text not null default 'pending_review',
  created_at timestamptz not null default now()
);
create table if not exists public.cards(
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  account_id uuid references public.accounts(id),
  card_type text not null,
  last4 text,
  status text not null default 'application_received',
  created_at timestamptz not null default now()
);
create table if not exists public.notifications(
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table if exists public.applications add column if not exists reference text;
alter table if exists public.applications add column if not exists title text;
alter table if exists public.applications add column if not exists status text default 'submitted';
alter table if exists public.applications add column if not exists decision_note text;
alter table if exists public.applications add column if not exists reviewed_at timestamptz;
alter table if exists public.applications add column if not exists reviewed_by uuid;
alter table if exists public.applications add column if not exists created_at timestamptz default now();
alter table if exists public.cards add column if not exists locked boolean not null default false;
alter table if exists public.cards add column if not exists nickname text;
alter table if exists public.accounts add column if not exists last4 text;

update public.applications set reference='SP-APP-'||upper(substr(replace(id::text,'-',''),1,8)) where reference is null;
create unique index if not exists applications_reference_unique_idx on public.applications(reference) where reference is not null;
create index if not exists applications_profile_created_idx on public.applications(profile_id,created_at desc);
create index if not exists accounts_profile_created_idx on public.accounts(profile_id,created_at desc);
create index if not exists transactions_profile_created_idx on public.transactions(profile_id,created_at desc);
create index if not exists transfers_profile_created_idx on public.transfers(profile_id,created_at desc);
create index if not exists cards_profile_created_idx on public.cards(profile_id,created_at desc);
create index if not exists notifications_profile_created_idx on public.notifications(profile_id,created_at desc);

create or replace function public.is_staff(uid uuid default auth.uid()) returns boolean
language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.id=uid and lower(coalesce(p.role,'')) in ('owner','admin','staff','reviewer'));
$$;
grant execute on function public.is_staff(uuid) to authenticated;

alter table public.accounts enable row level security;
alter table public.transactions enable row level security;
alter table public.transfers enable row level security;
alter table public.cards enable row level security;
alter table public.applications enable row level security;
alter table public.notifications enable row level security;

-- Remove older broad policies before installing the V12 access model.
drop policy if exists accounts_own on public.accounts;
drop policy if exists transactions_own on public.transactions;
drop policy if exists transfers_own on public.transfers;
drop policy if exists cards_own on public.cards;
drop policy if exists applications_own on public.applications;
drop policy if exists applications_select_own on public.applications;
drop policy if exists applications_insert_own on public.applications;
drop policy if exists applications_update_own on public.applications;
drop policy if exists notifications_select_own on public.notifications;
drop policy if exists notifications_update_own on public.notifications;

-- Staff may read the customer directory; customers retain their existing own-profile access.
alter table public.profiles enable row level security;
drop policy if exists profiles_staff_read on public.profiles;
create policy profiles_staff_read on public.profiles for select to authenticated using(public.is_staff());

-- Customers see their own records; staff see all records.
do $$ declare t text; begin
  foreach t in array array['accounts','transactions','transfers','cards','applications','notifications'] loop
    execute format('drop policy if exists %I on public.%I',t||'_select_access',t);
    execute format('create policy %I on public.%I for select to authenticated using (profile_id=auth.uid() or public.is_staff())',t||'_select_access',t);
  end loop;
end $$;

drop policy if exists accounts_insert_staff on public.accounts;
create policy accounts_insert_staff on public.accounts for insert to authenticated with check(public.is_staff());
drop policy if exists accounts_update_staff on public.accounts;
create policy accounts_update_staff on public.accounts for update to authenticated using(public.is_staff()) with check(public.is_staff());

drop policy if exists transactions_insert_staff on public.transactions;
create policy transactions_insert_staff on public.transactions for insert to authenticated with check(public.is_staff());

drop policy if exists transfers_insert_own on public.transfers;
create policy transfers_insert_own on public.transfers for insert to authenticated with check(profile_id=auth.uid());
drop policy if exists transfers_update_staff on public.transfers;
create policy transfers_update_staff on public.transfers for update to authenticated using(public.is_staff()) with check(public.is_staff());

drop policy if exists cards_insert_own on public.cards;
create policy cards_insert_own on public.cards for insert to authenticated with check(profile_id=auth.uid());
drop policy if exists cards_update_access on public.cards;
create policy cards_update_access on public.cards for update to authenticated using(profile_id=auth.uid() or public.is_staff()) with check(profile_id=auth.uid() or public.is_staff());

drop policy if exists applications_insert_own on public.applications;
create policy applications_insert_own on public.applications for insert to authenticated with check(profile_id=auth.uid());
drop policy if exists applications_update_staff on public.applications;
create policy applications_update_staff on public.applications for update to authenticated using(public.is_staff()) with check(public.is_staff());

drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications for update to authenticated using(profile_id=auth.uid()) with check(profile_id=auth.uid());
drop policy if exists notifications_insert_staff on public.notifications;
create policy notifications_insert_staff on public.notifications for insert to authenticated with check(public.is_staff());

-- Atomic sandbox internal transfer.
create or replace function public.submit_internal_transfer(p_from uuid,p_to uuid,p_amount numeric)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_uid uuid:=auth.uid(); v_from public.accounts; v_to public.accounts; v_id uuid;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Amount must be greater than zero'; end if;
  if p_from=p_to then raise exception 'Choose two different accounts'; end if;
  select * into v_from from public.accounts where id=p_from and profile_id=v_uid and status='active' for update;
  select * into v_to from public.accounts where id=p_to and profile_id=v_uid and status='active' for update;
  if v_from.id is null or v_to.id is null then raise exception 'Active account not found'; end if;
  if v_from.balance<p_amount then raise exception 'Insufficient sandbox balance'; end if;
  update public.accounts set balance=balance-p_amount where id=p_from;
  update public.accounts set balance=balance+p_amount where id=p_to;
  insert into public.transfers(profile_id,from_account_id,to_account_id,from_name,to_name,amount,status)
  values(v_uid,p_from,p_to,v_from.name,v_to.name,p_amount,'completed') returning id into v_id;
  insert into public.transactions(profile_id,account_id,description,kind,amount,status) values
    (v_uid,p_from,'Internal transfer to '||v_to.name,'debit',-p_amount,'posted'),
    (v_uid,p_to,'Internal transfer from '||v_from.name,'credit',p_amount,'posted');
  insert into public.notifications(profile_id,title,body) values(v_uid,'Transfer completed','A sandbox transfer of $'||to_char(p_amount,'FM999999990.00')||' was completed.');
  return v_id;
end $$;
grant execute on function public.submit_internal_transfer(uuid,uuid,numeric) to authenticated;

-- Staff review creates a sandbox account when approved.
create or replace function public.review_application(p_application uuid,p_decision text,p_note text default null)
returns void language plpgsql security definer set search_path=public as $$
declare a public.applications; acct_type text; acct_name text;
begin
  if not public.is_staff() then raise exception 'Staff access required'; end if;
  if lower(p_decision) not in ('approved','declined','under_review') then raise exception 'Invalid decision'; end if;
  select * into a from public.applications where id=p_application for update;
  if a.id is null then raise exception 'Application not found'; end if;
  update public.applications set status=lower(p_decision),decision_note=p_note,reviewed_at=now(),reviewed_by=auth.uid() where id=a.id;
  if lower(p_decision)='approved' and not exists(select 1 from public.accounts where profile_id=a.profile_id and name=a.title) then
    acct_type:=case when lower(a.title) like '%saving%' then 'savings' when lower(a.title) like '%business%' then 'business' else 'checking' end;
    acct_name:=coalesce(a.title,'Approved Account');
    insert into public.accounts(profile_id,name,type,balance,status,last4)
    values(a.profile_id,acct_name,acct_type,0,'active',lpad((floor(random()*10000))::int::text,4,'0'));
  end if;
  insert into public.notifications(profile_id,title,body) values(a.profile_id,'Application '||replace(initcap(lower(p_decision)),'_',' '),coalesce(a.title,'Application')||' is now '||replace(lower(p_decision),'_',' ')||'.'||case when p_note is not null then ' '||p_note else '' end);
end $$;
grant execute on function public.review_application(uuid,text,text) to authenticated;

create or replace function public.issue_sandbox_card(p_card uuid)
returns void language plpgsql security definer set search_path=public as $$
declare c public.cards;
begin
 if not public.is_staff() then raise exception 'Staff access required'; end if;
 select * into c from public.cards where id=p_card for update;
 if c.id is null then raise exception 'Card request not found'; end if;
 update public.cards set status='active',last4=lpad((floor(random()*10000))::int::text,4,'0'),locked=false where id=p_card;
 insert into public.notifications(profile_id,title,body) values(c.profile_id,'Sandbox card activated',c.card_type||' ending in a generated test last-four is active in the sandbox portal.');
end $$;
grant execute on function public.issue_sandbox_card(uuid) to authenticated;

-- Set your admin after creating/signing in to the account. Replace the email, then run this one line separately:
-- update public.profiles set role='owner' where lower(email)=lower('YOUR-EMAIL-HERE');
