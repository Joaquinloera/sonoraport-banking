-- TMM SonoraPort Banking V27: external transfer lifecycle hardening.
-- Extends provider payment reservations without inventing provider settlement state.

alter table public.payment_reservations
  add column if not exists payment_method text,
  add column if not exists direction text not null default 'outgoing',
  add column if not exists return_code text,
  add column if not exists returned_at timestamptz;

alter table public.payment_reservations
  drop constraint if exists payment_reservations_direction_check;
alter table public.payment_reservations
  add constraint payment_reservations_direction_check
  check (direction in ('incoming','outgoing'));

create index if not exists payment_reservations_provider_payment_idx
  on public.payment_reservations(provider_payment_id)
  where provider_payment_id is not null;

create index if not exists payment_reservations_profile_status_created_idx
  on public.payment_reservations(profile_id,status,created_at desc);

create or replace view public.customer_transaction_history
with (security_invoker = true)
as
select
  r.id as payment_id,
  r.profile_id,
  r.provider_account_link_id,
  r.amount,
  r.currency,
  r.status,
  r.provider_status,
  r.provider_payment_id,
  r.payment_method,
  r.direction,
  r.return_code,
  r.correlation_id,
  r.created_at,
  r.updated_at,
  r.settled_at,
  r.released_at,
  r.returned_at,
  r.failure_reason
from public.payment_reservations r;

grant select on public.customer_transaction_history to authenticated;
