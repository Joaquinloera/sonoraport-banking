create table if not exists public.operator_role_assignments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role_name text not null check (role_name in ('super_admin','onboarding_reviewer','onboarding_activator','beneficiary_reviewer','payment_reviewer','payment_approver','dispute_reviewer','refund_reviewer','refund_approver','auditor','operations')),
  active boolean not null default true,
  assigned_by uuid references auth.users(id),
  assigned_at timestamptz not null default now(),
  revoked_by uuid references auth.users(id),
  revoked_at timestamptz,
  unique(user_id, role_name)
);

create table if not exists public.operator_action_separation (
  id bigint generated always as identity primary key,
  actor_user_id uuid not null references auth.users(id),
  resource_type text not null,
  resource_id text not null,
  action_name text not null,
  correlation_id text,
  created_at timestamptz not null default now(),
  unique(actor_user_id, resource_type, resource_id, action_name)
);
create index if not exists operator_action_resource_idx on public.operator_action_separation(resource_type, resource_id, created_at desc);

alter table public.operator_role_assignments enable row level security;
alter table public.operator_action_separation enable row level security;
revoke all on public.operator_role_assignments from anon, authenticated;
revoke all on public.operator_action_separation from anon, authenticated;
-- All writes and administrative reads are service-role only through Netlify functions.
