-- STEP 5: controlled J.P. Morgan payment certification records.
-- Run once in Supabase SQL Editor before enabling the certification payment.
create table if not exists public.jpmorgan_payment_certifications (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  linked_account_id uuid references public.money_provider_account_links(id) on delete set null,
  external_payment_id text not null unique,
  provider_payment_id text,
  destination_fingerprint text not null,
  amount numeric(14,2) not null check (amount > 0),
  currency text not null,
  payment_method text not null,
  status text not null default 'created',
  correlation_id text,
  failure_code text,
  provider_response_received_at timestamptz,
  callback_event_id text,
  callback_received_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists jpm_cert_profile_created_idx
  on public.jpmorgan_payment_certifications(profile_id, created_at desc);
create index if not exists jpm_cert_provider_payment_idx
  on public.jpmorgan_payment_certifications(provider_payment_id);

alter table public.jpmorgan_payment_certifications enable row level security;
drop policy if exists jpm_certifications_own_select on public.jpmorgan_payment_certifications;
create policy jpm_certifications_own_select
  on public.jpmorgan_payment_certifications for select to authenticated
  using (profile_id = auth.uid());

revoke insert, update, delete on public.jpmorgan_payment_certifications from anon, authenticated;
grant select on public.jpmorgan_payment_certifications to authenticated;
