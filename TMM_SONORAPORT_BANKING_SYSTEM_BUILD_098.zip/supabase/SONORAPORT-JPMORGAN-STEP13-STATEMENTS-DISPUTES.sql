-- SonoraPort J.P. Morgan Step 13: statements, reconciliation reports, and disputes
-- Run after Step 12.

create table if not exists public.payment_disputes (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references auth.users(id) on delete cascade,
  payment_id uuid not null references public.payment_reservations(id) on delete restrict,
  reason_code text not null,
  customer_statement text not null,
  status text not null default 'submitted' check (status in ('submitted','under_review','information_required','resolved_customer','resolved_merchant','rejected','closed')),
  resolution_notes text,
  provider_case_id text,
  correlation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  resolved_at timestamptz,
  unique(profile_id, payment_id)
);

create index if not exists payment_disputes_profile_created_idx
  on public.payment_disputes(profile_id, created_at desc);
create index if not exists payment_disputes_status_idx
  on public.payment_disputes(status, created_at);

create table if not exists public.reconciliation_reports (
  id uuid primary key default gen_random_uuid(),
  report_month date not null,
  generated_by uuid references auth.users(id) on delete set null,
  total_transactions integer not null default 0,
  total_settled numeric(20,2) not null default 0,
  total_failed numeric(20,2) not null default 0,
  total_held numeric(20,2) not null default 0,
  mismatch_count integer not null default 0,
  report_hash text not null,
  correlation_id text,
  generated_at timestamptz not null default now(),
  unique(report_month, report_hash)
);

alter table public.payment_disputes enable row level security;
alter table public.reconciliation_reports enable row level security;

revoke all on public.payment_disputes from public, anon;
revoke all on public.reconciliation_reports from public, anon, authenticated;
grant select, insert on public.payment_disputes to authenticated;
grant all on public.payment_disputes to service_role;
grant all on public.reconciliation_reports to service_role;

drop policy if exists payment_disputes_customer_select on public.payment_disputes;
create policy payment_disputes_customer_select on public.payment_disputes
for select to authenticated
using (profile_id = auth.uid());

drop policy if exists payment_disputes_customer_insert on public.payment_disputes;
create policy payment_disputes_customer_insert on public.payment_disputes
for insert to authenticated
with check (profile_id = auth.uid());

create or replace view public.customer_statement_transactions
with (security_invoker = true)
as
select
  r.id as payment_id,
  r.profile_id,
  r.provider_account_link_id,
  r.amount,
  r.currency,
  r.status,
  r.provider_status,
  r.provider_payment_id,
  r.correlation_id,
  r.created_at,
  r.settled_at,
  r.released_at,
  r.failure_reason
from public.payment_reservations r;

grant select on public.customer_statement_transactions to authenticated;
