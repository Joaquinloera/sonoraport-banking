-- SONORAPORT V14 TRANSACTIONS PATCH
-- Sandbox ledger activity only. Safe to run more than once.

create or replace function public.post_sandbox_activity(
  p_account uuid,
  p_kind text,
  p_amount numeric,
  p_description text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid:=auth.uid();
  v_account public.accounts;
  v_signed numeric;
  v_tx uuid;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if lower(coalesce(p_kind,'')) not in ('deposit','withdrawal') then raise exception 'Invalid sandbox activity type'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Amount must be greater than zero'; end if;

  select * into v_account
  from public.accounts
  where id=p_account and profile_id=v_uid and status='active'
  for update;

  if v_account.id is null then raise exception 'Active account not found'; end if;
  if lower(p_kind)='withdrawal' and v_account.balance<p_amount then raise exception 'Insufficient sandbox balance'; end if;

  v_signed:=case when lower(p_kind)='withdrawal' then -p_amount else p_amount end;

  update public.accounts set balance=balance+v_signed where id=v_account.id;

  insert into public.transactions(profile_id,account_id,description,kind,amount,status)
  values(v_uid,v_account.id,coalesce(nullif(trim(p_description),''),case when lower(p_kind)='deposit' then 'Sandbox test deposit' else 'Sandbox test withdrawal' end),lower(p_kind),v_signed,'posted')
  returning id into v_tx;

  insert into public.notifications(profile_id,title,body)
  values(v_uid,'Sandbox activity posted',case when lower(p_kind)='deposit' then 'A test deposit of $' else 'A test withdrawal of $' end||to_char(p_amount,'FM999999990.00')||' was posted to '||v_account.name||'.');

  return v_tx;
end $$;

grant execute on function public.post_sandbox_activity(uuid,text,numeric,text) to authenticated;
