-- SonoraPort V11 Complete Portal schema repair
-- Safe to run more than once. It does not create balances, approvals, cards, or transactions.

alter table if exists public.applications add column if not exists reference text;
alter table if exists public.applications add column if not exists title text;
alter table if exists public.applications add column if not exists status text default 'submitted';
alter table if exists public.applications add column if not exists created_at timestamptz default now();

update public.applications
set reference = 'SP-APP-' || upper(substr(replace(id::text, '-', ''), 1, 8))
where reference is null;

create unique index if not exists applications_reference_unique_idx
on public.applications(reference)
where reference is not null;

create index if not exists applications_profile_created_idx
on public.applications(profile_id, created_at desc);
create index if not exists accounts_profile_created_idx
on public.accounts(profile_id, created_at desc);
create index if not exists transactions_profile_created_idx
on public.transactions(profile_id, created_at desc);
create index if not exists transfers_profile_created_idx
on public.transfers(profile_id, created_at desc);
create index if not exists cards_profile_created_idx
on public.cards(profile_id, created_at desc);

alter table public.applications enable row level security;
drop policy if exists applications_own on public.applications;
create policy applications_own on public.applications
for all to authenticated
using (profile_id = auth.uid())
with check (profile_id = auth.uid());

-- Verification only
select 'applications' as table_name, count(*) as rows from public.applications
union all select 'accounts', count(*) from public.accounts
union all select 'transactions', count(*) from public.transactions
union all select 'transfers', count(*) from public.transfers
union all select 'cards', count(*) from public.cards;
