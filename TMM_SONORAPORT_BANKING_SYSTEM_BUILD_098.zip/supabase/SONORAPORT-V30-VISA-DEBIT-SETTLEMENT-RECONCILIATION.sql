-- Build 065: Visa Debit provider settlement + reconciliation verification.
-- Settlement clears the provider-side captured obligation only; customer cash was debited at capture in V29.
create table if not exists public.card_settlement_events (
 id uuid primary key default gen_random_uuid(), provider text not null, provider_event_id text not null,
 provider_transaction_id text not null, provider_settlement_id text not null, provider_reference_id text,
 provider_account_link_id uuid references public.provider_accounts(id) on delete restrict,
 profile_id uuid references public.profiles(id) on delete cascade, amount numeric(20,2) not null,
 currency text not null, settlement_date date, outcome text not null check(outcome in ('settled','exception')),
 capture_journal_id uuid references public.ledger_journals(id) on delete restrict,
 settlement_journal_id uuid references public.ledger_journals(id) on delete restrict,
 correlation_id text, created_at timestamptz not null default now(), unique(provider,provider_event_id),
 unique(provider,provider_settlement_id,provider_transaction_id)
);
create index if not exists card_settlement_tx_idx on public.card_settlement_events(provider,provider_transaction_id,created_at desc);
alter table public.card_settlement_events enable row level security;
revoke all on public.card_settlement_events from public,anon,authenticated; grant all on public.card_settlement_events to service_role;
create policy card_settlement_events_select_own on public.card_settlement_events for select to authenticated using(profile_id=auth.uid());

create or replace function public.apply_visa_debit_settlement_event(
 p_provider text,p_provider_event_id text,p_provider_transaction_id text,p_provider_settlement_id text,
 p_amount numeric,p_currency text,p_provider_reference_id text default null,p_settlement_date date default null,p_correlation_id text default null
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_capture public.card_lifecycle_applications%rowtype; v_hold public.card_authorization_holds%rowtype;
 v_existing public.card_settlement_events%rowtype; v_journal uuid; v_exception text; v_debits numeric; v_credits numeric;
begin
 if coalesce(p_provider_event_id,'')='' or coalesce(p_provider_transaction_id,'')='' or coalesce(p_provider_settlement_id,'')='' then raise exception 'SETTLEMENT_IDENTIFIERS_REQUIRED'; end if;
 if p_amount is null or p_amount<=0 then raise exception 'SETTLEMENT_AMOUNT_INVALID'; end if;
 if upper(coalesce(p_currency,''))<>'USD' then raise exception 'VISA_DEBIT_SETTLEMENT_USD_ONLY'; end if;
 select * into v_existing from public.card_settlement_events where provider=p_provider and provider_event_id=p_provider_event_id;
 if found then return jsonb_build_object('settled',v_existing.outcome='settled','duplicate',true,'outcome',v_existing.outcome,'journalId',v_existing.settlement_journal_id); end if;
 select * into v_capture from public.card_lifecycle_applications where provider=p_provider and provider_transaction_id=p_provider_transaction_id and event_type='capture' and outcome='applied' order by created_at desc limit 1;
 if not found then v_exception:='CAPTURE_NOT_FOUND';
 else
   select * into v_hold from public.card_authorization_holds where provider=p_provider and provider_transaction_id=p_provider_transaction_id for update;
   if not found or v_hold.status<>'captured' then v_exception:='CAPTURE_HOLD_NOT_SETTLEABLE';
   elsif v_hold.captured_amount<>p_amount then v_exception:='SETTLEMENT_AMOUNT_MISMATCH';
   elsif upper(v_hold.currency)<>'USD' then v_exception:='SETTLEMENT_CURRENCY_MISMATCH'; end if;
 end if;
 if v_exception is null then
   select total_debits,total_credits into v_debits,v_credits from public.ledger_journals where id=v_capture.journal_id;
   if not found or v_debits<>v_credits then v_exception:='CAPTURE_LEDGER_UNBALANCED';
   elsif v_debits<>(v_hold.captured_amount+v_hold.authorized_amount) then v_exception:='CAPTURE_LEDGER_TOTAL_MISMATCH'; end if;
 end if;
 if v_exception is not null then
   insert into public.card_reconciliation_exceptions(provider,provider_event_id,provider_transaction_id,exception_code,details)
   values(p_provider,p_provider_event_id,p_provider_transaction_id,v_exception,jsonb_build_object('settlementId',p_provider_settlement_id,'amount',p_amount,'currency','USD','providerReferenceId',p_provider_reference_id,'captureJournalId',v_capture.journal_id,'correlationId',p_correlation_id))
   on conflict(provider,provider_event_id,exception_code) do nothing;
   insert into public.card_settlement_events(provider,provider_event_id,provider_transaction_id,provider_settlement_id,provider_reference_id,provider_account_link_id,profile_id,amount,currency,settlement_date,outcome,capture_journal_id,correlation_id)
   values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_settlement_id,p_provider_reference_id,v_capture.provider_account_link_id,v_capture.profile_id,p_amount,'USD',p_settlement_date,'exception',v_capture.journal_id,p_correlation_id);
   return jsonb_build_object('settled',false,'duplicate',false,'exception',v_exception);
 end if;
 v_journal:=gen_random_uuid();
 insert into public.ledger_journals(id,profile_id,event_type,currency,total_debits,total_credits,correlation_id) values(v_journal,v_capture.profile_id,'visa_debit_network_settlement','USD',p_amount,p_amount,p_correlation_id);
 insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
  (v_journal,v_capture.profile_id,v_capture.provider_account_link_id,'provider_settlement_payable','debit',p_amount,'USD'),
  (v_journal,v_capture.profile_id,v_capture.provider_account_link_id,'provider_cash','credit',p_amount,'USD');
 insert into public.card_settlement_events(provider,provider_event_id,provider_transaction_id,provider_settlement_id,provider_reference_id,provider_account_link_id,profile_id,amount,currency,settlement_date,outcome,capture_journal_id,settlement_journal_id,correlation_id)
 values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_settlement_id,p_provider_reference_id,v_capture.provider_account_link_id,v_capture.profile_id,p_amount,'USD',p_settlement_date,'settled',v_capture.journal_id,v_journal,p_correlation_id);
 return jsonb_build_object('settled',true,'duplicate',false,'status','settled','captureJournalId',v_capture.journal_id,'settlementJournalId',v_journal,'providerSettlementId',p_provider_settlement_id);
end; $$;
revoke all on function public.apply_visa_debit_settlement_event(text,text,text,text,numeric,text,text,date,text) from public,anon,authenticated;
grant execute on function public.apply_visa_debit_settlement_event(text,text,text,text,numeric,text,text,date,text) to service_role;
