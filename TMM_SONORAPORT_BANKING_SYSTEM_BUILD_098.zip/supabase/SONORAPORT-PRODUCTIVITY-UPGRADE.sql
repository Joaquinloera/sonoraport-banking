-- SonoraPort productivity module: Tasks and Calendar
create extension if not exists pgcrypto;

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  priority text not null default 'normal' check (priority in ('normal','high','urgent')),
  due_at timestamptz,
  is_complete boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.calendar_events (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  starts_at timestamptz not null,
  notes text not null default '',
  created_at timestamptz not null default now()
);

alter table public.tasks enable row level security;
alter table public.calendar_events enable row level security;

drop policy if exists tasks_select_own on public.tasks;
create policy tasks_select_own on public.tasks for select to authenticated using (profile_id = auth.uid());
drop policy if exists tasks_insert_own on public.tasks;
create policy tasks_insert_own on public.tasks for insert to authenticated with check (profile_id = auth.uid());
drop policy if exists tasks_update_own on public.tasks;
create policy tasks_update_own on public.tasks for update to authenticated using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists tasks_delete_own on public.tasks;
create policy tasks_delete_own on public.tasks for delete to authenticated using (profile_id = auth.uid());

drop policy if exists calendar_events_select_own on public.calendar_events;
create policy calendar_events_select_own on public.calendar_events for select to authenticated using (profile_id = auth.uid());
drop policy if exists calendar_events_insert_own on public.calendar_events;
create policy calendar_events_insert_own on public.calendar_events for insert to authenticated with check (profile_id = auth.uid());
drop policy if exists calendar_events_delete_own on public.calendar_events;
create policy calendar_events_delete_own on public.calendar_events for delete to authenticated using (profile_id = auth.uid());

create index if not exists tasks_profile_due_idx on public.tasks(profile_id,due_at);
create index if not exists calendar_events_profile_start_idx on public.calendar_events(profile_id,starts_at);
