-- TMM SonoraPort Banking V26: customer card spend-state controls.
-- Provider events remain authoritative; this migration rejects authorization-state posting for locally inactive/locked cards.
create index if not exists card_holds_account_status_idx on public.card_authorization_holds(account_id,status,updated_at desc);

create or replace function public.customer_pending_card_holds()
returns table(provider_transaction_id text, account_id uuid, amount numeric, currency text, status text, authorized_at timestamptz, updated_at timestamptz)
language sql security invoker set search_path=public
as $$
  select h.provider_transaction_id,h.account_id,h.amount,h.currency,h.status,h.authorized_at,h.updated_at
  from public.card_authorization_holds h
  where h.profile_id=auth.uid() and h.status in ('authorized','captured')
  order by h.updated_at desc;
$$;
grant execute on function public.customer_pending_card_holds() to authenticated;
