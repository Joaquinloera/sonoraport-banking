-- SONORAPORT V17.1 ALL ACTIONS + API SCHEMA REFRESH
-- Sandbox operations only. Safe to run more than once.

create extension if not exists pgcrypto;

-- Required customer-facing columns.
alter table public.accounts add column if not exists last4 text;
alter table public.cards add column if not exists locked boolean not null default false;
alter table public.cards add column if not exists nickname text;
alter table public.profiles add column if not exists preferences jsonb not null default '{"transaction_alerts":true,"application_alerts":true}'::jsonb;

-- Required notification permissions and policy.
alter table public.notifications enable row level security;
drop policy if exists notifications_select_access on public.notifications;
create policy notifications_select_access on public.notifications for select to authenticated
using(profile_id=auth.uid() or public.is_staff());
drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications for update to authenticated
using(profile_id=auth.uid()) with check(profile_id=auth.uid());
grant select on public.notifications to authenticated;
grant update(read) on public.notifications to authenticated;

-- Customer insert and safe-update grants used by portal buttons.
grant select on public.accounts, public.transactions, public.transfers, public.cards, public.applications, public.secure_messages to authenticated;
grant insert on public.transfers, public.cards, public.applications, public.secure_messages to authenticated;
grant update(locked) on public.cards to authenticated;
grant update(full_name,preferences) on public.profiles to authenticated;

-- Atomic sandbox deposit/withdrawal.
create or replace function public.post_sandbox_activity(
  p_account uuid,
  p_kind text,
  p_amount numeric,
  p_description text default null
)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  v_uid uuid:=auth.uid();
  v_account public.accounts;
  v_signed numeric;
  v_tx uuid;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if lower(coalesce(p_kind,'')) not in ('deposit','withdrawal') then raise exception 'Invalid sandbox activity type'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Amount must be greater than zero'; end if;

  select * into v_account from public.accounts
  where id=p_account and profile_id=v_uid and lower(status)='active'
  for update;

  if v_account.id is null then raise exception 'Active account not found'; end if;
  if lower(p_kind)='withdrawal' and v_account.balance<p_amount then raise exception 'Insufficient sandbox balance'; end if;

  v_signed:=case when lower(p_kind)='withdrawal' then -p_amount else p_amount end;
  update public.accounts set balance=balance+v_signed where id=v_account.id;

  insert into public.transactions(profile_id,account_id,description,kind,amount,status)
  values(v_uid,v_account.id,
    coalesce(nullif(trim(p_description),''),case when lower(p_kind)='deposit' then 'Sandbox test deposit' else 'Sandbox test withdrawal' end),
    lower(p_kind),v_signed,'posted') returning id into v_tx;

  insert into public.notifications(profile_id,title,body)
  values(v_uid,'Sandbox activity posted',
    case when lower(p_kind)='deposit' then 'A test deposit of $' else 'A test withdrawal of $' end||
    to_char(p_amount,'FM999999990.00')||' was posted to '||v_account.name||'.');
  return v_tx;
end $$;
revoke all on function public.post_sandbox_activity(uuid,text,numeric,text) from public;
grant execute on function public.post_sandbox_activity(uuid,text,numeric,text) to authenticated;

-- Atomic transfer between the signed-in customer's own active accounts.
create or replace function public.submit_internal_transfer(p_from uuid,p_to uuid,p_amount numeric)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_uid uuid:=auth.uid(); v_from public.accounts; v_to public.accounts; v_id uuid;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if p_amount is null or p_amount<=0 then raise exception 'Amount must be greater than zero'; end if;
  if p_from=p_to then raise exception 'Choose two different accounts'; end if;
  select * into v_from from public.accounts where id=p_from and profile_id=v_uid and lower(status)='active' for update;
  select * into v_to from public.accounts where id=p_to and profile_id=v_uid and lower(status)='active' for update;
  if v_from.id is null or v_to.id is null then raise exception 'Active account not found'; end if;
  if v_from.balance<p_amount then raise exception 'Insufficient sandbox balance'; end if;
  update public.accounts set balance=balance-p_amount where id=p_from;
  update public.accounts set balance=balance+p_amount where id=p_to;
  insert into public.transfers(profile_id,from_account_id,to_account_id,from_name,to_name,amount,status)
  values(v_uid,p_from,p_to,v_from.name,v_to.name,p_amount,'completed') returning id into v_id;
  insert into public.transactions(profile_id,account_id,description,kind,amount,status) values
    (v_uid,p_from,'Internal transfer to '||v_to.name,'debit',-p_amount,'posted'),
    (v_uid,p_to,'Internal transfer from '||v_from.name,'credit',p_amount,'posted');
  insert into public.notifications(profile_id,title,body)
  values(v_uid,'Transfer completed','A sandbox transfer of $'||to_char(p_amount,'FM999999990.00')||' was completed.');
  return v_id;
end $$;
revoke all on function public.submit_internal_transfer(uuid,uuid,numeric) from public;
grant execute on function public.submit_internal_transfer(uuid,uuid,numeric) to authenticated;

-- Force PostgREST/Supabase API to discover the recreated functions immediately.
notify pgrst, 'reload schema';
