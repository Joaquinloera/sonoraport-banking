create table if not exists public.payment_approval_requests (
  id uuid primary key,
  requester_profile_id uuid not null,
  linked_account_id uuid not null,
  provider_account_id text not null,
  destination_id text not null,
  amount numeric(18,2) not null check (amount > 0),
  currency text not null,
  payment_method text not null,
  memo text,
  risk_score integer not null default 0 check (risk_score between 0 and 100),
  risk_reasons jsonb not null default '[]'::jsonb,
  required_approvals integer not null default 1 check (required_approvals between 1 and 2),
  approval_count integer not null default 0,
  status text not null default 'pending_approval',
  correlation_id text,
  provider_payment_id text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  submitted_at timestamptz
);

create table if not exists public.payment_approvals (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.payment_approval_requests(id) on delete cascade,
  approver_profile_id uuid not null,
  decision text not null check (decision in ('approved','rejected')),
  note text,
  created_at timestamptz not null default now(),
  unique(request_id, approver_profile_id)
);

alter table public.payment_approval_requests enable row level security;
alter table public.payment_approvals enable row level security;

create policy "requesters can view own payment reviews"
on public.payment_approval_requests for select
to authenticated
using (requester_profile_id = auth.uid());

revoke insert, update, delete on public.payment_approval_requests from anon, authenticated;
revoke all on public.payment_approvals from anon, authenticated;
