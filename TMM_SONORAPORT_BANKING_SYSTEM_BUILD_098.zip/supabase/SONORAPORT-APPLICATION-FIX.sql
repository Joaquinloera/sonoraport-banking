-- SonoraPort application submission repair
-- Safe for the existing empty public.applications table.

create extension if not exists pgcrypto;

-- Ensure the columns used by the live website exist.
alter table public.applications add column if not exists id uuid default gen_random_uuid();
alter table public.applications add column if not exists profile_id uuid;
alter table public.applications add column if not exists title text;
alter table public.applications add column if not exists reference text;
alter table public.applications add column if not exists status text default 'submitted';
alter table public.applications add column if not exists created_at timestamptz default now();

-- Normalize defaults required by browser submissions.
alter table public.applications alter column id set default gen_random_uuid();
alter table public.applications alter column status set default 'submitted';
alter table public.applications alter column created_at set default now();

-- Existing versions of this table may contain additional required columns.
-- Because the table is currently empty, make non-core columns optional so
-- the live form can insert without inventing data.
do $$
declare c record;
begin
  for c in
    select column_name
    from information_schema.columns
    where table_schema='public'
      and table_name='applications'
      and is_nullable='NO'
      and column_name not in ('id','profile_id','title','reference','status','created_at')
  loop
    execute format('alter table public.applications alter column %I drop not null', c.column_name);
  end loop;
end $$;

-- Core constraints and indexes.
alter table public.applications alter column profile_id set not null;
alter table public.applications alter column title set not null;
alter table public.applications alter column status set not null;
alter table public.applications alter column created_at set not null;

create unique index if not exists applications_reference_unique
  on public.applications(reference)
  where reference is not null;
create index if not exists applications_profile_created_idx
  on public.applications(profile_id, created_at desc);

alter table public.applications enable row level security;

drop policy if exists "applications_select_own" on public.applications;
create policy "applications_select_own"
on public.applications for select
to authenticated
using (profile_id = auth.uid());

drop policy if exists "applications_insert_own" on public.applications;
create policy "applications_insert_own"
on public.applications for insert
to authenticated
with check (profile_id = auth.uid());

drop policy if exists "applications_update_own" on public.applications;
create policy "applications_update_own"
on public.applications for update
to authenticated
using (profile_id = auth.uid())
with check (profile_id = auth.uid());

-- Verification result. This should return the six core columns.
select column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema='public' and table_name='applications'
  and column_name in ('id','profile_id','title','reference','status','created_at')
order by ordinal_position;
