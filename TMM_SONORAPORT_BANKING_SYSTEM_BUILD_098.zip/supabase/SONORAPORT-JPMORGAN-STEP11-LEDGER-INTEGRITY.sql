-- SonoraPort J.P. Morgan Step 11: customer account controls and ledger integrity
-- Run after the provider-account and Step 9/10 migrations.

create table if not exists public.provider_balance_snapshots (
  provider_account_link_id uuid primary key references public.provider_accounts(id) on delete cascade,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  currency text not null default 'USD',
  current_balance numeric(20,2) not null default 0,
  available_balance numeric(20,2) not null default 0,
  provider_as_of timestamptz,
  refreshed_at timestamptz not null default now(),
  check (current_balance >= 0),
  check (available_balance >= 0)
);

create table if not exists public.payment_reservations (
  id uuid primary key,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  provider_account_link_id uuid not null references public.provider_accounts(id) on delete restrict,
  amount numeric(20,2) not null check (amount > 0),
  currency text not null,
  status text not null default 'reserved' check (status in ('reserved','submitted','settled','released','failed')),
  provider_payment_id text,
  correlation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider_payment_id)
);

create table if not exists public.ledger_journals (
  id uuid primary key,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  reservation_id uuid unique references public.payment_reservations(id) on delete restrict,
  event_type text not null,
  currency text not null,
  total_debits numeric(20,2) not null,
  total_credits numeric(20,2) not null,
  correlation_id text,
  created_at timestamptz not null default now(),
  check (total_debits = total_credits)
);

create table if not exists public.ledger_entries (
  id bigint generated always as identity primary key,
  journal_id uuid not null references public.ledger_journals(id) on delete restrict,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  provider_account_link_id uuid references public.provider_accounts(id) on delete restrict,
  ledger_account text not null,
  direction text not null check (direction in ('debit','credit')),
  amount numeric(20,2) not null check (amount > 0),
  currency text not null,
  created_at timestamptz not null default now()
);

create unique index if not exists ledger_entries_journal_account_direction_uidx
  on public.ledger_entries(journal_id, ledger_account, direction);
create index if not exists payment_reservations_account_status_idx
  on public.payment_reservations(provider_account_link_id, status);

alter table public.provider_balance_snapshots enable row level security;
alter table public.payment_reservations enable row level security;
alter table public.ledger_journals enable row level security;
alter table public.ledger_entries enable row level security;

-- Customers can read only their own snapshots and ledger evidence. Writes stay server-side.
drop policy if exists provider_balance_snapshots_select_own on public.provider_balance_snapshots;
create policy provider_balance_snapshots_select_own on public.provider_balance_snapshots
  for select to authenticated using (profile_id = auth.uid());
drop policy if exists payment_reservations_select_own on public.payment_reservations;
create policy payment_reservations_select_own on public.payment_reservations
  for select to authenticated using (profile_id = auth.uid());
drop policy if exists ledger_journals_select_own on public.ledger_journals;
create policy ledger_journals_select_own on public.ledger_journals
  for select to authenticated using (profile_id = auth.uid());
drop policy if exists ledger_entries_select_own on public.ledger_entries;
create policy ledger_entries_select_own on public.ledger_entries
  for select to authenticated using (profile_id = auth.uid());

create or replace function public.reserve_provider_payment(
  p_payment_id uuid,
  p_profile_id uuid,
  p_provider_account_link_id uuid,
  p_amount numeric,
  p_currency text,
  p_correlation_id text,
  p_max_snapshot_age_seconds integer default 300
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_snapshot public.provider_balance_snapshots%rowtype;
  v_reserved numeric(20,2);
  v_spendable numeric(20,2);
  v_journal_id uuid := gen_random_uuid();
begin
  if p_amount is null or p_amount <= 0 then raise exception 'INVALID_AMOUNT'; end if;

  perform 1 from public.provider_accounts
   where id = p_provider_account_link_id
     and profile_id = p_profile_id
     and status = 'active'
   for update;
  if not found then raise exception 'ACCOUNT_OWNERSHIP_INVALID'; end if;

  select * into v_snapshot from public.provider_balance_snapshots
   where provider_account_link_id = p_provider_account_link_id
     and profile_id = p_profile_id
     and upper(currency) = upper(p_currency)
   for update;
  if not found then raise exception 'BALANCE_SNAPSHOT_MISSING'; end if;
  if v_snapshot.refreshed_at < now() - make_interval(secs => greatest(30, p_max_snapshot_age_seconds)) then
    raise exception 'BALANCE_SNAPSHOT_STALE';
  end if;

  select coalesce(sum(amount),0) into v_reserved
    from public.payment_reservations
   where provider_account_link_id = p_provider_account_link_id
     and upper(currency) = upper(p_currency)
     and status in ('reserved','submitted');

  v_spendable := greatest(0, v_snapshot.available_balance - v_reserved);
  if p_amount > v_spendable then raise exception 'INSUFFICIENT_AVAILABLE_BALANCE'; end if;

  insert into public.payment_reservations(id, profile_id, provider_account_link_id, amount, currency, status, correlation_id)
  values (p_payment_id, p_profile_id, p_provider_account_link_id, p_amount, upper(p_currency), 'reserved', p_correlation_id);

  insert into public.ledger_journals(id, profile_id, reservation_id, event_type, currency, total_debits, total_credits, correlation_id)
  values (v_journal_id, p_profile_id, p_payment_id, 'payment_reserved', upper(p_currency), p_amount, p_amount, p_correlation_id);

  insert into public.ledger_entries(journal_id, profile_id, provider_account_link_id, ledger_account, direction, amount, currency)
  values
    (v_journal_id, p_profile_id, p_provider_account_link_id, 'customer_available_funds', 'debit', p_amount, upper(p_currency)),
    (v_journal_id, p_profile_id, p_provider_account_link_id, 'outgoing_payment_hold', 'credit', p_amount, upper(p_currency));

  return jsonb_build_object('reservationId', p_payment_id, 'journalId', v_journal_id, 'spendableBefore', v_spendable, 'spendableAfter', v_spendable - p_amount);
exception
  when unique_violation then raise exception 'DUPLICATE_PAYMENT_RESERVATION';
end;
$$;

create or replace function public.update_payment_reservation(
  p_payment_id uuid,
  p_status text,
  p_provider_payment_id text default null
) returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_status not in ('submitted','settled','released','failed') then raise exception 'INVALID_RESERVATION_STATUS'; end if;
  update public.payment_reservations
     set status = p_status,
         provider_payment_id = coalesce(p_provider_payment_id, provider_payment_id),
         updated_at = now()
   where id = p_payment_id;
  if not found then raise exception 'PAYMENT_RESERVATION_NOT_FOUND'; end if;
end;
$$;

revoke all on function public.reserve_provider_payment(uuid,uuid,uuid,numeric,text,text,integer) from public, anon, authenticated;
revoke all on function public.update_payment_reservation(uuid,text,text) from public, anon, authenticated;
grant execute on function public.reserve_provider_payment(uuid,uuid,uuid,numeric,text,text,integer) to service_role;
grant execute on function public.update_payment_reservation(uuid,text,text) to service_role;
