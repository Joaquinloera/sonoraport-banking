create table if not exists public.jpmorgan_health_snapshots (
  id uuid primary key default gen_random_uuid(),
  healthy boolean not null,
  payments_allowed boolean not null,
  environment text not null,
  failed_checks text[] not null default '{}',
  correlation_id text,
  checked_by uuid,
  checked_at timestamptz not null default now()
);
create table if not exists public.jpmorgan_incidents (
  id uuid primary key default gen_random_uuid(),
  severity text not null check (severity in ('low','medium','high','critical')),
  status text not null default 'open' check (status in ('open','investigating','contained','resolved')),
  incident_type text not null,
  summary text not null,
  details jsonb not null default '{}'::jsonb,
  correlation_id text,
  opened_by uuid,
  assigned_to uuid,
  opened_at timestamptz not null default now(),
  resolved_at timestamptz,
  updated_at timestamptz not null default now()
);
create index if not exists jpmorgan_health_snapshots_checked_at_idx on public.jpmorgan_health_snapshots(checked_at desc);
create index if not exists jpmorgan_incidents_status_idx on public.jpmorgan_incidents(status, opened_at desc);
alter table public.jpmorgan_health_snapshots enable row level security;
alter table public.jpmorgan_incidents enable row level security;
revoke all on public.jpmorgan_health_snapshots from anon, authenticated;
revoke all on public.jpmorgan_incidents from anon, authenticated;
