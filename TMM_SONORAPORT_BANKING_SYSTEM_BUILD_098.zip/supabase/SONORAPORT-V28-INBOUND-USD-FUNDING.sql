-- Build 063: idempotent inbound provider funding events.
create table if not exists public.provider_funding_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  provider_account_link_id uuid not null references public.provider_accounts(id) on delete restrict,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  event_type text not null check (event_type in ('deposit_settled','deposit_reversed')),
  amount numeric(20,2) not null check (amount > 0),
  currency text not null check (upper(currency) = 'USD'),
  provider_as_of timestamptz,
  correlation_id text,
  created_at timestamptz not null default now(),
  unique(provider, provider_event_id)
);
alter table public.provider_funding_events enable row level security;
drop policy if exists provider_funding_events_select_own on public.provider_funding_events;
create policy provider_funding_events_select_own on public.provider_funding_events for select to authenticated using (profile_id = auth.uid());

create or replace function public.apply_provider_funding_event(
 p_provider text, p_provider_event_id text, p_provider_account_id text,
 p_event_type text, p_amount numeric, p_currency text,
 p_provider_as_of timestamptz default null, p_correlation_id text default null
) returns jsonb language plpgsql security definer set search_path=public as $$
declare
 v_link public.provider_accounts%rowtype; v_event_id uuid; v_journal uuid := gen_random_uuid(); v_delta numeric(20,2);
begin
 if p_event_type not in ('deposit_settled','deposit_reversed') then raise exception 'FUNDING_EVENT_UNSUPPORTED'; end if;
 if p_amount is null or p_amount <= 0 then raise exception 'INVALID_AMOUNT'; end if;
 if upper(coalesce(p_currency,'')) <> 'USD' then raise exception 'USD_ONLY'; end if;
 select * into v_link from public.provider_accounts where provider=p_provider and provider_account_id=p_provider_account_id and status='active' limit 1 for update;
 if not found then raise exception 'PROVIDER_ACCOUNT_NOT_LINKED'; end if;
 select id into v_event_id from public.provider_funding_events where provider=p_provider and provider_event_id=p_provider_event_id;
 if found then return jsonb_build_object('applied',false,'duplicate',true,'fundingEventId',v_event_id); end if;
 v_delta := case when p_event_type='deposit_settled' then p_amount else -p_amount end;
 if v_delta < 0 then
   perform 1 from public.provider_balance_snapshots where provider_account_link_id=v_link.id and available_balance >= abs(v_delta) for update;
   if not found then raise exception 'INSUFFICIENT_AVAILABLE_BALANCE'; end if;
 end if;
 insert into public.provider_funding_events(provider,provider_event_id,provider_account_link_id,profile_id,event_type,amount,currency,provider_as_of,correlation_id)
 values(p_provider,p_provider_event_id,v_link.id,v_link.profile_id,p_event_type,p_amount,'USD',p_provider_as_of,p_correlation_id) returning id into v_event_id;
 insert into public.provider_balance_snapshots(provider_account_link_id,profile_id,currency,current_balance,available_balance,provider_as_of,refreshed_at)
 values(v_link.id,v_link.profile_id,'USD',greatest(0,v_delta),greatest(0,v_delta),p_provider_as_of,now())
 on conflict(provider_account_link_id) do update set
 current_balance=public.provider_balance_snapshots.current_balance+v_delta,
 available_balance=public.provider_balance_snapshots.available_balance+v_delta,
 currency='USD', provider_as_of=coalesce(excluded.provider_as_of,public.provider_balance_snapshots.provider_as_of), refreshed_at=now();
 insert into public.ledger_journals(id,profile_id,event_type,currency,total_debits,total_credits,correlation_id)
 values(v_journal,v_link.profile_id,p_event_type,'USD',p_amount,p_amount,p_correlation_id);
 if p_event_type='deposit_settled' then
   insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
   (v_journal,v_link.profile_id,v_link.id,'provider_cash','debit',p_amount,'USD'),
   (v_journal,v_link.profile_id,v_link.id,'customer_available_funds','credit',p_amount,'USD');
 else
   insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
   (v_journal,v_link.profile_id,v_link.id,'customer_available_funds','debit',p_amount,'USD'),
   (v_journal,v_link.profile_id,v_link.id,'provider_cash','credit',p_amount,'USD');
 end if;
 return jsonb_build_object('applied',true,'duplicate',false,'fundingEventId',v_event_id,'journalId',v_journal,'currency','USD');
end; $$;
revoke all on function public.apply_provider_funding_event(text,text,text,text,numeric,text,timestamptz,text) from public,anon,authenticated;
grant execute on function public.apply_provider_funding_event(text,text,text,text,numeric,text,timestamptz,text) to service_role;
