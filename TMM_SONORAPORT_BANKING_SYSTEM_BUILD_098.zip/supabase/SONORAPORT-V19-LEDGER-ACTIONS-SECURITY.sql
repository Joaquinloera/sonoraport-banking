-- SONORAPORT V19 LEDGER + CUSTOMER ACTION SECURITY
-- Run after V18. Sandbox ledger only; no real-money movement or card issuance.

-- Customers may not create transfer ledger rows directly. Transfers must use the atomic RPC.
drop policy if exists transfers_insert_own on public.transfers;
revoke insert on public.transfers from authenticated;

-- Restrict customer application creation to a submitted record owned by the caller.
drop policy if exists applications_insert_own on public.applications;
create policy applications_insert_own
  on public.applications for insert to authenticated
  with check (
    profile_id=auth.uid()
    and lower(coalesce(status,'submitted'))='submitted'
    and reviewed_at is null
    and reviewed_by is null
    and decision_note is null
  );

-- Restrict customer card requests to their own active account and a pending card record.
drop policy if exists cards_insert_own on public.cards;
create policy cards_insert_own
  on public.cards for insert to authenticated
  with check (
    profile_id=auth.uid()
    and lower(coalesce(status,'application_received'))='application_received'
    and last4 is null
    and coalesce(locked,false)=false
    and exists (
      select 1 from public.accounts a
      where a.id=account_id and a.profile_id=auth.uid() and lower(a.status)='active'
    )
  );

-- Use RPCs for customer-created application/card records so protected fields are server-set.
create or replace function public.submit_customer_application(p_title text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_uid uuid:=auth.uid(); v_id uuid; v_ref text;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if nullif(trim(coalesce(p_title,'')),'') is null then raise exception 'Application type is required'; end if;
  v_ref:='SP-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
  insert into public.applications(profile_id,title,reference,status)
  values(v_uid,trim(p_title),v_ref,'submitted') returning id into v_id;
  insert into public.notifications(profile_id,title,body)
  values(v_uid,'Application submitted',trim(p_title)||' was submitted with reference '||v_ref||'.');
  return v_id;
end $$;
revoke all on function public.submit_customer_application(text) from public;
grant execute on function public.submit_customer_application(text) to authenticated;

create or replace function public.request_sandbox_card(p_account uuid,p_card_type text,p_nickname text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_uid uuid:=auth.uid(); v_account public.accounts; v_id uuid;
begin
  if v_uid is null then raise exception 'Sign in required'; end if;
  if nullif(trim(coalesce(p_card_type,'')),'') is null then raise exception 'Card type is required'; end if;
  select * into v_account from public.accounts
  where id=p_account and profile_id=v_uid and lower(status)='active';
  if v_account.id is null then raise exception 'Active account not found'; end if;
  insert into public.cards(profile_id,account_id,card_type,nickname,status,last4,locked)
  values(v_uid,v_account.id,trim(p_card_type),nullif(trim(coalesce(p_nickname,'')),''),'application_received',null,false)
  returning id into v_id;
  insert into public.notifications(profile_id,title,body)
  values(v_uid,'Card request received','A sandbox card request was received for '||v_account.name||'.');
  return v_id;
end $$;
revoke all on function public.request_sandbox_card(uuid,text,text) from public;
grant execute on function public.request_sandbox_card(uuid,text,text) to authenticated;

-- Customers can only change the read flag on their own notifications via RPC.
drop policy if exists notifications_update_own on public.notifications;
revoke update on public.notifications from authenticated;

create or replace function public.mark_notification_read(p_notification uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  update public.notifications set read=true
  where id=p_notification and profile_id=auth.uid();
end $$;
revoke all on function public.mark_notification_read(uuid) from public;
grant execute on function public.mark_notification_read(uuid) to authenticated;

create or replace function public.mark_all_notifications_read()
returns integer language plpgsql security definer set search_path=public as $$
declare v_count integer;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  update public.notifications set read=true
  where profile_id=auth.uid() and read=false;
  get diagnostics v_count = row_count;
  return v_count;
end $$;
revoke all on function public.mark_all_notifications_read() from public;
grant execute on function public.mark_all_notifications_read() to authenticated;

notify pgrst, 'reload schema';
