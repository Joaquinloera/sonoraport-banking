-- SonoraPort J.P. Morgan Step 12: settlement posting and customer transaction history
-- Run after Step 11.

alter table public.payment_reservations
  add column if not exists provider_status text,
  add column if not exists settled_at timestamptz,
  add column if not exists released_at timestamptz,
  add column if not exists failure_reason text;

create index if not exists payment_reservations_profile_created_idx
  on public.payment_reservations(profile_id, created_at desc);

create or replace function public.finalize_payment_reservation(
  p_payment_id uuid,
  p_outcome text,
  p_provider_status text default null,
  p_provider_payment_id text default null,
  p_failure_reason text default null,
  p_correlation_id text default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_res public.payment_reservations%rowtype;
  v_journal_id uuid;
  v_event_type text;
  v_new_status text;
begin
  if p_outcome not in ('settled','released','failed') then
    raise exception 'INVALID_FINAL_OUTCOME';
  end if;

  select * into v_res
    from public.payment_reservations
   where id = p_payment_id
   for update;
  if not found then raise exception 'PAYMENT_RESERVATION_NOT_FOUND'; end if;

  -- Idempotent: a final state is never posted twice.
  if v_res.status in ('settled','released','failed') then
    return jsonb_build_object(
      'paymentId', v_res.id,
      'status', v_res.status,
      'duplicate', true
    );
  end if;

  if p_outcome = 'settled' then
    v_new_status := 'settled';
    v_event_type := 'payment_settled';
  elsif p_outcome = 'failed' then
    v_new_status := 'failed';
    v_event_type := 'payment_failed_hold_released';
  else
    v_new_status := 'released';
    v_event_type := 'payment_hold_released';
  end if;

  v_journal_id := gen_random_uuid();
  insert into public.ledger_journals(
    id, profile_id, reservation_id, event_type, currency,
    total_debits, total_credits, correlation_id
  ) values (
    v_journal_id, v_res.profile_id, null, v_event_type, v_res.currency,
    v_res.amount, v_res.amount, coalesce(p_correlation_id, v_res.correlation_id)
  );

  if p_outcome = 'settled' then
    insert into public.ledger_entries(
      journal_id, profile_id, provider_account_link_id, ledger_account,
      direction, amount, currency
    ) values
      (v_journal_id, v_res.profile_id, v_res.provider_account_link_id, 'outgoing_payment_hold', 'debit', v_res.amount, v_res.currency),
      (v_journal_id, v_res.profile_id, v_res.provider_account_link_id, 'provider_settled_payments', 'credit', v_res.amount, v_res.currency);
  else
    insert into public.ledger_entries(
      journal_id, profile_id, provider_account_link_id, ledger_account,
      direction, amount, currency
    ) values
      (v_journal_id, v_res.profile_id, v_res.provider_account_link_id, 'outgoing_payment_hold', 'debit', v_res.amount, v_res.currency),
      (v_journal_id, v_res.profile_id, v_res.provider_account_link_id, 'customer_available_funds', 'credit', v_res.amount, v_res.currency);
  end if;

  update public.payment_reservations
     set status = v_new_status,
         provider_status = nullif(p_provider_status, ''),
         provider_payment_id = coalesce(nullif(p_provider_payment_id, ''), provider_payment_id),
         settled_at = case when v_new_status = 'settled' then now() else settled_at end,
         released_at = case when v_new_status in ('released','failed') then now() else released_at end,
         failure_reason = case when v_new_status = 'failed' then nullif(left(p_failure_reason, 500), '') else failure_reason end,
         updated_at = now()
   where id = p_payment_id;

  return jsonb_build_object(
    'paymentId', p_payment_id,
    'status', v_new_status,
    'journalId', v_journal_id,
    'duplicate', false
  );
end;
$$;

create or replace view public.customer_transaction_history
with (security_invoker = true)
as
select
  r.id as payment_id,
  r.profile_id,
  r.provider_account_link_id,
  r.amount,
  r.currency,
  r.status,
  r.provider_status,
  r.provider_payment_id,
  r.correlation_id,
  r.created_at,
  r.updated_at,
  r.settled_at,
  r.released_at,
  r.failure_reason
from public.payment_reservations r;

revoke all on function public.finalize_payment_reservation(uuid,text,text,text,text,text) from public, anon, authenticated;
grant execute on function public.finalize_payment_reservation(uuid,text,text,text,text,text) to service_role;
grant select on public.customer_transaction_history to authenticated;
