create table if not exists public.jpmorgan_audit_events (
  sequence_no bigint generated always as identity primary key,
  occurred_at timestamptz not null default now(),
  correlation_id text not null,
  actor_profile_id uuid null,
  actor_email text null,
  action text not null,
  outcome text not null,
  resource_type text not null,
  resource_id text null,
  provider text not null default 'jpmorgan',
  details jsonb not null default '{}'::jsonb,
  previous_hash text null,
  event_hash text not null unique
);

create index if not exists jpmorgan_audit_events_occurred_at_idx on public.jpmorgan_audit_events (occurred_at desc);
create index if not exists jpmorgan_audit_events_correlation_idx on public.jpmorgan_audit_events (correlation_id);
create index if not exists jpmorgan_audit_events_resource_idx on public.jpmorgan_audit_events (resource_type, resource_id);

alter table public.jpmorgan_audit_events enable row level security;
revoke all on table public.jpmorgan_audit_events from anon, authenticated;
revoke all on sequence public.jpmorgan_audit_events_sequence_no_seq from anon, authenticated;
