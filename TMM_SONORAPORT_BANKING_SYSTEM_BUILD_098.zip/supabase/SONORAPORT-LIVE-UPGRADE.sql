-- SonoraPort live security and profile automation upgrade.
-- Safe to run after the eight core tables and the private documents bucket exist.

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.applications enable row level security;
alter table public.documents enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;
alter table public.ai_conversations enable row level security;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), new.email, 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Profiles
 drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
 drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid());
 drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Organizations: authenticated users may read organization names only.
 drop policy if exists "organizations_read_authenticated" on public.organizations;
create policy "organizations_read_authenticated" on public.organizations for select to authenticated using (true);

-- Applications
 drop policy if exists "applications_select_own" on public.applications;
create policy "applications_select_own" on public.applications for select to authenticated using (profile_id = auth.uid());
 drop policy if exists "applications_insert_own" on public.applications;
create policy "applications_insert_own" on public.applications for insert to authenticated with check (profile_id = auth.uid());
 drop policy if exists "applications_update_own" on public.applications;
create policy "applications_update_own" on public.applications for update to authenticated using (profile_id = auth.uid()) with check (profile_id = auth.uid());

-- Documents metadata
 drop policy if exists "documents_select_own" on public.documents;
create policy "documents_select_own" on public.documents for select to authenticated using (exists (select 1 from public.applications a where a.id = application_id and a.profile_id = auth.uid()));
 drop policy if exists "documents_insert_own" on public.documents;
create policy "documents_insert_own" on public.documents for insert to authenticated with check (exists (select 1 from public.applications a where a.id = application_id and a.profile_id = auth.uid()));
 drop policy if exists "documents_delete_own" on public.documents;
create policy "documents_delete_own" on public.documents for delete to authenticated using (exists (select 1 from public.applications a where a.id = application_id and a.profile_id = auth.uid()));

-- Messages
 drop policy if exists "messages_select_own" on public.messages;
create policy "messages_select_own" on public.messages for select to authenticated using (exists (select 1 from public.applications a where a.id = application_id and a.profile_id = auth.uid()));
 drop policy if exists "messages_insert_own" on public.messages;
create policy "messages_insert_own" on public.messages for insert to authenticated with check (sender_id = auth.uid() and exists (select 1 from public.applications a where a.id = application_id and a.profile_id = auth.uid()));

-- Notifications
 drop policy if exists "notifications_select_own" on public.notifications;
create policy "notifications_select_own" on public.notifications for select to authenticated using (profile_id = auth.uid());
 drop policy if exists "notifications_update_own" on public.notifications;
create policy "notifications_update_own" on public.notifications for update to authenticated using (profile_id = auth.uid()) with check (profile_id = auth.uid());

-- AI conversations
 drop policy if exists "ai_select_own" on public.ai_conversations;
create policy "ai_select_own" on public.ai_conversations for select to authenticated using (profile_id = auth.uid());
 drop policy if exists "ai_insert_own" on public.ai_conversations;
create policy "ai_insert_own" on public.ai_conversations for insert to authenticated with check (profile_id = auth.uid());

-- Audit logs are intentionally not readable or writable from the browser.

-- Storage policies. Files must be stored under: user_id/application_id/filename
 drop policy if exists "documents_bucket_select_own" on storage.objects;
create policy "documents_bucket_select_own" on storage.objects for select to authenticated using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
 drop policy if exists "documents_bucket_insert_own" on storage.objects;
create policy "documents_bucket_insert_own" on storage.objects for insert to authenticated with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
 drop policy if exists "documents_bucket_delete_own" on storage.objects;
create policy "documents_bucket_delete_own" on storage.objects for delete to authenticated using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
