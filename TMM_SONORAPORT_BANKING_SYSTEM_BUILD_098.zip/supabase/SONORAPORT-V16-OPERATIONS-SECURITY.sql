-- SONORAPORT V16 OPERATIONS, SECURITY, MESSAGES, AND AUDIT PATCH
-- Sandbox controls only. Safe to run more than once.
create extension if not exists pgcrypto;
alter table public.profiles add column if not exists preferences jsonb not null default '{"transaction_alerts":true,"application_alerts":true}'::jsonb;
create table if not exists public.secure_messages(
 id uuid primary key default gen_random_uuid(), profile_id uuid not null references public.profiles(id) on delete cascade,
 sender_id uuid not null, subject text not null, body text not null, direction text not null default 'customer_to_staff',
 status text not null default 'open', created_at timestamptz not null default now(), read_at timestamptz
);
create table if not exists public.audit_logs(
 id uuid primary key default gen_random_uuid(), actor_id uuid, action text not null, target_type text,
 target_id uuid, details jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create index if not exists secure_messages_profile_created_idx on public.secure_messages(profile_id,created_at desc);
create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);
alter table public.secure_messages enable row level security; alter table public.audit_logs enable row level security;
drop policy if exists secure_messages_select_access on public.secure_messages;
create policy secure_messages_select_access on public.secure_messages for select to authenticated using(profile_id=auth.uid() or public.is_staff());
drop policy if exists secure_messages_insert_access on public.secure_messages;
create policy secure_messages_insert_access on public.secure_messages for insert to authenticated with check((profile_id=auth.uid() and sender_id=auth.uid()) or public.is_staff());
drop policy if exists secure_messages_update_staff on public.secure_messages;
create policy secure_messages_update_staff on public.secure_messages for update to authenticated using(public.is_staff()) with check(public.is_staff());
drop policy if exists audit_logs_staff_read on public.audit_logs;
create policy audit_logs_staff_read on public.audit_logs for select to authenticated using(public.is_staff());
-- Customers may update only their own safe profile fields. Column grants below prevent role/email changes.
drop policy if exists profiles_customer_update on public.profiles;
create policy profiles_customer_update on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
drop policy if exists profiles_own_read on public.profiles;
create policy profiles_own_read on public.profiles for select to authenticated using(id=auth.uid());
revoke update on table public.profiles from authenticated;
grant update(full_name,preferences) on table public.profiles to authenticated;

-- Limit customer card changes to the lock flag. Staff controls continue through security-definer RPCs.
revoke update on table public.cards from authenticated;
grant update(locked) on table public.cards to authenticated;
drop policy if exists cards_update_access on public.cards;
create policy cards_update_access on public.cards for update to authenticated
 using(profile_id=auth.uid()) with check(profile_id=auth.uid());

-- New applications must enter the review queue rather than claiming an approved state.
drop policy if exists applications_insert_own on public.applications;
create policy applications_insert_own on public.applications for insert to authenticated
 with check(profile_id=auth.uid() and lower(coalesce(status,'submitted'))='submitted');

-- Customer-created secure messages must be customer-to-staff and open.
drop policy if exists secure_messages_insert_access on public.secure_messages;
create policy secure_messages_insert_access on public.secure_messages for insert to authenticated
 with check((profile_id=auth.uid() and sender_id=auth.uid() and direction='customer_to_staff' and status='open') or public.is_staff());

create or replace function public.log_admin_action(p_action text,p_target_type text,p_target_id uuid,p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path=public as $$ begin
 if not public.is_staff() then raise exception 'Staff access required'; end if;
 insert into public.audit_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),p_action,p_target_type,p_target_id,coalesce(p_details,'{}'::jsonb));
end $$; grant execute on function public.log_admin_action(text,text,uuid,jsonb) to authenticated;

create or replace function public.set_account_status(p_account uuid,p_status text,p_reason text default null)
returns void language plpgsql security definer set search_path=public as $$ declare a public.accounts; begin
 if not public.is_staff() then raise exception 'Staff access required'; end if;
 if lower(p_status) not in ('active','frozen','closed') then raise exception 'Invalid account status'; end if;
 select * into a from public.accounts where id=p_account for update; if a.id is null then raise exception 'Account not found'; end if;
 update public.accounts set status=lower(p_status) where id=a.id;
 insert into public.audit_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),'account_'||lower(p_status),'account',a.id,jsonb_build_object('reason',p_reason,'profile_id',a.profile_id));
 insert into public.notifications(profile_id,title,body) values(a.profile_id,'Account status updated',a.name||' is now '||lower(p_status)||case when p_reason is not null then '. Reason: '||p_reason else '.' end);
end $$; grant execute on function public.set_account_status(uuid,text,text) to authenticated;

create or replace function public.set_card_status(p_card uuid,p_action text,p_reason text default null)
returns void language plpgsql security definer set search_path=public as $$ declare c public.cards; v_action text:=lower(p_action); begin
 if not public.is_staff() then raise exception 'Staff access required'; end if;
 if v_action not in ('lock','unlock','cancel','replace') then raise exception 'Invalid card action'; end if;
 select * into c from public.cards where id=p_card for update; if c.id is null then raise exception 'Card not found'; end if;
 if v_action='lock' then update public.cards set locked=true where id=c.id;
 elsif v_action='unlock' then update public.cards set locked=false where id=c.id;
 elsif v_action='cancel' then update public.cards set status='cancelled',locked=true where id=c.id;
 else update public.cards set status='active',locked=false,last4=lpad((floor(random()*10000))::int::text,4,'0') where id=c.id; end if;
 insert into public.audit_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),'card_'||v_action,'card',c.id,jsonb_build_object('reason',p_reason,'profile_id',c.profile_id));
 insert into public.notifications(profile_id,title,body) values(c.profile_id,'Card control updated',c.card_type||' was '||case when v_action='replace' then 'replaced with a new sandbox last-four' else v_action||'ed' end||'.');
end $$; grant execute on function public.set_card_status(uuid,text,text) to authenticated;

create or replace function public.reply_secure_message(p_message uuid,p_body text)
returns uuid language plpgsql security definer set search_path=public as $$ declare m public.secure_messages; v_id uuid; begin
 if not public.is_staff() then raise exception 'Staff access required'; end if;
 select * into m from public.secure_messages where id=p_message; if m.id is null then raise exception 'Message not found'; end if;
 insert into public.secure_messages(profile_id,sender_id,subject,body,direction,status) values(m.profile_id,auth.uid(),'Re: '||m.subject,p_body,'staff_to_customer','closed') returning id into v_id;
 update public.secure_messages set status='closed',read_at=now() where id=m.id;
 insert into public.notifications(profile_id,title,body) values(m.profile_id,'New secure message','Operations replied to: '||m.subject);
 insert into public.audit_logs(actor_id,action,target_type,target_id,details) values(auth.uid(),'message_reply','secure_message',m.id,jsonb_build_object('reply_id',v_id)); return v_id;
end $$; grant execute on function public.reply_secure_message(uuid,text) to authenticated;
