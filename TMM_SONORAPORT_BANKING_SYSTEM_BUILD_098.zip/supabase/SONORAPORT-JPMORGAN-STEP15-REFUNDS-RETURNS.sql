-- SonoraPort J.P. Morgan Step 15: refunds, reversals, and returned-payment controls
-- Run after Step 14.

create table if not exists public.payment_refund_requests (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references auth.users(id) on delete cascade,
  payment_id uuid not null references public.payment_reservations(id) on delete restrict,
  dispute_id uuid references public.payment_disputes(id) on delete set null,
  request_type text not null check (request_type in ('refund','reversal','return_review')),
  requested_amount numeric(20,2) not null check (requested_amount > 0),
  currency text not null check (char_length(currency) = 3),
  reason_code text not null,
  customer_note text,
  status text not null default 'submitted' check (status in (
    'submitted','under_review','approved','provider_submitted','completed','rejected','failed','canceled'
  )),
  provider_request_id text,
  provider_status text,
  provider_reference text,
  failure_reason text,
  reviewed_by uuid references auth.users(id) on delete set null,
  approved_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  approved_at timestamptz,
  provider_submitted_at timestamptz,
  completed_at timestamptz,
  correlation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(payment_id, request_type)
);

create index if not exists payment_refund_requests_profile_created_idx
  on public.payment_refund_requests(profile_id, created_at desc);
create index if not exists payment_refund_requests_status_created_idx
  on public.payment_refund_requests(status, created_at asc);

create table if not exists public.payment_return_events (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payment_reservations(id) on delete restrict,
  refund_request_id uuid references public.payment_refund_requests(id) on delete set null,
  provider_event_id text not null unique,
  provider_status text not null,
  return_code text,
  return_reason text,
  amount numeric(20,2),
  currency text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  correlation_id text,
  raw_event_hash text
);

alter table public.payment_refund_requests enable row level security;
alter table public.payment_return_events enable row level security;
revoke all on public.payment_refund_requests from public, anon, authenticated;
revoke all on public.payment_return_events from public, anon, authenticated;
grant all on public.payment_refund_requests to service_role;
grant all on public.payment_return_events to service_role;

grant select on public.payment_refund_requests to authenticated;
drop policy if exists payment_refund_requests_customer_select on public.payment_refund_requests;
create policy payment_refund_requests_customer_select on public.payment_refund_requests
for select to authenticated using (profile_id = auth.uid());

create or replace function public.finalize_refund_ledger(
  p_refund_request_id uuid,
  p_outcome text,
  p_provider_status text default null,
  p_provider_reference text default null,
  p_failure_reason text default null,
  p_correlation_id text default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_req public.payment_refund_requests%rowtype;
  v_payment public.payment_reservations%rowtype;
  v_journal_id uuid;
begin
  if p_outcome not in ('completed','failed','rejected') then
    raise exception 'INVALID_REFUND_OUTCOME';
  end if;

  select * into v_req from public.payment_refund_requests where id = p_refund_request_id for update;
  if not found then raise exception 'REFUND_REQUEST_NOT_FOUND'; end if;
  if v_req.status in ('completed','failed','rejected','canceled') then
    return jsonb_build_object('refundRequestId', v_req.id, 'status', v_req.status, 'duplicate', true);
  end if;

  select * into v_payment from public.payment_reservations where id = v_req.payment_id;
  if not found then raise exception 'PAYMENT_RESERVATION_NOT_FOUND'; end if;

  if p_outcome = 'completed' then
    v_journal_id := gen_random_uuid();
    insert into public.ledger_journals(
      id, profile_id, reservation_id, event_type, currency,
      total_debits, total_credits, correlation_id
    ) values (
      v_journal_id, v_req.profile_id, null, 'payment_refund_completed', v_req.currency,
      v_req.requested_amount, v_req.requested_amount, coalesce(p_correlation_id, v_req.correlation_id)
    );

    insert into public.ledger_entries(
      journal_id, profile_id, provider_account_link_id, ledger_account,
      direction, amount, currency
    ) values
      (v_journal_id, v_req.profile_id, v_payment.provider_account_link_id, 'provider_refund_receivable', 'debit', v_req.requested_amount, v_req.currency),
      (v_journal_id, v_req.profile_id, v_payment.provider_account_link_id, 'customer_available_funds', 'credit', v_req.requested_amount, v_req.currency);
  end if;

  update public.payment_refund_requests
     set status = p_outcome,
         provider_status = nullif(p_provider_status, ''),
         provider_reference = coalesce(nullif(p_provider_reference, ''), provider_reference),
         failure_reason = case when p_outcome = 'failed' then nullif(left(p_failure_reason, 500), '') else failure_reason end,
         completed_at = case when p_outcome = 'completed' then now() else completed_at end,
         updated_at = now()
   where id = p_refund_request_id;

  return jsonb_build_object('refundRequestId', p_refund_request_id, 'status', p_outcome, 'journalId', v_journal_id, 'duplicate', false);
end;
$$;

revoke all on function public.finalize_refund_ledger(uuid,text,text,text,text,text) from public, anon, authenticated;
grant execute on function public.finalize_refund_ledger(uuid,text,text,text,text,text) to service_role;
