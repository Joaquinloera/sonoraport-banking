-- SonoraPort J.P. Morgan provider-account links
-- Run once in the Supabase SQL Editor before enabling balances or payments.

create table if not exists public.provider_accounts (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null default 'jpmorgan' check (provider in ('jpmorgan')),
  provider_client_id text,
  provider_account_id text not null,
  account_type text,
  display_name text,
  last4 text,
  status text not null default 'pending' check (status in ('pending','active','suspended','closed')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, provider_account_id)
);

create index if not exists provider_accounts_profile_provider_idx
  on public.provider_accounts(profile_id, provider, status);

alter table public.provider_accounts enable row level security;

drop policy if exists provider_accounts_select_own on public.provider_accounts;
create policy provider_accounts_select_own
  on public.provider_accounts
  for select
  to authenticated
  using (profile_id = auth.uid());

-- Deliberately no INSERT/UPDATE/DELETE policy for authenticated customers.
-- Provider IDs must only be written by trusted server-side/admin workflows.

create or replace function public.set_provider_accounts_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists provider_accounts_set_updated_at on public.provider_accounts;
create trigger provider_accounts_set_updated_at
before update on public.provider_accounts
for each row execute function public.set_provider_accounts_updated_at();
