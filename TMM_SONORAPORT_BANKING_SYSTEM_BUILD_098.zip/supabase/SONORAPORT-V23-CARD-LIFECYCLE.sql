-- Provider-confirmed card lifecycle metadata. No PAN, CVV, PIN, or track data is stored here.
alter table if exists public.cards add column if not exists provider_status text;
alter table if exists public.cards add column if not exists provider_updated_at timestamptz;
create index if not exists cards_provider_status_idx on public.cards(provider_status) where provider_status is not null;
