-- TMM SonoraPort Banking V24: provider-confirmed card transaction lifecycle
create table if not exists public.card_transaction_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  provider_card_id text,
  provider_transaction_id text,
  event_type text not null check (event_type in ('authorization','authorization_declined','capture','clearing','reversal','refund')),
  provider_status text,
  amount numeric(20,2),
  currency text,
  merchant_reference text,
  correlation_id text,
  received_at timestamptz not null default now(),
  payload jsonb not null default '{}'::jsonb,
  unique(provider, provider_event_id)
);
create index if not exists card_transaction_events_tx_idx on public.card_transaction_events(provider,provider_transaction_id,received_at desc);
create index if not exists card_transaction_events_card_idx on public.card_transaction_events(provider_card_id,received_at desc);
alter table public.card_transaction_events enable row level security;
revoke all on public.card_transaction_events from public, anon, authenticated;
grant all on public.card_transaction_events to service_role;
