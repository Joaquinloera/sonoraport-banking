-- Run only if the private documents bucket has not yet been created.
insert into storage.buckets (id, name, public) values ('documents','documents',false) on conflict (id) do update set public=false;

drop policy if exists "Users upload own documents" on storage.objects;
create policy "Users upload own documents" on storage.objects for insert to authenticated with check (bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Users read own documents" on storage.objects;
create policy "Users read own documents" on storage.objects for select to authenticated using (bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Users delete own documents" on storage.objects;
create policy "Users delete own documents" on storage.objects for delete to authenticated using (bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text);
