-- TMM SonoraPort Banking V25: card holds, ledger posting, and reconciliation exceptions.
-- Provider-confirmed events only. No PAN/CVV data is stored.
create table if not exists public.card_authorization_holds (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_transaction_id text not null,
  provider_card_id text not null,
  profile_id uuid not null references public.profiles(id) on delete cascade,
  account_id uuid references public.accounts(id) on delete restrict,
  amount numeric(20,2) not null check (amount > 0),
  currency text not null,
  status text not null default 'authorized' check (status in ('authorized','captured','cleared','reversed','refunded','declined')),
  authorized_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, provider_transaction_id)
);

create table if not exists public.card_reconciliation_exceptions (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  provider_transaction_id text,
  exception_code text not null,
  details jsonb not null default '{}'::jsonb,
  status text not null default 'open' check (status in ('open','reviewing','resolved')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  unique(provider, provider_event_id, exception_code)
);

create index if not exists card_holds_profile_status_idx on public.card_authorization_holds(profile_id,status,updated_at desc);
create index if not exists card_recon_status_idx on public.card_reconciliation_exceptions(status,created_at desc);
alter table public.card_authorization_holds enable row level security;
alter table public.card_reconciliation_exceptions enable row level security;
revoke all on public.card_authorization_holds from public,anon,authenticated;
revoke all on public.card_reconciliation_exceptions from public,anon,authenticated;
grant all on public.card_authorization_holds to service_role;
grant all on public.card_reconciliation_exceptions to service_role;

drop policy if exists card_holds_select_own on public.card_authorization_holds;
create policy card_holds_select_own on public.card_authorization_holds for select to authenticated using (profile_id=auth.uid());

-- Atomically apply a previously signature-verified provider event to the card hold lifecycle.
create or replace function public.apply_card_transaction_event(
  p_provider text,
  p_provider_event_id text,
  p_provider_card_id text,
  p_provider_transaction_id text,
  p_event_type text,
  p_amount numeric,
  p_currency text
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare
  v_card public.cards%rowtype;
  v_hold public.card_authorization_holds%rowtype;
  v_exception text;
  v_status text;
begin
  if p_event_type not in ('authorization','authorization_declined','capture','clearing','reversal','refund') then raise exception 'CARD_EVENT_UNSUPPORTED'; end if;
  if coalesce(p_provider_event_id,'')='' or coalesce(p_provider_transaction_id,'')='' then raise exception 'CARD_EVENT_IDENTIFIERS_REQUIRED'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'CARD_EVENT_AMOUNT_INVALID'; end if;

  select * into v_card from public.cards where provider_card_id=p_provider_card_id limit 1;
  if not found then
    v_exception := 'CARD_NOT_LINKED';
  elsif p_event_type='authorization_declined' then
    insert into public.card_authorization_holds(provider,provider_transaction_id,provider_card_id,profile_id,account_id,amount,currency,status)
    values(p_provider,p_provider_transaction_id,p_provider_card_id,v_card.profile_id,v_card.account_id,greatest(p_amount,0.01),upper(p_currency),'declined')
    on conflict(provider,provider_transaction_id) do update set status='declined',updated_at=now();
    v_status := 'declined';
  elsif p_event_type='authorization' then
    if p_amount <= 0 then raise exception 'CARD_AUTH_AMOUNT_INVALID'; end if;
    insert into public.card_authorization_holds(provider,provider_transaction_id,provider_card_id,profile_id,account_id,amount,currency,status)
    values(p_provider,p_provider_transaction_id,p_provider_card_id,v_card.profile_id,v_card.account_id,p_amount,upper(p_currency),'authorized')
    on conflict(provider,provider_transaction_id) do nothing;
    v_status := 'authorized';
  else
    select * into v_hold from public.card_authorization_holds where provider=p_provider and provider_transaction_id=p_provider_transaction_id for update;
    if not found then
      v_exception := 'AUTHORIZATION_HOLD_MISSING';
    elsif upper(v_hold.currency)<>upper(p_currency) then
      v_exception := 'CURRENCY_MISMATCH';
    elsif p_event_type in ('capture','clearing') and p_amount > v_hold.amount then
      v_exception := 'CAPTURE_EXCEEDS_AUTHORIZATION';
    else
      v_status := case p_event_type when 'capture' then 'captured' when 'clearing' then 'cleared' when 'reversal' then 'reversed' when 'refund' then 'refunded' end;
      update public.card_authorization_holds set status=v_status,updated_at=now() where id=v_hold.id;
    end if;
  end if;

  if v_exception is not null then
    insert into public.card_reconciliation_exceptions(provider,provider_event_id,provider_transaction_id,exception_code,details)
    values(p_provider,p_provider_event_id,p_provider_transaction_id,v_exception,jsonb_build_object('eventType',p_event_type,'amount',p_amount,'currency',p_currency,'providerCardId',p_provider_card_id))
    on conflict(provider,provider_event_id,exception_code) do nothing;
    return jsonb_build_object('applied',false,'exception',v_exception);
  end if;
  return jsonb_build_object('applied',true,'status',v_status);
end; $$;
revoke all on function public.apply_card_transaction_event(text,text,text,text,text,numeric,text) from public,anon,authenticated;
grant execute on function public.apply_card_transaction_event(text,text,text,text,text,numeric,text) to service_role;
