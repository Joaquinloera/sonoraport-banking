-- Build 064: funded-account Visa Debit authorization/capture/reversal lifecycle.
-- Apply after V28. Provider webhooks remain signature-verified server-side.

alter table public.provider_accounts add column if not exists linked_account_id uuid references public.accounts(id) on delete restrict;
create index if not exists provider_accounts_linked_account_idx on public.provider_accounts(profile_id,linked_account_id,status);

alter table public.card_authorization_holds add column if not exists provider_account_link_id uuid references public.provider_accounts(id) on delete restrict;
alter table public.card_authorization_holds add column if not exists authorized_amount numeric(20,2);
alter table public.card_authorization_holds add column if not exists captured_amount numeric(20,2) not null default 0;
alter table public.card_authorization_holds add column if not exists provider_authorization_id text;
alter table public.card_authorization_holds add column if not exists provider_capture_id text;
alter table public.card_authorization_holds add column if not exists correlation_id text;

create table if not exists public.card_lifecycle_applications (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  provider_transaction_id text not null,
  provider_card_id text not null,
  provider_account_link_id uuid references public.provider_accounts(id) on delete restrict,
  profile_id uuid references public.profiles(id) on delete cascade,
  event_type text not null,
  amount numeric(20,2) not null,
  currency text not null,
  outcome text not null check (outcome in ('applied','declined','exception')),
  provider_reference_id text,
  correlation_id text,
  journal_id uuid references public.ledger_journals(id) on delete restrict,
  created_at timestamptz not null default now(),
  unique(provider,provider_event_id)
);
create index if not exists card_lifecycle_tx_idx on public.card_lifecycle_applications(provider,provider_transaction_id,created_at desc);
alter table public.card_lifecycle_applications enable row level security;
revoke all on public.card_lifecycle_applications from public,anon,authenticated;
grant all on public.card_lifecycle_applications to service_role;
drop policy if exists card_lifecycle_applications_select_own on public.card_lifecycle_applications;
create policy card_lifecycle_applications_select_own on public.card_lifecycle_applications for select to authenticated using(profile_id=auth.uid());

create or replace function public.apply_visa_debit_transaction_event(
  p_provider text,
  p_provider_event_id text,
  p_provider_card_id text,
  p_provider_transaction_id text,
  p_event_type text,
  p_amount numeric,
  p_currency text,
  p_provider_reference_id text default null,
  p_correlation_id text default null
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare
  v_card public.cards%rowtype;
  v_link public.provider_accounts%rowtype;
  v_snapshot public.provider_balance_snapshots%rowtype;
  v_hold public.card_authorization_holds%rowtype;
  v_existing public.card_lifecycle_applications%rowtype;
  v_journal uuid;
  v_release numeric(20,2) := 0;
  v_exception text;
  v_status text;
begin
  if coalesce(p_provider_event_id,'')='' or coalesce(p_provider_transaction_id,'')='' or coalesce(p_provider_card_id,'')='' then raise exception 'CARD_EVENT_IDENTIFIERS_REQUIRED'; end if;
  if p_event_type not in ('authorization','authorization_declined','capture','reversal') then raise exception 'VISA_DEBIT_EVENT_UNSUPPORTED'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'CARD_EVENT_AMOUNT_INVALID'; end if;
  if upper(coalesce(p_currency,'')) <> 'USD' then raise exception 'VISA_DEBIT_USD_ONLY'; end if;

  select * into v_existing from public.card_lifecycle_applications where provider=p_provider and provider_event_id=p_provider_event_id;
  if found then return jsonb_build_object('applied',v_existing.outcome='applied','duplicate',true,'outcome',v_existing.outcome,'journalId',v_existing.journal_id); end if;

  select * into v_card from public.cards where provider_card_id=p_provider_card_id and lower(card_type)='visa_debit' and (lower(provider)=lower(p_provider) or lower(provider)=('authorized_issuer:'||lower(p_provider))) limit 1 for update;
  if not found then v_exception := 'VISA_DEBIT_CARD_NOT_LINKED';
  else
    select * into v_link from public.provider_accounts
      where profile_id=v_card.profile_id and linked_account_id=v_card.account_id and status='active'
      limit 1 for update;
    if not found then v_exception := 'FUNDED_ACCOUNT_LINK_MISSING'; end if;
  end if;

  if v_exception is null then
    select * into v_snapshot from public.provider_balance_snapshots
      where provider_account_link_id=v_link.id and profile_id=v_card.profile_id and upper(currency)='USD' for update;
    if not found then v_exception := 'FUNDED_BALANCE_SNAPSHOT_MISSING'; end if;
  end if;

  if v_exception is not null then
    insert into public.card_reconciliation_exceptions(provider,provider_event_id,provider_transaction_id,exception_code,details)
    values(p_provider,p_provider_event_id,p_provider_transaction_id,v_exception,jsonb_build_object('eventType',p_event_type,'amount',p_amount,'currency','USD','providerCardId',p_provider_card_id,'providerReferenceId',p_provider_reference_id,'correlationId',p_correlation_id))
    on conflict(provider,provider_event_id,exception_code) do nothing;
    insert into public.card_lifecycle_applications(provider,provider_event_id,provider_transaction_id,provider_card_id,event_type,amount,currency,outcome,provider_reference_id,correlation_id)
    values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_card_id,p_event_type,p_amount,'USD','exception',p_provider_reference_id,p_correlation_id);
    return jsonb_build_object('applied',false,'duplicate',false,'exception',v_exception);
  end if;

  if p_event_type='authorization_declined' then
    insert into public.card_authorization_holds(provider,provider_transaction_id,provider_card_id,profile_id,account_id,provider_account_link_id,amount,authorized_amount,currency,status,provider_authorization_id,correlation_id)
    values(p_provider,p_provider_transaction_id,p_provider_card_id,v_card.profile_id,v_card.account_id,v_link.id,p_amount,p_amount,'USD','declined',p_provider_reference_id,p_correlation_id)
    on conflict(provider,provider_transaction_id) do nothing;
    insert into public.card_lifecycle_applications(provider,provider_event_id,provider_transaction_id,provider_card_id,provider_account_link_id,profile_id,event_type,amount,currency,outcome,provider_reference_id,correlation_id)
    values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_card_id,v_link.id,v_card.profile_id,p_event_type,p_amount,'USD','declined',p_provider_reference_id,p_correlation_id);
    return jsonb_build_object('applied',false,'duplicate',false,'outcome','declined','availableBalance',v_snapshot.available_balance,'settledBalance',v_snapshot.current_balance);
  end if;

  if p_event_type='authorization' then
    if v_snapshot.available_balance < p_amount then raise exception 'INSUFFICIENT_AVAILABLE_BALANCE'; end if;
    insert into public.card_authorization_holds(provider,provider_transaction_id,provider_card_id,profile_id,account_id,provider_account_link_id,amount,authorized_amount,currency,status,provider_authorization_id,correlation_id)
    values(p_provider,p_provider_transaction_id,p_provider_card_id,v_card.profile_id,v_card.account_id,v_link.id,p_amount,p_amount,'USD','authorized',p_provider_reference_id,p_correlation_id);
    update public.provider_balance_snapshots set available_balance=available_balance-p_amount,refreshed_at=now() where provider_account_link_id=v_link.id;
    v_journal:=gen_random_uuid();
    insert into public.ledger_journals(id,profile_id,event_type,currency,total_debits,total_credits,correlation_id) values(v_journal,v_card.profile_id,'visa_debit_authorization_hold','USD',p_amount,p_amount,p_correlation_id);
    insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
      (v_journal,v_card.profile_id,v_link.id,'customer_card_hold','debit',p_amount,'USD'),
      (v_journal,v_card.profile_id,v_link.id,'customer_available_funds','credit',p_amount,'USD');
    v_status:='authorized';
  else
    select * into v_hold from public.card_authorization_holds where provider=p_provider and provider_transaction_id=p_provider_transaction_id for update;
    if not found or v_hold.status<>'authorized' then
      v_exception := case when not found then 'AUTHORIZATION_HOLD_MISSING' else 'AUTHORIZATION_HOLD_NOT_OPEN' end;
    elsif v_hold.provider_account_link_id<>v_link.id then v_exception:='AUTHORIZATION_ACCOUNT_MISMATCH';
    elsif upper(v_hold.currency)<>'USD' then v_exception:='CURRENCY_MISMATCH';
    elsif p_event_type='capture' and p_amount>v_hold.authorized_amount then v_exception:='CAPTURE_EXCEEDS_AUTHORIZATION';
    end if;
    if v_exception is not null then
      insert into public.card_reconciliation_exceptions(provider,provider_event_id,provider_transaction_id,exception_code,details)
      values(p_provider,p_provider_event_id,p_provider_transaction_id,v_exception,jsonb_build_object('eventType',p_event_type,'amount',p_amount,'currency','USD','providerCardId',p_provider_card_id,'providerReferenceId',p_provider_reference_id,'correlationId',p_correlation_id))
      on conflict(provider,provider_event_id,exception_code) do nothing;
      insert into public.card_lifecycle_applications(provider,provider_event_id,provider_transaction_id,provider_card_id,provider_account_link_id,profile_id,event_type,amount,currency,outcome,provider_reference_id,correlation_id)
      values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_card_id,v_link.id,v_card.profile_id,p_event_type,p_amount,'USD','exception',p_provider_reference_id,p_correlation_id);
      return jsonb_build_object('applied',false,'duplicate',false,'exception',v_exception);
    end if;

    v_release:=v_hold.authorized_amount;
    v_journal:=gen_random_uuid();
    if p_event_type='capture' then
      if v_snapshot.current_balance < p_amount then raise exception 'INSUFFICIENT_SETTLED_BALANCE'; end if;
      update public.provider_balance_snapshots set current_balance=current_balance-p_amount,available_balance=available_balance+v_release-p_amount,refreshed_at=now() where provider_account_link_id=v_link.id;
      update public.card_authorization_holds set status='captured',captured_amount=p_amount,provider_capture_id=p_provider_reference_id,updated_at=now() where id=v_hold.id;
      insert into public.ledger_journals(id,profile_id,event_type,currency,total_debits,total_credits,correlation_id) values(v_journal,v_card.profile_id,'visa_debit_capture','USD',p_amount+v_release,p_amount+v_release,p_correlation_id);
      insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
        (v_journal,v_card.profile_id,v_link.id,'card_purchase_expense','debit',p_amount,'USD'),
        (v_journal,v_card.profile_id,v_link.id,'provider_cash','credit',p_amount,'USD'),
        (v_journal,v_card.profile_id,v_link.id,'customer_available_funds','debit',v_release,'USD'),
        (v_journal,v_card.profile_id,v_link.id,'customer_card_hold','credit',v_release,'USD');
      v_status:='captured';
    else
      update public.provider_balance_snapshots set available_balance=available_balance+v_release,refreshed_at=now() where provider_account_link_id=v_link.id;
      update public.card_authorization_holds set status='reversed',updated_at=now() where id=v_hold.id;
      insert into public.ledger_journals(id,profile_id,event_type,currency,total_debits,total_credits,correlation_id) values(v_journal,v_card.profile_id,'visa_debit_reversal','USD',v_release,v_release,p_correlation_id);
      insert into public.ledger_entries(journal_id,profile_id,provider_account_link_id,ledger_account,direction,amount,currency) values
        (v_journal,v_card.profile_id,v_link.id,'customer_available_funds','debit',v_release,'USD'),
        (v_journal,v_card.profile_id,v_link.id,'customer_card_hold','credit',v_release,'USD');
      v_status:='reversed';
    end if;
  end if;

  insert into public.card_lifecycle_applications(provider,provider_event_id,provider_transaction_id,provider_card_id,provider_account_link_id,profile_id,event_type,amount,currency,outcome,provider_reference_id,correlation_id,journal_id)
  values(p_provider,p_provider_event_id,p_provider_transaction_id,p_provider_card_id,v_link.id,v_card.profile_id,p_event_type,p_amount,'USD','applied',p_provider_reference_id,p_correlation_id,v_journal);
  select * into v_snapshot from public.provider_balance_snapshots where provider_account_link_id=v_link.id;
  return jsonb_build_object('applied',true,'duplicate',false,'status',v_status,'journalId',v_journal,'providerAccountLinkId',v_link.id,'availableBalance',v_snapshot.available_balance,'settledBalance',v_snapshot.current_balance);
end; $$;
revoke all on function public.apply_visa_debit_transaction_event(text,text,text,text,text,numeric,text,text,text) from public,anon,authenticated;
grant execute on function public.apply_visa_debit_transaction_event(text,text,text,text,text,numeric,text,text,text) to service_role;
