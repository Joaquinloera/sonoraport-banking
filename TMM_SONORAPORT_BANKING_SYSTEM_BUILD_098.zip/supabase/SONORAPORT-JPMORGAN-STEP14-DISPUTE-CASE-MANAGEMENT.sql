-- SonoraPort J.P. Morgan Step 14: dispute case management and evidence review
-- Run after Step 13.

create table if not exists public.payment_dispute_events (
  id uuid primary key default gen_random_uuid(),
  dispute_id uuid not null references public.payment_disputes(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  event_type text not null check (event_type in (
    'submitted','under_review','information_requested','evidence_received',
    'provider_case_opened','resolved_customer','resolved_merchant','rejected','closed','note_added'
  )),
  note text,
  provider_case_id text,
  previous_status text,
  new_status text,
  correlation_id text,
  created_at timestamptz not null default now()
);

create index if not exists payment_dispute_events_dispute_created_idx
  on public.payment_dispute_events(dispute_id, created_at asc);

alter table public.payment_dispute_events enable row level security;
revoke all on public.payment_dispute_events from public, anon, authenticated;
grant all on public.payment_dispute_events to service_role;

-- Customers may read only the timeline for their own disputes.
grant select on public.payment_dispute_events to authenticated;
drop policy if exists payment_dispute_events_customer_select on public.payment_dispute_events;
create policy payment_dispute_events_customer_select on public.payment_dispute_events
for select to authenticated
using (
  exists (
    select 1 from public.payment_disputes d
    where d.id = payment_dispute_events.dispute_id
      and d.profile_id = auth.uid()
  )
);

alter table public.payment_disputes
  add column if not exists assigned_to uuid references auth.users(id) on delete set null,
  add column if not exists information_due_at timestamptz,
  add column if not exists last_reviewed_at timestamptz,
  add column if not exists resolution_code text,
  add column if not exists closed_by uuid references auth.users(id) on delete set null;

create index if not exists payment_disputes_assigned_status_idx
  on public.payment_disputes(assigned_to, status, updated_at desc);
