create table if not exists public.customer_onboarding_cases (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references auth.users(id) on delete cascade,
  legal_name text not null,
  customer_type text not null default 'individual' check (customer_type in ('individual','business')),
  requested_products text[] not null default array['checking']::text[],
  identity_status text not null default 'pending' check (identity_status in ('pending','verified','failed','expired')),
  kyc_status text not null default 'pending' check (kyc_status in ('pending','approved','rejected','needs_information')),
  sanctions_status text not null default 'pending' check (sanctions_status in ('pending','clear','possible_match','blocked')),
  eligibility_status text not null default 'pending' check (eligibility_status in ('pending','eligible','ineligible')),
  account_status text not null default 'pending_review' check (account_status in ('pending_review','approved','active','suspended','rejected','closed')),
  provider_customer_id text,
  provider_account_id text,
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  activated_at timestamptz,
  suspension_reason text,
  correlation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.customer_onboarding_events (
  id bigint generated always as identity primary key,
  onboarding_id uuid not null references public.customer_onboarding_cases(id) on delete cascade,
  profile_id uuid not null references auth.users(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  event_type text not null,
  old_status text,
  new_status text,
  details jsonb not null default '{}'::jsonb,
  correlation_id text,
  created_at timestamptz not null default now()
);
create index if not exists customer_onboarding_events_case_idx on public.customer_onboarding_events(onboarding_id, created_at desc);
alter table public.customer_onboarding_cases enable row level security;
alter table public.customer_onboarding_events enable row level security;
revoke all on public.customer_onboarding_cases from anon, authenticated;
revoke all on public.customer_onboarding_events from anon, authenticated;
grant select on public.customer_onboarding_cases to authenticated;
grant select on public.customer_onboarding_events to authenticated;
drop policy if exists onboarding_case_self_read on public.customer_onboarding_cases;
create policy onboarding_case_self_read on public.customer_onboarding_cases for select to authenticated using (profile_id = auth.uid());
drop policy if exists onboarding_event_self_read on public.customer_onboarding_events;
create policy onboarding_event_self_read on public.customer_onboarding_events for select to authenticated using (profile_id = auth.uid());
