-- STEP 6: provider-to-ledger reconciliation fields.
alter table public.jpmorgan_payment_certifications
  add column if not exists provider_status text,
  add column if not exists reconciliation_status text not null default 'not_checked',
  add column if not exists reconciliation_checked_at timestamptz,
  add column if not exists reconciliation_details jsonb,
  add column if not exists settled_at timestamptz;

create index if not exists jpm_cert_reconciliation_idx
  on public.jpmorgan_payment_certifications(reconciliation_status, reconciliation_checked_at desc);
