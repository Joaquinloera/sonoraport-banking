begin;

create table if not exists public.payment_beneficiaries (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references auth.users(id) on delete cascade,
  provider text not null default 'jpmorgan',
  display_name text not null,
  destination_type text not null check (destination_type in ('ach','wire','internal','other')),
  provider_destination_id text not null,
  country_code text not null default 'US',
  currency text not null default 'USD',
  status text not null default 'pending_review' check (status in ('pending_review','cooling_off','active','suspended','rejected','closed')),
  risk_score integer not null default 0 check (risk_score between 0 and 100),
  risk_reasons jsonb not null default '[]'::jsonb,
  created_by uuid not null references auth.users(id),
  reviewed_by uuid references auth.users(id),
  approved_at timestamptz,
  activates_at timestamptz,
  suspended_at timestamptz,
  last_used_at timestamptz,
  change_version integer not null default 1,
  correlation_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(profile_id, provider, provider_destination_id)
);

create table if not exists public.payment_beneficiary_events (
  id uuid primary key default gen_random_uuid(),
  beneficiary_id uuid not null references public.payment_beneficiaries(id) on delete cascade,
  profile_id uuid not null references auth.users(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  event_type text not null,
  old_status text,
  new_status text,
  details jsonb not null default '{}'::jsonb,
  correlation_id text,
  created_at timestamptz not null default now()
);

create index if not exists payment_beneficiaries_profile_status_idx on public.payment_beneficiaries(profile_id, status);
create index if not exists payment_beneficiary_events_beneficiary_idx on public.payment_beneficiary_events(beneficiary_id, created_at desc);

alter table public.payment_beneficiaries enable row level security;
alter table public.payment_beneficiary_events enable row level security;

revoke all on public.payment_beneficiaries from anon, authenticated;
revoke all on public.payment_beneficiary_events from anon, authenticated;
grant select on public.payment_beneficiaries to authenticated;
grant select on public.payment_beneficiary_events to authenticated;

create policy "beneficiaries_read_own" on public.payment_beneficiaries
for select to authenticated using (profile_id = auth.uid());

create policy "beneficiary_events_read_own" on public.payment_beneficiary_events
for select to authenticated using (profile_id = auth.uid());

create or replace function public.touch_payment_beneficiary_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_payment_beneficiary_updated_at on public.payment_beneficiaries;
create trigger trg_payment_beneficiary_updated_at
before update on public.payment_beneficiaries
for each row execute function public.touch_payment_beneficiary_updated_at();

commit;
