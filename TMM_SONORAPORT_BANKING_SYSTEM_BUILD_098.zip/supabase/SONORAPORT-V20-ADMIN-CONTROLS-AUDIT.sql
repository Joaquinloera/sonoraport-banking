-- SONORAPORT V20 ADMIN CONTROLS, MESSAGING, PROFILE, AND AUDIT HARDENING
-- Run after V19. Sandbox operations only.

-- Audit logs are append-only through trusted security-definer functions.
revoke insert, update, delete on public.audit_logs from authenticated;
revoke update, delete on public.secure_messages from authenticated;

-- Application decisions are idempotent, create one sandbox account per approved
-- application, notify the customer, and write the audit record atomically.
create or replace function public.review_application(p_application uuid,p_decision text,p_note text default null)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  a public.applications;
  acct_type text;
  acct_name text;
  v_decision text:=lower(trim(coalesce(p_decision,'')));
  v_note text:=nullif(trim(coalesce(p_note,'')),'');
begin
  if not public.is_staff() then raise exception 'Staff access required'; end if;
  if v_decision not in ('approved','declined','under_review') then raise exception 'Invalid decision'; end if;

  select * into a from public.applications where id=p_application for update;
  if a.id is null then raise exception 'Application not found'; end if;

  update public.applications
  set status=v_decision, decision_note=v_note, reviewed_at=now(), reviewed_by=auth.uid()
  where id=a.id;

  if v_decision='approved'
     and not exists(select 1 from public.accounts where source_application_id=a.id) then
    acct_type:=case
      when lower(coalesce(a.title,'')) like '%saving%' then 'savings'
      when lower(coalesce(a.title,'')) like '%business%' then 'business'
      else 'checking'
    end;
    acct_name:=coalesce(a.title,'Approved Account');
    insert into public.accounts(profile_id,name,type,balance,status,last4,source_application_id)
    values(a.profile_id,acct_name,acct_type,0,'active',lpad((floor(random()*10000))::int::text,4,'0'),a.id);
  end if;

  insert into public.notifications(profile_id,title,body)
  values(a.profile_id,'Application '||replace(initcap(v_decision),'_',' '),
    coalesce(a.title,'Application')||' is now '||replace(v_decision,'_',' ')||'.'||
    case when v_note is not null then ' '||v_note else '' end);

  insert into public.audit_logs(actor_id,action,target_type,target_id,details)
  values(auth.uid(),'application_'||v_decision,'application',a.id,
    jsonb_build_object('profile_id',a.profile_id,'reference',a.reference,'note',v_note));
end $$;
revoke all on function public.review_application(uuid,text,text) from public;
grant execute on function public.review_application(uuid,text,text) to authenticated;

-- Card issuance can only activate a pending sandbox request once. The action,
-- notification, and audit entry occur in one transaction.
create or replace function public.issue_sandbox_card(p_card uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare c public.cards;
begin
  if not public.is_staff() then raise exception 'Staff access required'; end if;
  select * into c from public.cards where id=p_card for update;
  if c.id is null then raise exception 'Card request not found'; end if;
  if lower(coalesce(c.status,'')) <> 'application_received' then
    raise exception 'Card request is not pending';
  end if;

  update public.cards
  set status='active',last4=lpad((floor(random()*10000))::int::text,4,'0'),locked=false
  where id=c.id;

  insert into public.notifications(profile_id,title,body)
  values(c.profile_id,'Sandbox card activated',c.card_type||' ending in a generated test last-four is active in the sandbox portal.');

  insert into public.audit_logs(actor_id,action,target_type,target_id,details)
  values(auth.uid(),'card_issued','card',c.id,jsonb_build_object('profile_id',c.profile_id,'account_id',c.account_id));
end $$;
revoke all on function public.issue_sandbox_card(uuid) from public;
grant execute on function public.issue_sandbox_card(uuid) to authenticated;

-- Secure replies must target an open inbound customer message and contain a
-- bounded, non-empty body.
create or replace function public.reply_secure_message(p_message uuid,p_body text)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare m public.secure_messages; v_id uuid; v_body text:=trim(coalesce(p_body,''));
begin
  if not public.is_staff() then raise exception 'Staff access required'; end if;
  if v_body='' then raise exception 'Reply is required'; end if;
  if length(v_body)>4000 then raise exception 'Reply is too long'; end if;

  select * into m from public.secure_messages where id=p_message for update;
  if m.id is null then raise exception 'Message not found'; end if;
  if m.direction<>'customer_to_staff' or m.status='closed' then raise exception 'Message is not open for reply'; end if;

  insert into public.secure_messages(profile_id,sender_id,subject,body,direction,status)
  values(m.profile_id,auth.uid(),'Re: '||left(m.subject,240),v_body,'staff_to_customer','closed') returning id into v_id;
  update public.secure_messages set status='closed',read_at=now() where id=m.id;
  insert into public.notifications(profile_id,title,body) values(m.profile_id,'New secure message','Operations replied to: '||left(m.subject,200));
  insert into public.audit_logs(actor_id,action,target_type,target_id,details)
  values(auth.uid(),'message_reply','secure_message',m.id,jsonb_build_object('reply_id',v_id,'profile_id',m.profile_id));
  return v_id;
end $$;
revoke all on function public.reply_secure_message(uuid,text) from public;
grant execute on function public.reply_secure_message(uuid,text) to authenticated;

notify pgrst, 'reload schema';
