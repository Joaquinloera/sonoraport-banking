-- Provider-backed card issuance metadata. Sensitive PAN/CVV values are never stored here.
alter table if exists public.cards add column if not exists provider text;
alter table if exists public.cards add column if not exists provider_card_id text;
create unique index if not exists cards_provider_card_id_unique on public.cards(provider,provider_card_id) where provider_card_id is not null;
