-- SONORAPORT V18 WORKFLOW + SECURITY FIX
-- Run after the earlier SonoraPort platform migrations.
-- Keeps the platform in sandbox mode and strengthens approval/card controls.

-- Track exactly which approved application created an account.
alter table public.accounts
  add column if not exists source_application_id uuid references public.applications(id) on delete set null;

create unique index if not exists accounts_source_application_unique_idx
  on public.accounts(source_application_id)
  where source_application_id is not null;

-- Customers must not be able to update arbitrary card fields such as status or last4.
drop policy if exists cards_update_access on public.cards;
drop policy if exists cards_update_own on public.cards;

create policy cards_update_staff
  on public.cards
  for update
  to authenticated
  using (public.is_staff())
  with check (public.is_staff());

-- Customer-only RPC for locking or unlocking one of their own active cards.
create or replace function public.set_own_card_lock(p_card uuid, p_locked boolean)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare c public.cards;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  select * into c
  from public.cards
  where id=p_card and profile_id=auth.uid()
  for update;
  if c.id is null then raise exception 'Card not found'; end if;
  if lower(coalesce(c.status,'')) <> 'active' then raise exception 'Only active cards can be locked or unlocked'; end if;
  update public.cards set locked=coalesce(p_locked,false) where id=c.id;
end $$;

grant execute on function public.set_own_card_lock(uuid,boolean) to authenticated;

-- Approval is idempotent and creates one sandbox account per approved application.
create or replace function public.review_application(p_application uuid,p_decision text,p_note text default null)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  a public.applications;
  acct_type text;
  acct_name text;
begin
  if not public.is_staff() then raise exception 'Staff access required'; end if;
  if lower(p_decision) not in ('approved','declined','under_review') then raise exception 'Invalid decision'; end if;

  select * into a from public.applications where id=p_application for update;
  if a.id is null then raise exception 'Application not found'; end if;

  update public.applications
  set status=lower(p_decision),
      decision_note=p_note,
      reviewed_at=now(),
      reviewed_by=auth.uid()
  where id=a.id;

  if lower(p_decision)='approved'
     and not exists(select 1 from public.accounts where source_application_id=a.id) then
    acct_type:=case
      when lower(coalesce(a.title,'')) like '%saving%' then 'savings'
      when lower(coalesce(a.title,'')) like '%business%' then 'business'
      else 'checking'
    end;
    acct_name:=coalesce(a.title,'Approved Account');

    insert into public.accounts(profile_id,name,type,balance,status,last4,source_application_id)
    values(
      a.profile_id,
      acct_name,
      acct_type,
      0,
      'active',
      lpad((floor(random()*10000))::int::text,4,'0'),
      a.id
    );
  end if;

  insert into public.notifications(profile_id,title,body)
  values(
    a.profile_id,
    'Application '||replace(initcap(lower(p_decision)),'_',' '),
    coalesce(a.title,'Application')||' is now '||replace(lower(p_decision),'_',' ')||'.'||
      case when nullif(trim(coalesce(p_note,'')),'') is not null then ' '||trim(p_note) else '' end
  );
end $$;

grant execute on function public.review_application(uuid,text,text) to authenticated;
