# Linked Account and Private Balance Integration

- Added an authenticated endpoint that lists only the signed-in user's active J.P. Morgan-linked accounts.
- Added an explicit profile-id filter in addition to Supabase Row Level Security.
- Added an account selector when multiple approved linked accounts exist.
- Balance requests now include the selected local linked-account ID and verify ownership server-side.
- Unauthenticated balance requests redirect to secure sign-in and return to the J.P. Morgan page.
- Provider account IDs remain server-side and are never exposed in the browser response.
- Balance responses retain `Cache-Control: no-store`.
