# Step 18 — Operator RBAC and Separation of Duties

Run `supabase/SONORAPORT-JPMORGAN-STEP18-OPERATOR-RBAC.sql` after Step 17.

Set a temporary bootstrap administrator in Netlify:

`JPMORGAN_SUPER_ADMIN_EMAILS=authorized-owner@example.com`

The protected operator endpoint is:

- `GET /.netlify/functions/jpmorgan-operator-admin`
- `POST /.netlify/functions/jpmorgan-operator-admin`
- `DELETE /.netlify/functions/jpmorgan-operator-admin`

POST/DELETE body: `{ "userId": "auth-user-uuid", "role": "onboarding_reviewer" }`

Roles are least-privilege. Sensitive workflows can require one operator to review and a different operator to activate or approve. Keep the bootstrap list limited and remove unused access after database roles are assigned.
