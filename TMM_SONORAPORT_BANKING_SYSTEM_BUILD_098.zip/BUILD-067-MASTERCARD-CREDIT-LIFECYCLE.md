# Build 067 — Mastercard Credit Lifecycle

Continues from Build 066. Adds an explicit Mastercard Credit provider lifecycle using the shared approved credit-line accounting model while enforcing Mastercard product isolation.

## Added
- Mastercard Credit authorization, authorization decline, capture, and reversal processing.
- Mastercard-only card lookup and provider/card validation.
- Authorization reservation against available credit without touching funded Visa Debit balances.
- Capture conversion from reservation to cardholder receivable and network settlement payable.
- Reversal release of the open authorization reservation.
- Provider-event idempotency and provider transaction/reference/correlation retention.
- Reconciliation exceptions for missing Mastercard card/credit line/authorization and over-capture.
- Stable route `/api/cards/mastercard-credit/webhook`.

## Preserved
Builds 063–066 USD funding, Visa Debit lifecycle/settlement, Visa Credit lifecycle, issuance, authentication, and portal surfaces remain unchanged.

## Deployment dependency
Apply `supabase/SONORAPORT-V32-MASTERCARD-CREDIT-LIFECYCLE.sql` after V31, provision each issued Mastercard Credit card with an approved `card_credit_accounts` row/credit limit, and route only authenticated issuer Mastercard Credit events to the new webhook. Build 067 does not invent or auto-approve credit limits.
