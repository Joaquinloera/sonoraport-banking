# Build 027 — Admin Routes
- Adds /admin/login.html as the stable administrator login route.
- Successful sign-in target: /admin/index.html.
- Adds /admin/index.html as stable route to the existing Admin Command Center.
- Preserves the existing admin-portal.html and its role enforcement, provider operations, payments operations, and Security & Biometrics panels.
- Biometric server configuration remains server-side through Netlify environment variables.
