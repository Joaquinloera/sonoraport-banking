# Production Activation Configuration

This master build contains the fields needed for a production handoff without redesigning the website.

## Provider-issued values to enter in Netlify

1. Production client ID and authentication method.
2. Production token URL, API base URL, scope, and audience.
3. Merchant, organization, configuration, and approved account identifiers.
4. Private-key JWT values and/or mTLS certificate material when required.
5. Callback URL registration and the matching signature secret, public key, or certificate.
6. Production endpoint paths for payments, balances, onboarding, and transaction status.
7. Provider-approved limits, rails, currencies, and certification destination.

## Safe cutover order

1. Keep `JPMORGAN_PAYMENT_OPERATIONS_ENABLED=false`.
2. Enter the complete provider-issued production values.
3. Deploy and verify authentication, product access, callbacks, and certification.
4. Complete the controlled provider certification and reconciliation.
5. Set `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=true` only after approval.
6. Set `JPMORGAN_PAYMENT_OPERATIONS_ENABLED=true` for the approved production launch.
7. Keep `JPMORGAN_EMERGENCY_STOP=false` unless operations must be halted.

No secret is embedded in this ZIP. Real values stay in Netlify environment variables.
