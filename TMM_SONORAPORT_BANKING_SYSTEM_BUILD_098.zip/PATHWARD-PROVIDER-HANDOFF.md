# Pathward Provider Handoff — BUILD 086

BUILD 086 adds Pathward-compatible environment aliases while preserving legacy JPMORGAN_* variable compatibility. No production secret is stored in this archive.

Preferred server-only variables:
- PATHWARD_ENVIRONMENT
- PATHWARD_API_BASE_URL
- PATHWARD_TOKEN_URL
- PATHWARD_CLIENT_ID
- PATHWARD_CLIENT_SECRET
- PATHWARD_SCOPE
- PATHWARD_MTLS_CERT
- PATHWARD_MTLS_KEY
- PATHWARD_MTLS_CA (when supplied by provider)
- PATHWARD_CREATE_PAYMENT_PATH / PATHWARD_AUTHORIZATION_PATH
- PATHWARD_WEBHOOK_URL
- PATHWARD_WEBHOOK_SECRET
- PATHWARD_WEBHOOK_VERIFICATION_MODE
- PATHWARD_MERCHANT_ID / PATHWARD_PROVIDER_ACCOUNT_ID
- PATHWARD_PROGRAM_ID

Secrets must be configured only in the deployment environment. Provider verification must succeed before operations are enabled.
