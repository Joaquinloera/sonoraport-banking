# Step 9 — Transaction monitoring and approval controls

This pass adds server-side risk assessment before provider submission.

## Netlify variables

- `JPMORGAN_MANUAL_REVIEW_THRESHOLD=10000`
- `JPMORGAN_DUAL_APPROVAL_THRESHOLD=25000`
- `JPMORGAN_BLOCKED_CURRENCIES=`

Payments at or above the manual-review threshold, and wire payments, are placed on hold instead of being sent. Payments at or above the dual-approval threshold require two approvals. The SQL migration creates the approval queue and locks direct browser writes.

This pass intentionally does not auto-submit held payments. The next pass adds authenticated reviewer decisions and release to the provider after the required distinct approvals are recorded.
