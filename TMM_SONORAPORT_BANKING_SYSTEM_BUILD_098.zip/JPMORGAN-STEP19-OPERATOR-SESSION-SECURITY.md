# Step 19 — Operator MFA, Session Security, and Device Controls

This release adds a server-enforced operator security session. It does not rely on a page label to claim MFA. The signed-in Supabase access token must carry `aal2`, meaning the user completed a configured second factor.

## Install
1. Run `supabase/SONORAPORT-JPMORGAN-STEP19-OPERATOR-SESSION-SECURITY.sql`.
2. Configure Supabase MFA for staff accounts.
3. Add the Netlify variables below.
4. Redeploy, sign out, sign back in, complete MFA, and create a secure operator session.

## Netlify variables
```
JPMORGAN_REQUIRE_OPERATOR_SECURE_SESSION=true
JPMORGAN_OPERATOR_SESSION_HOURS=4
```
Keep `JPMORGAN_REQUIRE_OPERATOR_SECURE_SESSION=false` until the SQL migration and staff MFA enrollment are complete, otherwise protected operator actions will be locked.

## Endpoint
```
GET|POST|DELETE /.netlify/functions/jpmorgan-operator-session
```
Every call must include the normal bearer token and a stable, randomly generated browser-side header:
```
x-sonoraport-device-id: <32-128 character random identifier>
```
POST creates a secure session only at AAL2. GET checks it. DELETE revokes it.

## Important limitation
The device identifier is a registered browser identifier, not hardware attestation. Stronger assurance requires an identity provider or device-management product that supports managed-device claims or passkeys.
