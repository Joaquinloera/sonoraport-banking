# Build 056 — Explicit Banking API Routes

- Replaced active browser use of generic `/api/function/<function-name>` URLs with an allowlisted resolver.
- Added explicit `/api/banking/*`, `/api/cards/*`, `/api/integrations/*`, and `/api/assistant` redirects before the compatibility fallback.
- Unknown browser API names now fail closed instead of being constructed dynamically.
- Preserved query strings such as `?verify=token`.
- Advanced authenticated cache generation to v56.
