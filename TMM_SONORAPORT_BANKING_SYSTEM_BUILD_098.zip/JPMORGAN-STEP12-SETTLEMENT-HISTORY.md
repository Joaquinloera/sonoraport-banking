# J.P. Morgan Step 12 — Settlement Posting and Transaction History

1. Run `supabase/SONORAPORT-JPMORGAN-STEP12-SETTLEMENT-HISTORY.sql` after Step 11.
2. Deploy the package.
3. Provider callbacks with a completed/settled status atomically convert the outgoing hold to a settled ledger entry.
4. Failed/rejected/returned callbacks release the hold back to customer available funds.
5. Duplicate callbacks do not create duplicate journals.
6. Signed-in customers can retrieve only their own history from:
   `/.netlify/functions/jpmorgan-transaction-history?limit=50`

The callback status vocabulary may be adjusted to the exact values documented for the approved J.P. Morgan product before production cutover.
