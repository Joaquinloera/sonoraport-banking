# Build 062 — Card Issuer Continuity

- Continued from Build 061.
- Unified card activation, controls, and status sync onto the same multi-issuer router used by issuance.
- Provider-tagged cards prefer their original issuer, with configured failover ordering available.
- Issuer-specific activate/status/control paths now come from the router configuration.
- Added stable `/api/cards/status-sync` route.
- USD remains inherited from the selected active account during issuance.
