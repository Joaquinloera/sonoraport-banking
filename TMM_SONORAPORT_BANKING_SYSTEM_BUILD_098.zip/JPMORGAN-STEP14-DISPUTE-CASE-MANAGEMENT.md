# J.P. Morgan Step 14 — Dispute Case Management

This step adds an administrator-only dispute case workflow. It does not issue credits, reverse payments, or contact the provider automatically.

## Install

1. Run `supabase/SONORAPORT-JPMORGAN-STEP14-DISPUTE-CASE-MANAGEMENT.sql` after Step 13.
2. Add authorized case administrators to Netlify:

```text
JPMORGAN_DISPUTE_ADMIN_EMAILS=authorized@example.com
```

3. Deploy the package.

## Endpoint

```text
GET   /.netlify/functions/jpmorgan-dispute-admin
GET   /.netlify/functions/jpmorgan-dispute-admin?status=under_review
PATCH /.netlify/functions/jpmorgan-dispute-admin
```

PATCH body example:

```json
{
  "disputeId": "uuid",
  "status": "under_review",
  "note": "Initial evidence reviewed and provider case opened.",
  "providerCaseId": "provider-case-reference"
}
```

Allowed transitions are enforced by the server. Every action is written to both the dispute timeline and the tamper-evident audit log.
