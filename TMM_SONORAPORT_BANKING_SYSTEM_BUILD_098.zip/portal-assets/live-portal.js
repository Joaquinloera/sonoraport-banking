const SB_URL='https://utnassdlhanlxbcovjmc.supabase.co';
const SB_KEY='sb_publishable_aJ7UeCdanPHEbh3RlVOznA_RHf-StTA';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(n||0));
const cardActionInFlight=new Set();
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let sb,user,profile,isRendering=false;

function redirectToSignIn(){
  const next=encodeURIComponent('client-portal.html');
  location.replace(`sign-in.html?next=${next}`);
}
function setConnection(text,bad=false){
  const el=$('#modeText');
  if(el) el.textContent=text;
  document.body.classList.toggle('portal-error',bad);
}
function updatePortalChrome(){
  const bar=document.querySelector('.sp-auth-access-bar');
  if(bar){
    bar.classList.add('sp-auth-connected');
    bar.innerHTML='<span>SECURE CLIENT ACCESS</span><span class="sp-auth-connected-state">Connected session</span>';
  }
  const set=(selector,text,state='')=>{const el=$(selector);if(!el)return;el.textContent=text;el.classList.remove('pending','error');if(state)el.classList.add(state);};
  set('#portalConnectionState','Secure');
  set('#portalSessionState',user?'Active':'Unavailable',user?'':'error');
  set('#portalIdentityState',user?.email_confirmed_at?'Verified':'Authenticated',user?.email_confirmed_at?'':'pending');
  set('#portalEnvironmentState','Secure','');
}
function apiError(data,fallback){return data?.message||data?.error||data?.code||fallback;}
function friendlyError(error){
  const message=String(error?.message||error||'Unable to complete the request.');
  if(/relation .* does not exist/i.test(message)) return 'This banking feature is temporarily unavailable. Please try again shortly.';
  if(/schema cache|could not find the function|function .* does not exist/i.test(message)) return 'This banking service is temporarily unavailable. Please try again shortly.';
  if(/row-level security|policy/i.test(message)) return 'This request could not be completed with your current account permissions.';
  if(/failed to fetch|network/i.test(message)) return 'We could not reach the banking service. Check your connection and try again.';
  return message;
}
async function boot(){
  if(!window.supabase){setConnection('SECURE SERVICE UNAVAILABLE',true);return;}
  sb=window.supabase.createClient(SB_URL,SB_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  const {data,error}=await sb.auth.getSession();
  if(error){console.error(error);redirectToSignIn();return;}
  user=data.session?.user||null;
  if(!user){redirectToSignIn();return;}
  sb.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'||!session) redirectToSignIn();});
  await loadProfile();
  updatePortalChrome();
  bind();
  await syncSavedApplications();
  await renderAll();
}
async function syncSavedApplications(){
  // Legacy browser-saved applications are no longer written into the retired applications table.
  // New requests use the authenticated /api/applications boundary.
  return;
}
async function loadProfile(){
  const {data,error}=await sb.from('profiles').select('id,full_name,email,role,preferences').eq('id',user.id).maybeSingle();
  if(error) console.warn('profiles',error);
  profile=data||null;
  const name=profile?.full_name||user.user_metadata?.full_name||'Client';
  $('#userName').textContent=name;
  $('#userEmail').textContent=profile?.email||user.email||'';
  const roleEl=$('#userRole'); if(roleEl) roleEl.textContent=profile?.role?profile.role.replaceAll('_',' '):'customer';
}
function bind(){
  $('#signOut').onclick=signOut;
  $('#refreshPortal').onclick=()=>renderAll(true);
  $('#transferForm').onsubmit=submitTransfer;
  $('#cardForm').onsubmit=submitCard;
  $('#applicationForm').onsubmit=submitApplication;
  if($('#messageForm'))$('#messageForm').onsubmit=submitMessage;
  if($('#profileForm'))$('#profileForm').onsubmit=saveProfile;
  $('#printStatement').onclick=()=>window.print();
  $('#downloadTransactions').onclick=downloadTransactions;
  $('#markAllRead').onclick=markAllRead;
  $('#statementAccount').onchange=()=>renderAll();
  $('#statementMonth').onchange=()=>renderAll();
  document.addEventListener('click',handlePortalActions);
  document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-account-card]')){e.preventDefault();openAccountDetails(e.target.dataset.accountCard)}});
}
function activatePanel(panel){
  if(window.TMMOpenCustomerPanel){window.TMMOpenCustomerPanel(panel);return;}
  $$('.lp-tab').forEach(x=>{
    const on=x.dataset.panel===panel;
    x.classList.toggle('active',on);
    x.setAttribute('aria-selected',on?'true':'false');
    x.tabIndex=on?0:-1;
  });
  $$('.lp-panel').forEach(x=>{
    const on=x.id===`panel-${panel}`;
    x.classList.toggle('active',on);
    x.hidden=!on;
  });
}
async function signOut(){
  const button=$('#signOut');
  if(button){button.disabled=true;button.textContent='Signing Out…';}
  try{await sb.auth.signOut({scope:'global'});}catch(error){console.warn('sign out',error);}
  try{sessionStorage.removeItem('sonoraport_auth_next');}catch{}
  location.replace('sign-in.html?signedout=1');
}
async function table(name,columns='*'){
  const {data,error}=await sb.from(name).select(columns).eq('profile_id',user.id).order('created_at',{ascending:false});
  if(error) throw new Error(`${name}: ${friendlyError(error)}`);
  return data||[];
}
async function safeTable(name,columns='*'){
  try{return {rows:await table(name,columns),error:null};}
  catch(error){console.warn(error.message);return {rows:[],error};}
}
async function currentRows(name,columns='*'){
  const {data,error}=await sb.from(name).select(columns).eq('user_id',user.id).order('created_at',{ascending:false});
  if(error)throw new Error(`${name}: ${friendlyError(error)}`);return data||[];
}
async function safeCurrentAccounts(){try{const rows=await currentRows('bank_accounts');return {rows:rows.map(a=>({...a,name:a.account_name,type:a.account_type,balance:a.current_balance,profile_id:a.user_id,last4:String(a.account_number||'').slice(-4)})),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeCurrentCards(){try{const [d,c]=await Promise.all([currentRows('debit_cards'),currentRows('credit_cards')]);const norm=(x,kind)=>({...x,account_id:x.linked_account_id,last4:x.last_four,provider_card_id:x.external_card_id,locked:Boolean(x.is_locked),nickname:x.card_name||x.product_name||x.product_code||kind,card_type:x.product_code||x.product_name||kind});return {rows:[...d.map(x=>norm(x,'Visa Debit')),...c.map(x=>norm(x,'Credit Card'))].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeCurrentApplications(){try{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in required.');const r=await fetch('/api/applications',{headers:{Authorization:`Bearer ${session.access_token}`},cache:'no-store'});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(apiError(d,'Unable to load applications.'));const rows=(d.applications||[]).map(a=>({...a,profile_id:user.id,title:String(a.account_type||'Application').replaceAll('_',' '),reference:String(a.id||'').slice(0,12).toUpperCase()}));return {rows,error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeCurrentTransactions(){try{const rows=await currentRows('transactions');return {rows:rows.map(t=>({...t,profile_id:t.user_id,account_id:t.bank_account_id||t.account_id,kind:t.transaction_type,amount:(String(t.direction).toLowerCase()==='debit'?-1:1)*Math.abs(Number(t.amount||0))})),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeCurrentTransfers(){try{const rows=await currentRows('transfer_requests');return {rows:rows.map(t=>({...t,profile_id:t.user_id,from_name:t.from_account_id?`Account ${String(t.from_account_id).slice(0,8)}`:'Account',to_name:t.to_account_id?`Account ${String(t.to_account_id).slice(0,8)}`:(t.external_recipient_name||'External recipient')})),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeCurrentMessages(){try{const {data,error}=await sb.from('secure_messages').select('*').or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order('created_at',{ascending:false});if(error)throw error;return {rows:(data||[]).map(m=>({...m,profile_id:user.id,body:m.message,direction:m.sender_id===user.id?'customer_to_staff':'staff_to_customer',status:m.is_read?'read':'open'})),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function safeDebitAuthorizations(){try{const rows=await currentRows('debit_card_authorizations');return {rows:rows.map(h=>({...h,profile_id:h.user_id,account_id:h.bank_account_id,amount:h.authorized_amount})),error:null};}catch(error){console.warn(error.message);return {rows:[],error};}}
async function insert(name,row){
  const payload={...row,profile_id:user.id};
  const {data,error}=await sb.from(name).insert(payload).select().single();
  if(error) throw new Error(friendlyError(error));
  return data;
}
async function renderAll(showToast=false){
  if(isRendering)return;
  isRendering=true;
  const refresh=$('#refreshPortal');
  if(refresh){refresh.disabled=true;refresh.textContent='Refreshing…';}
  setConnection('SECURE BANKING');
  const dataState=$('#portalDataState');
  if(dataState){dataState.textContent='Refreshing';dataState.classList.add('pending');dataState.classList.remove('error');}
  try{
    const [accountsResult,txResult,transfersResult,cardsResult,appsResult,notificationsResult,messagesResult,holdsResult]=await Promise.all([
      safeCurrentAccounts(),safeCurrentTransactions(),safeCurrentTransfers(),safeCurrentCards(),safeCurrentApplications(),Promise.resolve({rows:[],error:null}),safeCurrentMessages(),safeDebitAuthorizations()
    ]);
    const accounts=accountsResult.rows,tx=txResult.rows,transfers=transfersResult.rows,cards=cardsResult.rows,apps=appsResult.rows,notifications=notificationsResult.rows,messages=messagesResult.rows,cardHolds=holdsResult.rows;
    const allErrors=[accountsResult,txResult,transfersResult,cardsResult,appsResult,notificationsResult,messagesResult,holdsResult].filter(x=>x.error);
    if(allErrors.length) setConnection(`BANKING — ${allErrors.length} SECTION${allErrors.length===1?'':'S'} NEED ATTENTION`,true);
    const pendingPattern=/pending|review|submitted|received|processing/i;
    const total=accounts.reduce((sum,account)=>sum+Number(account.balance||0),0);
    $('#totalBalance').textContent=money(total);
    $('#accountCount').textContent=accounts.length;
    $('#pendingCount').textContent=apps.filter(item=>pendingPattern.test(item.status||'')).length;
    $('#transactionCount').textContent=tx.length;
    $('#accountsBody').innerHTML=accounts.map(a=>`<tr><td>${esc(a.name||'Account')}</td><td>${esc(a.type||'—')}</td><td>${money(a.balance)}</td><td>${status(a.status)}</td></tr>`).join('')||empty(4,'No accounts have been activated.');
    const activeAccountsForSummary=accounts.filter(a=>/active|open/i.test(a.status||''));
    const availableTotal=activeAccountsForSummary.reduce((sum,a)=>sum+Number(a.available_balance??a.balance??0),0);
    const accountCards=$('#accountCards');
    if(accountCards){
      accountCards.innerHTML=accounts.map(a=>{
        const last4=String(a.last4||a.account_last4||a.id||'').slice(-4).toUpperCase();
        const available=Number(a.available_balance??a.balance??0);
        return `<article class="lp-account-card lp-account-card-clickable" data-account-card="${esc(a.id)}" tabindex="0" role="button" aria-label="Open ${esc(a.name||'account')} details"><div class="lp-account-card-head"><div><small>${esc(a.type||'Account')}</small><h3>${esc(a.name||'Account')}</h3></div>${status(a.status||'active')}</div><p class="lp-account-number">•••• •••• •••• ${esc(last4||'----')}</p><div class="lp-account-balances"><span><small>Current balance</small><strong>${money(a.balance)}</strong></span><span><small>Available balance</small><strong>${money(available)}</strong></span></div><div class="lp-account-actions"><button class="lp-mini" type="button" data-account-action="transactions" data-account-id="${esc(a.id)}">View Activity</button><button class="lp-mini" type="button" data-account-action="transfer" data-account-id="${esc(a.id)}">Transfer</button></div><footer><span>Opened ${date(a.created_at)}</span><span>Tap card for details</span></footer></article>`;
      }).join('')||'<div class="lp-empty-card"><h3>No active accounts yet</h3><p>Approved account applications will appear here after account creation.</p></div>';
    }
    if($('#accountsTotalBalance'))$('#accountsTotalBalance').textContent=money(total);
    if($('#accountsActiveCount'))$('#accountsActiveCount').textContent=activeAccountsForSummary.length;
    if($('#accountsAvailableBalance'))$('#accountsAvailableBalance').textContent=money(availableTotal);
    const accountMap=new Map(accounts.map(a=>[a.id,a]));
    window.__portalAccounts=accounts;
    window.__portalAccountMap=accountMap;
    const running=new Map(accounts.map(a=>[a.id,Number(a.balance||0)]));
    $('#transactionsBody').innerHTML=tx.map(t=>{const account=accountMap.get(t.account_id);const after=running.has(t.account_id)?running.get(t.account_id):null;if(after!==null)running.set(t.account_id,after-Number(t.amount||0));return `<tr><td>${date(t.created_at)}</td><td>${esc(account?.name||'Account')}</td><td>${esc(t.description||'Transaction')}</td><td>${esc(t.kind||'—')}</td><td class="${Number(t.amount||0)<0?'lp-amount-negative':'lp-amount-positive'}">${money(t.amount)}</td><td>${after===null?'—':money(after)}</td><td>${status(t.status)}</td></tr>`;}).join('')||empty(7,'No transactions yet.');

    const pendingHolds=cardHolds.filter(h=>['authorized','captured'].includes(String(h.status||'').toLowerCase()));
    if($('#cardHoldCount'))$('#cardHoldCount').textContent=pendingHolds.length;
    if($('#cardHoldAmount'))$('#cardHoldAmount').textContent=money(pendingHolds.reduce((sum,h)=>sum+Number(h.amount||0),0));
    if($('#cardHoldList'))$('#cardHoldList').innerHTML=pendingHolds.slice(0,8).map(h=>`<div class="lp-hold-row"><span>${esc(h.status||'pending')}</span> <strong>${money(h.amount)}</strong> <small>${date(h.updated_at||h.authorized_at)}</small></div>`).join('')||'No pending card authorizations.';
    $('#transfersBody').innerHTML=transfers.map(t=>`<tr><td>${date(t.created_at)}</td><td>${esc(t.from_name||'Account')} → ${esc(t.to_name||'Account')}</td><td>${money(t.amount)}</td><td>${status(t.status)}</td></tr>`).join('')||empty(4,'No transfer requests yet.');
    $('#cardsBody').innerHTML=cards.map(c=>{const linked=accountMap.get(c.account_id);const issued=Boolean(c.provider_card_id||c.external_card_id||c.last4);const lifecycle=String(c.lifecycle_status||'current').toLowerCase();const active=String(c.status||'').toLowerCase()==='active';const terminal=['closed','closing','replaced'].includes(lifecycle)||['closed','cancelled'].includes(String(c.status||'').toLowerCase());const pendingReplace=Boolean(c.replacement_requested_at),pendingClose=Boolean(c.closure_requested_at);const lifecycleActions=terminal?'':`${pendingReplace?'<span class="lp-help">Replacement requested</span>':`<button class="lp-mini" data-card-lifecycle="${esc(c.id)}" data-lifecycle-action="replace">Replace</button>`} ${pendingClose?'<span class="lp-help">Closure requested</span>':`<button class="lp-mini danger" data-card-lifecycle="${esc(c.id)}" data-lifecycle-action="close">Close</button>`}`;const controls=terminal?`<button class="lp-mini" data-card-sync="${esc(c.id)}">Refresh status</button>`:(active?`<button class="lp-mini" data-card-lock="${esc(c.id)}" data-locked="${c.locked?'true':'false'}">${c.locked?'Unlock':'Lock'}</button> <button class="lp-mini" data-card-sync="${esc(c.id)}">Refresh status</button> ${lifecycleActions}`:(issued?`<button class="lp-mini" data-card-activate="${esc(c.id)}">Activate</button> <button class="lp-mini" data-card-sync="${esc(c.id)}">Refresh status</button> ${lifecycleActions}`:`<span class="lp-help">Awaiting issuance</span>`));return `<tr><td><strong>${esc(c.nickname||c.card_type||'Card')}</strong><br><small>${esc(c.card_type||'Card')}</small></td><td>${esc(linked?.name||'Not linked')}</td><td>•••• ${esc(c.last4||'PENDING')}</td><td>${status(c.locked?'locked':c.status)}</td><td>${controls}</td></tr>`}).join('')||empty(5,'No card requests yet.');
    if($('#cardTotal'))$('#cardTotal').textContent=cards.length;
    if($('#cardActive'))$('#cardActive').textContent=cards.filter(c=>c.status==='active').length;
    if($('#cardLocked'))$('#cardLocked').textContent=cards.filter(c=>c.locked).length;
    $('#applicationsBody').innerHTML=apps.map(a=>`<tr><td>${esc(a.title||'Application')}</td><td>${esc(a.reference||a.id)}</td><td>${status(a.status||'submitted')}</td><td>${date(a.created_at)}</td></tr>`).join('')||empty(4,'No applications yet.');
    const overviewApps=apps.slice(0,3);
    $('#overviewApplicationsBody').innerHTML=overviewApps.map(a=>`<tr><td>${esc(a.title||'Application')}</td><td>${esc(a.reference||a.id)}</td><td>${status(a.status||'submitted')}</td></tr>`).join('')||empty(3,'No submitted applications yet.');
    $('#latestApplicationStatus').textContent=apps.length?`Latest: ${apps[0].title||'Application'} — ${humanStatus(apps[0].status||'submitted')} (${date(apps[0].created_at)})`:'No submitted applications yet.';
    $('#applicationSystemStatus').textContent=apps.length?`${apps.length} tracked`:'none submitted';
    $('#overviewAccountCount').textContent=accounts.length;
    $('#overviewTransactionCount').textContent=tx.length;
    $('#overviewTransferCount').textContent=transfers.filter(item=>pendingPattern.test(item.status||'')).length;
    $('#overviewCardCount').textContent=cards.length;
    renderNotifications(notifications);
    renderMessages(messages);
    populateProfile();
    renderStatement(accounts,tx,total);
    const adminLink=$('#adminPortalLink');if(adminLink)adminLink.hidden=!['owner','admin','staff','reviewer'].includes(String(profile?.role||'').toLowerCase());
    $('#lastUpdated').textContent=`Last updated: ${new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}`;
    const applicationButton=$('#fullApplicationButton');
    if(applicationButton){
      applicationButton.onclick=null;
      if(apps.length){
        applicationButton.textContent=apps.length===1?'View Submitted Application':`View ${apps.length} Submitted Applications`;
        applicationButton.href='#panel-applications';
        applicationButton.onclick=event=>{event.preventDefault();activatePanel('applications');$('.lp-tab[data-panel="applications"]')?.scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'});$('#panel-applications')?.scrollIntoView({behavior:'smooth',block:'start'});};
      }else{applicationButton.textContent='Start Full Application';applicationButton.href='apply.html';}
    }
    const activeAccounts=accounts.filter(a=>/active|open/i.test(a.status||''));
    const opts=activeAccounts.map(a=>`<option value="${esc(a.id)}" data-name="${esc(a.name||'Account')}">${esc(a.name||'Account')} — ${money(a.balance)}</option>`).join('');
    $('#fromAccount').innerHTML=opts||'<option value="">No active accounts</option>';
    $('#toAccount').innerHTML=opts||'<option value="">No active accounts</option>';
    $('#cardAccount').innerHTML='<option value="">Choose an active account</option>'+opts;
    const currentStatementAccount=$('#statementAccount').value||'all';
    $('#statementAccount').innerHTML='<option value="all">All accounts</option>'+activeAccounts.map(a=>`<option value="${esc(a.id)}">${esc(a.name||'Account')}</option>`).join('');
    $('#statementAccount').value=[...$('#statementAccount').options].some(o=>o.value===currentStatementAccount)?currentStatementAccount:'all';
    if(!$('#statementMonth').value)$('#statementMonth').value=new Date().toISOString().slice(0,7);
    $('#transferForm').querySelector('button[type=submit]').disabled=activeAccounts.length<2;
    if(dataState){dataState.textContent='Current';dataState.classList.remove('pending','error');}
    if(showToast)toast('Portal data refreshed.');
  }catch(error){
    if(dataState){dataState.textContent='Needs attention';dataState.classList.remove('pending');dataState.classList.add('error');}console.error(error);setConnection('PORTAL DATA ERROR',true);toast(friendlyError(error),true);}
  finally{isRendering=false;if(refresh){refresh.disabled=false;refresh.textContent='Refresh Data';}}
}
function date(value){const d=new Date(value);return Number.isNaN(d.getTime())?'—':d.toLocaleDateString('en-US');}
function empty(n,message='No records yet.'){return `<tr><td colspan="${n}" class="lp-empty">${esc(message)}</td></tr>`;}
function humanStatus(value){return String(value||'pending').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());}
function status(value){return `<span class="lp-status lp-status-${esc(String(value||'pending').toLowerCase().replace(/[^a-z0-9]+/g,'-'))}">${esc(humanStatus(value))}</span>`;}
async function submitTransfer(e){
  e.preventDefault();
  const from=$('#fromAccount'),to=$('#toAccount'),amount=Number($('#transferAmount').value);
  if(!from.value||!to.value||!amount||amount<=0||from.value===to.value)return toast('Choose two different active accounts and enter a valid amount.',true);
  await runSubmission(e.submitter,'Processing…',async()=>{const requestId=crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`;const {data,error}=await sb.rpc('internal_transfer',{p_from_account:from.value,p_to_account:to.value,p_amount:amount,p_memo:'Portal internal transfer',p_request_id:requestId});if(error)throw error;toast(`Internal transfer ${humanStatus(data?.status||'submitted')}.`);e.target.reset();await renderAll();});
}
async function submitCard(e){
  e.preventDefault();
  const accountId=$('#cardAccount').value;
  if(!accountId)return toast('Choose an active account to link to this card request.',true);
  await runSubmission(e.submitter,'Submitting…',async()=>{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before requesting a card.');const raw=$('#cardType').value;const map={debit:'VISA_DEBIT',visa_debit:'VISA_DEBIT',visa_credit:'VISA_CREDIT',credit:'VISA_CREDIT',mastercard_credit:'MASTERCARD_CREDIT'};const product=map[String(raw).toLowerCase()]||String(raw).toUpperCase();const response=await fetch('/api/cards/issuance',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({accountId,product,nickname:$('#cardNickname').value.trim()||null})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.message||data.error||'Card issuer request failed.');toast(`Card request accepted — ${humanStatus(data.status||'pending')}.`);e.target.reset();await renderAll();});
}
async function submitApplication(e){
  e.preventDefault();
  await runSubmission(e.submitter,'Submitting…',async()=>{const title=$('#applicationType').value;const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before submitting an application.');const r=await fetch('/api/applications',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({title,legalName:profile?.full_name||user.user_metadata?.full_name||user.email})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(apiError(d,'Application submission failed.'));toast('Application submitted and added to status tracking.');e.target.reset();await renderAll();});
}
async function runSubmission(button,busyText,action,key=''){
  const guard=key||button?.dataset?.actionGuard||'';
  if(guard&&cardActionInFlight.has(guard)){toast('That card action is already processing.');return;}
  if(guard)cardActionInFlight.add(guard);
  const label=button?.textContent;if(button){button.disabled=true;button.setAttribute('aria-busy','true');button.textContent=busyText;}
  try{await action();}catch(error){console.error(error);toast(friendlyError(error),true);}finally{if(guard)cardActionInFlight.delete(guard);if(button){button.disabled=false;button.removeAttribute('aria-busy');button.textContent=label;}}
}
function toast(msg,bad=false){const el=$('#toast');el.textContent=msg;el.className='lp-toast'+(bad?' lp-danger':'')+' show';clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),5000);}

function renderNotifications(items){
  const unread=items.filter(n=>!n.read).length;
  const badge=$('#notificationBadge');if(badge)badge.textContent=unread?`(${unread})`:'';
  const list=$('#notificationsList');if(!list)return;
  list.innerHTML=items.map(n=>`<article class="lp-notification ${n.read?'':'unread'}"><div><strong>${esc(n.title)}</strong><p>${esc(n.body)}</p><small>${date(n.created_at)}</small></div>${n.read?'':`<button class="lp-mini" data-read-notification="${esc(n.id)}">Mark Read</button>`}</article>`).join('')||'<p class="lp-empty">No notifications yet.</p>';
}
function renderStatement(accounts,tx,total){
  const monthInput=$('#statementMonth');
  const selectedMonth=monthInput?.value||new Date().toISOString().slice(0,7);
  const accountId=$('#statementAccount')?.value||'all';
  const accountMap=new Map(accounts.map(a=>[a.id,a]));
    window.__portalAccounts=accounts;
    window.__portalAccountMap=accountMap;
  const filtered=tx.filter(t=>{
    const d=new Date(t.created_at);if(Number.isNaN(d.getTime()))return false;
    const month=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
    return month===selectedMonth&&(accountId==='all'||t.account_id===accountId);
  });
  const includedAccounts=accountId==='all'?accounts:accounts.filter(a=>a.id===accountId);
  const ending=includedAccounts.reduce((sum,a)=>sum+Number(a.balance||0),0);
  const credits=filtered.filter(t=>Number(t.amount||0)>0).reduce((s,t)=>s+Number(t.amount||0),0);
  const debits=Math.abs(filtered.filter(t=>Number(t.amount||0)<0).reduce((s,t)=>s+Number(t.amount||0),0));
  const net=filtered.reduce((s,t)=>s+Number(t.amount||0),0);
  const beginning=ending-net;
  $('#statementBeginning').textContent=money(beginning);
  $('#statementCredits').textContent=money(credits);
  $('#statementDebits').textContent=money(debits);
  $('#statementBalance').textContent=money(ending);
  $('#statementAccounts').textContent=includedAccounts.length;
  $('#statementTransactions').textContent=filtered.length;
  $('#statementGenerated').textContent=new Date().toLocaleString();
  const label=accountId==='all'?'All accounts':(accountMap.get(accountId)?.name||'Account');
  $('#statementPreview').innerHTML=`<h3>TMM SonoraPort Banking Statement</h3><p>${esc(profile?.full_name||'Client')} · ${esc(profile?.email||user.email||'')}</p><p><strong>Period:</strong> ${esc(selectedMonth)} · <strong>Account:</strong> ${esc(label)}</p><p>Generated ${esc(new Date().toLocaleString())}</p><hr><div class="lp-statement-totals"><p><strong>Beginning:</strong> ${money(beginning)}</p><p><strong>Credits:</strong> ${money(credits)}</p><p><strong>Debits:</strong> ${money(debits)}</p><p><strong>Ending:</strong> ${money(ending)}</p></div><h3>Activity</h3>${filtered.map(t=>`<p>${date(t.created_at)} · ${esc(accountMap.get(t.account_id)?.name||'Account')} · ${esc(t.description||'Transaction')} · ${money(t.amount)}</p>`).join('')||'<p>No activity for this period.</p>'}`;
  window.__portalTransactions=filtered;
  window.__statementMeta={selectedMonth,label,beginning,credits,debits,ending};
}
function downloadTransactions(){
  const rows=window.__portalTransactions||[],meta=window.__statementMeta||{};const csv=[['Statement Period',meta.selectedMonth||''],['Account',meta.label||'All accounts'],['Beginning Balance',meta.beginning||0],['Credits',meta.credits||0],['Debits',meta.debits||0],['Ending Balance',meta.ending||0],[],['Date','Description','Type','Amount','Status'],...rows.map(t=>[date(t.created_at),t.description||'',t.kind||'',t.amount||0,t.status||''])].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=`sonoraport-statement-${meta.selectedMonth||new Date().toISOString().slice(0,7)}.csv`;a.click();URL.revokeObjectURL(a.href);
}
async function markAllRead(){toast('No unread banking notifications.');}
async function handlePortalActions(e){
 const n=e.target.closest('[data-read-notification]');if(n){await runSubmission(n,'Marking…',async()=>{const {error}=await sb.rpc('mark_notification_read',{p_notification:n.dataset.readNotification});if(error)throw error;toast('Notification marked read.');await renderAll();});return}
 const action=e.target.closest('[data-account-action]');if(action){e.preventDefault();e.stopPropagation();openAccountAction(action.dataset.accountId,action.dataset.accountAction);return}
 const card=e.target.closest('[data-account-card]');if(card){openAccountDetails(card.dataset.accountCard);return}
 const a=e.target.closest('[data-card-activate]');if(a){await runSubmission(a,'Activating…',async()=>{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before activating a card.');const response=await fetch('/api/cards/activate',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({cardId:a.dataset.cardActivate})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(apiError(data,'Card activation failed.'));toast(`Issuer activation — ${humanStatus(data.providerStatus||'submitted')}.`);await renderAll();},`card:${a.dataset.cardActivate}`);return;}
 const sync=e.target.closest('[data-card-sync]');if(sync){await runSubmission(sync,'Refreshing…',async()=>{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before refreshing card status.');const response=await fetch('/api/cards/status-sync',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({cardId:sync.dataset.cardSync})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(apiError(data,'Card status refresh failed.'));toast(`Issuer status — ${humanStatus(data.status||'updated')}.`);await renderAll();},`card:${sync.dataset.cardSync}`);return;}
 const life=e.target.closest('[data-card-lifecycle]');if(life){const action=life.dataset.lifecycleAction;if(!confirm(`Request card ${action}?`))return;await runSubmission(life,action==='replace'?'Requesting…':'Closing…',async()=>{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before changing card lifecycle.');const response=await fetch('/api/cards/lifecycle-request',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({cardId:life.dataset.cardLifecycle,action})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(apiError(data,'Card lifecycle request failed.'));toast(data.message||`Card ${action} request recorded.`);await renderAll();},`card:${life.dataset.cardLifecycle}`);return;}
 const c=e.target.closest('[data-card-lock]');if(c){const next=c.dataset.locked!=='true';await runSubmission(c,next?'Locking…':'Unlocking…',async()=>{const session=(await sb.auth.getSession()).data.session;if(!session)throw new Error('Sign in before controlling a card.');const response=await fetch('/api/cards/control',{method:'POST',headers:{Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({cardId:c.dataset.cardLock,action:next?'lock':'unlock'})});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(apiError(data,'Card control request failed.'));toast(next?'Card locked at issuer.':'Card unlocked at issuer.');await renderAll();},`card:${c.dataset.cardLock}`);}
}
function selectAccountIn(selectId,accountId){const select=$(selectId);if(!select)return;select.value=accountId;select.dispatchEvent(new Event('change',{bubbles:true}));}
function openAccountAction(accountId,action){
 if(action==='transactions'){activatePanel('transactions');document.querySelector('#panel-transactions')?.scrollIntoView({behavior:'smooth',block:'start'});return}
 if(action==='transfer'){activatePanel('transfers');selectAccountIn('#fromAccount',accountId);setTimeout(()=>$('#toAccount')?.focus(),150);document.querySelector('#panel-transfers')?.scrollIntoView({behavior:'smooth',block:'start'});return}
 if(action==='statements'){activatePanel('statements');selectAccountIn('#statementAccount',accountId);document.querySelector('#panel-statements')?.scrollIntoView({behavior:'smooth',block:'start'});}
}
function openAccountDetails(accountId){
 const a=window.__portalAccountMap?.get(accountId);if(!a)return toast('Account details are unavailable.',true);
 let modal=$('#accountDetailModal');
 if(!modal){modal=document.createElement('div');modal.id='accountDetailModal';modal.className='lp-modal';modal.innerHTML='<div class="lp-modal-backdrop" data-close-account-modal></div><section class="lp-modal-card" role="dialog" aria-modal="true" aria-labelledby="accountDetailTitle"><button class="lp-modal-close" type="button" data-close-account-modal aria-label="Close">×</button><div id="accountDetailContent"></div></section>';document.body.appendChild(modal);modal.addEventListener('click',ev=>{if(ev.target.closest('[data-close-account-modal]'))modal.classList.remove('show')});}
 const last4=String(a.last4||a.account_last4||a.id||'').slice(-4).toUpperCase();
 $('#accountDetailContent').innerHTML=`<small>${esc(a.type||'Account')}</small><h2 id="accountDetailTitle">${esc(a.name||'Account')}</h2><p class="lp-account-number">•••• •••• •••• ${esc(last4||'----')}</p><div class="lp-account-balances"><span><small>Current balance</small><strong>${money(a.balance)}</strong></span><span><small>Available balance</small><strong>${money(a.available_balance??a.balance??0)}</strong></span></div><p>Status: ${status(a.status||'active')}</p><p>Opened: ${date(a.created_at)}</p><div class="lp-account-actions"><button class="lp-btn" type="button" data-account-action="transfer" data-account-id="${esc(a.id)}">Transfer</button><button class="lp-btn" type="button" data-account-action="transactions" data-account-id="${esc(a.id)}">View Activity</button><button class="lp-btn" type="button" data-account-action="statements" data-account-id="${esc(a.id)}">Statements</button></div>`;
 modal.classList.add('show');
}


async function submitMessage(e){e.preventDefault();const subject=$('#messageSubject').value.trim(),body=$('#messageBody').value.trim();if(!subject||!body)return toast('Enter a subject and message.',true);await runSubmission(e.submitter,'Sending…',async()=>{await insert('secure_messages',{sender_id:user.id,subject,body,direction:'customer_to_staff',status:'open'});toast('Secure message sent.');e.target.reset();await renderAll();});}
function renderMessages(items){const list=$('#messagesList');if(!list)return;const unread=items.filter(m=>m.direction==='staff_to_customer'&&!m.read_at).length;const badge=$('#messageBadge');if(badge)badge.textContent=unread?`(${unread})`:'';list.innerHTML=items.map(m=>`<article class="lp-notification ${m.direction==='staff_to_customer'&&!m.read_at?'unread':''}"><div><strong>${esc(m.subject)}</strong><p>${esc(m.body)}</p><small>${m.direction==='staff_to_customer'?'Operations → You':'You → Operations'} · ${date(m.created_at)} · ${esc(humanStatus(m.status))}</small></div></article>`).join('')||'<p class="lp-empty">No secure messages yet.</p>';}
function populateProfile(){if(!$('#profileForm'))return;$('#profileName').value=profile?.full_name||user.user_metadata?.full_name||'';$('#profileEmail').value=profile?.email||user.email||'';$('#profileRoleDetail').textContent=humanStatus(profile?.role||'customer');const prefs=profile?.preferences||{};$('#prefTransactions').value=String(prefs.transaction_alerts!==false);$('#prefApplications').value=String(prefs.application_alerts!==false);}
async function saveProfile(e){e.preventDefault();const full_name=$('#profileName').value.trim();const preferences={transaction_alerts:$('#prefTransactions').value==='true',application_alerts:$('#prefApplications').value==='true'};await runSubmission(e.submitter,'Saving…',async()=>{const {error}=await sb.from('profiles').update({full_name,preferences}).eq('id',user.id);if(error)throw error;await loadProfile();toast('Profile settings saved.');});}
let inactivityTimer;function resetInactivity(){clearTimeout(inactivityTimer);inactivityTimer=setTimeout(async()=>{try{await sb.auth.signOut()}finally{redirectToSignIn()}},30*60*1000)}['click','keydown','touchstart','mousemove'].forEach(ev=>document.addEventListener(ev,resetInactivity,{passive:true}));resetInactivity();

document.addEventListener('DOMContentLoaded',boot);
