# BUILD 075 — Card lifecycle UI hardening

- Preserves BUILD 074 current-schema alignment and BUILD 073 card contrast.
- Adds provider status refresh control for issued debit and credit cards.
- Normalizes API error messages so provider/server failures are visible instead of generic button failures.
- Keeps server-side ownership checks for activation, lock/unlock, and status sync.
- Does not change or bypass the production cutover lock.
