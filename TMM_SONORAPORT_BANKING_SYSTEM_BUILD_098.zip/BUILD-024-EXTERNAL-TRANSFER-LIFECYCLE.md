# Build 024 — External transfer lifecycle

Adds authenticated customer transfer-status retrieval and V27 lifecycle metadata for ACH/Wire payment reservations. Provider callbacks remain authoritative for settlement, rejection, and return outcomes. No provider status is manufactured locally.
