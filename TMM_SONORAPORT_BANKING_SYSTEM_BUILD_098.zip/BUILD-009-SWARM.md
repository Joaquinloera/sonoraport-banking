# TMM SonoraPort Banking — Build 009

Authoritative parent: Build 008.

## Gate work
- Removed the stale Admin `issue_sandbox_card` issuance action so Admin can no longer bypass the provider-backed card boundary.
- Added authenticated `card-issuer-readiness` diagnostics without exposing issuer credentials.
- Added authenticated `biometric-readiness` diagnostics without exposing the Supabase service-role key.
- Customer card requests remain bound to an authenticated active owned account and the configured issuer API.
- Supported issuance products remain Visa Debit, Visa Credit, and Mastercard Credit.
- Updated card copy so provider-returned state/last-four is authoritative.

No PAN, CVV, provider secret, settlement result, or account balance is manufactured by this build.
