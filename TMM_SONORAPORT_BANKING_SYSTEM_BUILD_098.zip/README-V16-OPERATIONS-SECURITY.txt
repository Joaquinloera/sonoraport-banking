SONORAPORT AI BANKING V16.1 — AUDITED OPERATIONS & SECURITY

Run this SQL once before deployment:
supabase/SONORAPORT-V16-OPERATIONS-SECURITY.sql

Then deploy the complete ZIP to Netlify.

Includes customer secure messages, profile preferences, 30-minute inactivity sign-out, admin search, account controls, card controls, secure replies, audit logs, operations metrics, and mobile layout.

Security corrections in V16.1 prevent customer role escalation, restrict direct card edits, enforce submitted application status, and constrain customer message inserts.

Sandbox only: no real money movement or live card issuance.
