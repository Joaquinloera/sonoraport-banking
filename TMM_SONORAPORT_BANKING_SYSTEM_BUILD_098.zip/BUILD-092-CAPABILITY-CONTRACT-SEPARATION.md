# BUILD 092 — Capability Contract Separation

Parent: BUILD 091.

- Preserves BUILD 089 database certification work.
- Preserves BUILD 090 refresh behavior.
- Preserves BUILD 091 ordered verification and automatic Admin verification.
- Separates local capability configuration from provider authentication and live verification.
- Balances API now reports configured only when a valid API base origin and an explicit provider balances path are configured.
- Bank Payments API now reports configured only when a valid API base origin, explicit payment path, and OAuth scope are configured.
- Adds non-destructive aliases for existing provider/path naming families without embedding values.
- Provider Auth, Account Access, Payment Readiness, Cutover, and Operations remain verification-gated and are never manufactured as successful.
