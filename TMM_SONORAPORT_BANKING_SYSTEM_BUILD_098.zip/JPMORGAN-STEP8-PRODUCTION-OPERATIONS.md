# JPMorgan Step 8 — Production Operations and Fail-Safe Controls

This step adds a server-side operational gate to every standard and controlled JPMorgan payment submission.

## Netlify environment variables

Set these variables deliberately:

- `JPMORGAN_PAYMENT_OPERATIONS_ENABLED=false` while configuring or testing.
- `JPMORGAN_EMERGENCY_STOP=false` during normal operation.
- `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=false` until Step 7 passes.

Only after all production checks pass should payment operations be enabled:

- `JPMORGAN_PAYMENT_OPERATIONS_ENABLED=true`
- `JPMORGAN_EMERGENCY_STOP=false`
- `JPMORGAN_PRODUCTION_CUTOVER_APPROVED=true`

To stop all payment submissions immediately, set:

- `JPMORGAN_EMERGENCY_STOP=true`

Then trigger a new Netlify deploy so functions receive the changed environment value. The stop applies to normal payment requests and controlled certification payments.

## Added function

- `/.netlify/functions/jpmorgan-operations-health`

It requires a signed-in user and reports only safe operational state. It does not expose credentials, account numbers, or secrets.

## Fail-safe behavior

Payment functions return HTTP 423 with code `PAYMENT_OPERATIONS_LOCKED` whenever:

- JPMorgan is disabled;
- payment operations are not explicitly enabled;
- the emergency stop is active; or
- a production-labelled environment lacks explicit cutover approval.
