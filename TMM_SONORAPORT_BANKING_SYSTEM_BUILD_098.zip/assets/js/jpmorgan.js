const TMM_API_ROUTE=(name)=>({'jpmorgan-status':'/api/banking/status','jpmorgan-production-readiness':'/api/banking/readiness','jpmorgan-operations-health':'/api/banking/health','jpmorgan-beneficiaries':'/api/banking/beneficiaries','jpmorgan-monitoring':'/api/banking/monitoring','jpmorgan-callback-self-test':'/api/banking/callback-self-test','card-issuer-readiness':'/api/cards/issuer-readiness','card-issuer-router-readiness':'/api/cards/readiness','jpmorgan-balances':'/api/banking/balances','jpmorgan-linked-accounts':'/api/banking/linked-accounts','jpmorgan-create-payment':'/api/banking/payments','jpmorgan-transaction-history':'/api/banking/transactions','jpmorgan-statement':'/api/banking/statements','jpmorgan-disputes':'/api/banking/disputes','jpmorgan-refunds':'/api/banking/refunds','jpmorgan-customer-onboarding':'/api/banking/customer-onboarding','jpmorgan-onboard-client':'/api/banking/onboard-client','blackrock-status':'/api/integrations/blackrock/status','blackrock-portfolio':'/api/integrations/blackrock/portfolio','blackrock-risk':'/api/integrations/blackrock/risk','josh':'/api/assistant'}[String(name).split('?')[0]]||null);
document.addEventListener('DOMContentLoaded', async () => {
  let providerEnvironment = '';
  let providerEnabled = false;

  const text = (selector, value) => {
    const element = document.querySelector(selector);
    if (element) element.textContent = value;
  };

  const setState = (selector, value, state = '') => {
    const element = document.querySelector(selector);
    if (!element) return;
    element.textContent = value;
    if (state) element.dataset.state = state;
    else delete element.dataset.state;
  };

  const getAccessToken = () => {
    const session = window.LiveBackend?.getSession?.();
    return session?.session?.access_token || session?.access_token || '';
  };

  const request = async (name, options = {}) => {
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    const accessToken = getAccessToken();
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

    const response = await fetch((()=>{const q=String(name);const base=TMM_API_ROUTE(q);if(!base)throw new Error('Unsupported banking API route.');const i=q.indexOf('?');return base+(i>=0?q.slice(i):'')})(), { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const detail = data.correlationId ? ` Reference: ${data.correlationId}` : '';
      const error = new Error(`${data.error || `Request failed (${response.status})`}${detail}`);
      error.status = response.status;
      error.code = data.code || '';
      error.correlationId = data.correlationId || '';
      throw error;
    }
    return data;
  };

  const yesNo = (value) => value ? 'Ready' : 'Not configured';
  const environmentIsProduction = (value) => /prod|production|live/i.test(String(value || ''));

  try {
    const status = await request('jpmorgan-status', { method: 'GET' });
    providerEnvironment = status.environment || 'Not configured';
    providerEnabled = Boolean(status.enabled);
    const isProduction = environmentIsProduction(providerEnvironment);

    setState('#jpmEnabled', providerEnabled ? 'Configured' : 'Locked', providerEnabled ? 'success' : 'error');
    text('#jpmConnectionDetail', providerEnabled ? 'Required server settings detected' : 'Configuration is incomplete or disabled');
    setState('#jpmEnvironment', providerEnvironment, isProduction ? 'success' : '');
    text('#jpmEnvironmentDetail', isProduction ? 'Production-labelled environment' : 'Testing or non-production environment');
    text('#jpmRelationship', status.relationshipStatus || 'Not configured');
    setState('#jpmBalancesCapability', yesNo(status.products?.balances), status.products?.balances ? 'success' : 'error');
    setState('#jpmPaymentsCapability', yesNo(status.products?.embeddedPayments), status.products?.embeddedPayments ? 'success' : 'error');
    if (status.products?.callbacks) {
      setState('#jpmCallbacksCapability', 'Ready', 'success');
    } else {
      setState('#jpmCallbacksCapability', 'Awaiting provider setup');
    }

    text('#jpmModeLabel', isProduction ? 'J.P. MORGAN PRODUCTION OPERATIONS' : 'J.P. MORGAN TESTING OPERATIONS');
    text('#jpmOnboardTitle', isProduction ? 'Production provider onboarding' : 'Sandbox provider onboarding');
    text('#jpmPaymentEyebrow', isProduction ? 'PRODUCTION PAYMENT REQUEST' : 'SANDBOX PAYMENT REQUEST');
    text('#jpmPaymentTitle', isProduction ? 'Create a live authorized payment' : 'Create a sandbox payment');
    text('#jpmPaymentButton', isProduction ? 'Submit authorized payment' : 'Submit sandbox payment');
    text('#jpmPaymentWarning', isProduction
      ? 'This deployment identifies itself as production. Confirm every field before submitting; a successful provider response may move real funds.'
      : 'This deployment is not identified as production. Requests are expected to remain in the configured testing environment.');
  } catch (error) {
    setState('#jpmEnabled', 'Unavailable', 'error');
    text('#jpmConnectionDetail', error.message);
    setState('#jpmEnvironment', 'Unknown', 'error');
    setState('#jpmRelationship', 'Unknown', 'error');
    console.warn('J.P. Morgan status check failed:', error.message);
  }

  const verifyProviderButton = document.querySelector('#jpmVerifyProvider');
  verifyProviderButton?.addEventListener('click', async () => {
    verifyProviderButton.disabled = true;
    setState('#jpmTokenVerification', 'Testing…');
    text('#jpmTokenVerificationDetail', 'Requesting an access token through the deployed server function.');
    try {
      const result = await request('jpmorgan-status?verify=token', { method: 'GET' });
      if (result.provider?.token) {
        setState('#jpmTokenVerification', 'Verified', 'success');
        text('#jpmTokenVerificationDetail', `Provider authentication succeeded${result.provider.verifiedAt ? ` at ${new Date(result.provider.verifiedAt).toLocaleString()}` : ''}.`);
      } else {
        const parts = [result.provider?.code, result.provider?.providerCode, result.provider?.httpStatus ? `HTTP ${result.provider.httpStatus}` : ''].filter(Boolean);
        setState('#jpmTokenVerification', 'Failed', 'error');
        text('#jpmTokenVerificationDetail', `Token verification failed${parts.length ? ` — ${parts.join(' / ')}` : ''}. Check the matching production project credentials and authentication method.`);
      }
    } catch (error) {
      setState('#jpmTokenVerification', 'Unavailable', 'error');
      text('#jpmTokenVerificationDetail', error.message);
    } finally {
      verifyProviderButton.disabled = false;
    }
  });

  const verifyAccountButton = document.querySelector('#jpmVerifyAccount');
  verifyAccountButton?.addEventListener('click', async () => {
    verifyAccountButton.disabled = true;
    setState('#jpmAccountVerification', 'Testing…');
    text('#jpmAccountVerificationDetail', 'Checking OAuth and the configured J.P. Morgan product settings without creating a payment.');
    try {
      const result = await request('jpmorgan-status?verify=account', { method: 'GET' });
      if (result.provider?.token && result.provider?.accountAccess) {
        setState('#jpmAccountVerification', 'Verified', 'success');
        text('#jpmAccountVerificationDetail', `Authentication and Online Payments product configuration succeeded${result.provider.verifiedAt ? ` at ${new Date(result.provider.verifiedAt).toLocaleString()}` : ''}. No payment was created.`);
      } else {
        const parts = [result.provider?.code, result.provider?.providerCode, result.provider?.httpStatus ? `HTTP ${result.provider.httpStatus}` : ''].filter(Boolean);
        const blockers = Array.isArray(result.provider?.blockers) ? result.provider.blockers : [];
        setState('#jpmAccountVerification', 'Failed', 'error');
        text('#jpmAccountVerificationDetail', blockers.length
          ? `Product access failed — fix: ${blockers.join(', ')}. No payment was created.`
          : `Product access failed${parts.length ? ` — ${parts.join(' / ')}` : ''}. Confirm the Online Payments project permissions. No payment was created.`);
      }
    } catch (error) {
      setState('#jpmAccountVerification', 'Unavailable', 'error');
      text('#jpmAccountVerificationDetail', error.message);
    } finally {
      verifyAccountButton.disabled = false;
    }
  });

  const verifyPaymentButton = document.querySelector('#jpmVerifyPayment');
  verifyPaymentButton?.addEventListener('click', async () => {
    verifyPaymentButton.disabled = true;
    setState('#jpmPaymentVerification', 'Testing…');
    text('#jpmPaymentVerificationDetail', 'Checking authentication, Online Payments configuration, payment controls, endpoint settings, and callback readiness. No payment will be sent.');
    try {
      const result = await request('jpmorgan-status?verify=payment', { method: 'GET' });
      if (result.provider?.token && result.provider?.accountAccess && result.provider?.paymentReadiness) {
        const controls = result.provider.paymentControls || {};
        const warnings = Array.isArray(controls.warnings) ? controls.warnings : [];
        const callbackNote = controls.callbackVerificationConfigured ? 'Callback verification is configured.' : 'Callback verification is still pending.';
        const warningNote = warnings.length ? ` Remaining setup: ${warnings.join(', ')}.` : '';
        setState('#jpmPaymentVerification', warnings.length ? 'Core controls passed' : 'Ready for controlled test', warnings.length ? '' : 'success');
        text('#jpmPaymentVerificationDetail', `Authentication, Online Payments configuration, payment endpoint, limits, allowed rails, currencies, and idempotency controls passed. ${callbackNote}${warningNote} No funds were moved.`);
      } else {
        const parts = [result.provider?.code, result.provider?.providerCode, result.provider?.httpStatus ? `HTTP ${result.provider.httpStatus}` : ''].filter(Boolean);
        const blockers = Array.isArray(result.provider?.blockers) ? result.provider.blockers : [];
        setState('#jpmPaymentVerification', 'Failed', 'error');
        text('#jpmPaymentVerificationDetail', blockers.length
          ? `Payment readiness failed — fix: ${blockers.join(', ')}. No payment was sent.`
          : `Payment readiness failed${parts.length ? ` — ${parts.join(' / ')}` : ''}. No payment was sent.`);
      }
    } catch (error) {
      setState('#jpmPaymentVerification', 'Unavailable', 'error');
      text('#jpmPaymentVerificationDetail', `${error.message} No payment was sent.`);
    } finally {
      verifyPaymentButton.disabled = false;
    }
  });

  const verifyCallbackButton = document.querySelector('#jpmVerifyCallback');
  verifyCallbackButton?.addEventListener('click', async () => {
    verifyCallbackButton.disabled = true;
    setState('#jpmCallbackVerification', 'Testing…');
    text('#jpmCallbackVerificationDetail', 'Running signed callback, forged-signature, and expired-timestamp checks through the deployed callback handler.');
    try {
      const result = await request('jpmorgan-callback-self-test', { method: 'GET' });
      if (result.verified) {
        setState('#jpmCallbackVerification', result.providerRegistrationPending ? 'Core controls passed' : 'Verified', 'success');
        text('#jpmCallbackVerificationDetail', result.providerRegistrationPending
          ? `Signed callback handling, forged-signature rejection, and stale-timestamp rejection passed${result.verifiedAt ? ` at ${new Date(result.verifiedAt).toLocaleString()}` : ''}. Provider callback registration is still pending. No funds were moved.`
          : `Valid callbacks were accepted and forged or stale callbacks were rejected${result.verifiedAt ? ` at ${new Date(result.verifiedAt).toLocaleString()}` : ''}. No funds were moved.`);
        setState('#jpmCallbacksCapability', result.providerRegistrationPending ? 'Core controls passed' : 'Verified', 'success');
      } else {
        const failed = Object.entries(result.checks || {}).filter(([, passed]) => !passed).map(([name]) => name).join(', ');
        setState('#jpmCallbackVerification', 'Failed', 'error');
        text('#jpmCallbackVerificationDetail', `Callback security test failed${failed ? ` — ${failed}` : ''}. No payment was created.`);
      }
    } catch (error) {
      setState('#jpmCallbackVerification', 'Unavailable', 'error');
      text('#jpmCallbackVerificationDetail', `${error.message} No payment was created.`);
    } finally {
      verifyCallbackButton.disabled = false;
    }
  });

  const onboard = document.querySelector('#jpmOnboard');
  onboard?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = onboard.querySelector('button[type="submit"]');
    if (!providerEnabled) {
      setState('#jpmOnboardResult', 'J.P. Morgan configuration is not enabled.', 'error');
      return;
    }
    if (button) button.disabled = true;
    setState('#jpmOnboardResult', 'Submitting onboarding request…');
    try {
      const data = Object.fromEntries(new FormData(onboard));
      const result = await request('jpmorgan-onboard-client', { method: 'POST', body: JSON.stringify(data) });
      const message = result.linkStatus === 'linked'
        ? 'Onboarding accepted and the provider account was securely linked.'
        : 'Onboarding submitted. The provider account is awaiting a returned account identifier.';
      setState('#jpmOnboardResult', message, 'success');
      window.DB?.toast?.(message);
    } catch (error) {
      setState('#jpmOnboardResult', error.message, 'error');
      window.DB?.toast?.(error.message, 'danger');
    } finally {
      if (button) button.disabled = false;
    }
  });

  const linkedAccountSelect = document.querySelector('#jpmLinkedAccountSelect');
  const linkedAccountWrap = document.querySelector('#jpmLinkedAccountWrap');

  const signInForCurrentPage = () => {
    const next = encodeURIComponent(`${location.pathname.split('/').pop() || 'jpmorgan.html'}${location.search}${location.hash}`);
    sessionStorage.setItem('sonoraport_auth_next', decodeURIComponent(next));
    location.href = `sign-in.html?next=${next}`;
  };

  const loadLinkedAccounts = async () => {
    if (!getAccessToken() || !linkedAccountSelect) return [];
    const result = await request('jpmorgan-linked-accounts', { method: 'GET' });
    const accounts = Array.isArray(result.linkedAccounts) ? result.linkedAccounts : [];
    linkedAccountSelect.innerHTML = '<option value="">Select linked account</option>';
    accounts.forEach((account) => {
      const option = document.createElement('option');
      option.value = account.id;
      const ending = account.last4 ? ` ••••${account.last4}` : '';
      option.textContent = `${account.name || 'Linked account'}${ending}${account.type ? ` — ${account.type}` : ''}`;
      linkedAccountSelect.appendChild(option);
    });
    if (accounts.length === 1) linkedAccountSelect.value = accounts[0].id;
    if (linkedAccountWrap) linkedAccountWrap.style.display = accounts.length ? 'block' : 'none';

    // Keep the payment source selector bound to the same server-authorized linked accounts.
    const paymentSource = document.querySelector('#jpmPaymentLinkedAccount');
    if (paymentSource) {
      const previous = paymentSource.value;
      paymentSource.innerHTML = '<option value="">Select linked source account</option>';
      accounts.forEach((account) => {
        const option = document.createElement('option');
        option.value = account.id;
        const ending = account.last4 ? ` ••••${account.last4}` : '';
        option.textContent = `${account.name || 'Linked account'}${ending}${account.type ? ` — ${account.type}` : ''}`;
        paymentSource.appendChild(option);
      });
      if (previous && accounts.some((account) => account.id === previous)) paymentSource.value = previous;
      else if (accounts.length === 1) paymentSource.value = accounts[0].id;
    }
    return accounts;
  };

  if (getAccessToken()) {
    loadLinkedAccounts().catch((error) => console.warn('Linked account list unavailable:', error.message));
  }

  const balancesButton = document.querySelector('#jpmLoadBalances');
  balancesButton?.addEventListener('click', async () => {
    if (!getAccessToken()) {
      setState('#jpmBalancesResult', 'Sign in is required before private linked-account data can be loaded. Redirecting to secure sign in…');
      setTimeout(signInForCurrentPage, 450);
      return;
    }
    balancesButton.disabled = true;
    setState('#jpmBalancesResult', 'Loading approved linked accounts…');
    try {
      const accounts = await loadLinkedAccounts();
      if (!accounts.length) {
        setState('#jpmBalancesResult', 'No active J.P. Morgan account is linked to this signed-in profile yet.', 'success');
        return;
      }
      const selectedId = linkedAccountSelect?.value || accounts[0]?.id || '';
      if (!selectedId) {
        setState('#jpmBalancesResult', 'Select an approved linked account before loading its private balance.', 'error');
        return;
      }
      setState('#jpmBalancesResult', 'Loading the selected private provider balance…');
      const result = await request(`jpmorgan-balances?linkedAccountId=${encodeURIComponent(selectedId)}`, { method: 'GET' });
      const account = result.linkedAccount || {};
      const output = {
        provider: result.provider,
        linkedAccount: {
          name: account.name || 'Linked account',
          type: account.type || '',
          last4: account.last4 ? `••••${account.last4}` : '',
        },
        balances: result.balances,
        correlationId: result.correlationId,
      };
      setState('#jpmBalancesResult', JSON.stringify(output, null, 2), 'success');
    } catch (error) {
      if (error.code === 'AUTH_REQUIRED') {
        setState('#jpmBalancesResult', 'Your secure session expired. Sign in again to load private balance data.', 'error');
      } else if (error.code === 'PROVIDER_ACCOUNT_NOT_LINKED') {
        setState('#jpmBalancesResult', 'Core controls passed. No active J.P. Morgan account is linked to this profile yet.', 'success');
      } else {
        setState('#jpmBalancesResult', error.message, 'error');
      }
    } finally {
      balancesButton.disabled = false;
    }
  });

  const payment = document.querySelector('#jpmPayment');
  payment?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = payment.querySelector('button[type="submit"]');
    const confirmation = document.querySelector('#jpmConfirmPayment');
    if (!providerEnabled) {
      setState('#jpmPaymentResult', 'J.P. Morgan configuration is not enabled.', 'error');
      return;
    }
    if (!confirmation?.checked) {
      setState('#jpmPaymentResult', 'Confirm the payment details before submitting.', 'error');
      return;
    }
    const data = Object.fromEntries(new FormData(payment));
    if (!data.linkedAccountId) {
      setState('#jpmPaymentResult', 'Select an authorized linked source account before submitting.', 'error');
      return;
    }
    const amount = Number(data.amount);
    const environmentLabel = providerEnvironment || 'configured environment';
    const warning = `Submit ${data.currency || 'USD'} ${Number.isFinite(amount) ? amount.toFixed(2) : data.amount} by ${data.paymentMethod} to the selected approved beneficiary in ${environmentLabel}?`;
    if (!window.confirm(warning)) return;

    if (button) button.disabled = true;
    setState('#jpmPaymentResult', 'Submitting payment request…');
    try {
      const result = await request('jpmorgan-create-payment', { method: 'POST', body: JSON.stringify(data) });
      const paymentData = result?.payment || {};
      const providerStatus = paymentData.status || paymentData.state || result?.status || 'submitted';
      const providerId = paymentData.id || paymentData.paymentId || paymentData.externalPaymentId || '';
      const message = result?.heldForReview
        ? `Payment held for review. Review reference: ${result.reviewId}. Required approvals: ${result.risk?.requiredApprovals || 1}. No funds were sent.`
        : (providerId
          ? `Payment ${providerStatus}. Provider reference: ${providerId}.`
          : `Payment request ${providerStatus}. Reference: ${result.correlationId || 'not returned'}.`);
      setState('#jpmPaymentResult', message, result?.heldForReview ? '' : 'success');
      window.DB?.toast?.(message);
      payment.reset();
    } catch (error) {
      setState('#jpmPaymentResult', error.message, 'error');
      window.DB?.toast?.(error.message, 'danger');
    } finally {
      if (button) button.disabled = false;
    }
  });
});


// Beneficiary enrollment and selection for payment submission.
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('jpmBeneficiaryForm');
  const loadButton = document.getElementById('jpmLoadBeneficiaries');
  const result = document.getElementById('jpmBeneficiaryResult');
  const select = document.getElementById('jpmBeneficiarySelect');
  if (!form || !loadButton || !result || !select) return;

  const token = () => {
    const session = window.LiveBackend?.getSession?.();
    return session?.session?.access_token || session?.access_token || '';
  };
  const call = async (options = {}) => {
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    const accessToken = token();
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await fetch('/api/banking/beneficiaries', { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || `Request failed (${response.status})`);
      error.code = data.code || '';
      throw error;
    }
    return data;
  };
  const render = (rows = []) => {
    const active = rows.filter((row) => row.status === 'active');
    select.innerHTML = '<option value="">Select an active beneficiary</option>';
    active.forEach((row) => {
      const option = document.createElement('option');
      option.value = row.id;
      option.textContent = `${row.display_name} · ${String(row.destination_type || '').toUpperCase()} · ${row.currency}`;
      select.appendChild(option);
    });
    result.textContent = rows.length
      ? `${active.length} active of ${rows.length} enrolled beneficiar${rows.length === 1 ? 'y' : 'ies'}. Pending or cooling-off beneficiaries cannot receive payments.`
      : 'No beneficiaries are enrolled for this signed-in profile.';
    result.dataset.state = active.length ? 'success' : '';
  };
  const load = async () => {
    const data = await call({ method: 'GET' });
    render(data.beneficiaries || []);
  };
  loadButton.addEventListener('click', async () => {
    loadButton.disabled = true;
    result.textContent = 'Loading beneficiaries…';
    try { await load(); }
    catch (error) { result.textContent = `${error.message}${error.code ? ` (${error.code})` : ''}`; result.dataset.state = 'error'; }
    finally { loadButton.disabled = false; }
  });
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    if (button) button.disabled = true;
    result.textContent = 'Submitting beneficiary for review…';
    try {
      const body = Object.fromEntries(new FormData(form));
      const data = await call({ method: 'POST', body: JSON.stringify(body) });
      result.textContent = `Beneficiary enrolled with status ${data.beneficiary?.status || 'pending_review'}. It must be approved and active before payment submission.`;
      result.dataset.state = 'success';
      form.reset();
      await load();
    } catch (error) {
      result.textContent = `${error.message}${error.code ? ` (${error.code})` : ''}`;
      result.dataset.state = 'error';
    } finally { if (button) button.disabled = false; }
  });
});

const jpmGateLabel = (name) => ({
  productionCutoverApproved: 'J.P. Morgan production cutover approval',
  callbackSecurityConfigured: 'provider callback registration and security configuration',
  callbackVerificationConfigured: 'provider callback registration and verification',
  transactionStatusPathConfigured: 'provider transaction-status endpoint',
  transactionStatusConfigured: 'provider transaction-status endpoint',
  signedInProfileAvailable: 'signed-in SonoraPort operator profile',
  certificationExists: 'controlled certification record',
  controlledCertificationSettled: 'settled controlled certification transaction',
  certificationCallbackVerified: 'verified provider callback for certification',
  paymentOperationsEnabled: 'live payment operations enablement',
  cutoverApprovedForEnvironment: 'production cutover approval for this environment',
  merchantIdConfigured: 'J.P. Morgan merchant ID',
  providerEnabled: 'J.P. Morgan provider enablement',
  environmentSelected: 'approved provider environment',
  credentialsConfigured: 'provider credentials',
  tokenEndpointConfigured: 'provider token endpoint',
  onlinePaymentsBaseUrlConfigured: 'Online Payments API base URL',
  onlinePaymentsPathConfigured: 'Online Payments transaction path',
  onlinePaymentsScopeConfigured: 'Online Payments OAuth scope',
  emergencyStopInactive: 'inactive emergency stop',
}[name] || String(name || '').replace(/_/g, ' ').replace(/([A-Z])/g, ' $1').trim().toLowerCase());

// Step 5 controlled payment certification is intentionally isolated from the normal payment form.
document.addEventListener('DOMContentLoaded', () => {
  const byId = (id) => document.getElementById(id);


  const token = () => {
    const session = window.LiveBackend?.getSession?.();
    return session?.session?.access_token || session?.access_token || '';
  };
  const call = async (name, options = {}) => {
    const headers = { Accept: 'application/json', ...(options.headers || {}) };
    const accessToken = token();
    if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await fetch((()=>{const q=String(name);const base=TMM_API_ROUTE(q);if(!base)throw new Error('Unsupported banking API route.');const i=q.indexOf('?');return base+(i>=0?q.slice(i):'')})(), { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || `Request failed (${response.status})`);
      error.code = data.code || '';
      throw error;
    }
    return data;
  };
  const state = (value, detail, kind = '') => {
    const heading = byId('jpmCertificationState');
    const copy = byId('jpmCertificationDetail');
    if (heading) { heading.textContent = value; if (kind) heading.dataset.state = kind; }
    if (copy) copy.textContent = detail;
  };
  let confirmationText = '';

  async function loadConfiguration() {
    const result = await call('jpmorgan-certification-payment', { method: 'GET' });
    const c = result.certification || {};
    confirmationText = c.confirmationText || '';
    byId('jpmCertificationAmount').textContent = c.amount && c.currency ? `${c.amount} ${c.currency}` : 'Not configured';
    byId('jpmCertificationMethod').textContent = c.paymentMethod || 'Not configured';
    byId('jpmCertificationDestination').textContent = c.destinationConfigured ? 'Configured and hidden' : 'Not configured';
    byId('jpmCertificationCallbacks').textContent = c.callbacksReady ? 'Verified configuration detected' : 'Not ready';
    byId('jpmCertificationConfirmation').placeholder = confirmationText || 'Configuration incomplete';
    const ready = Boolean(c.enabled && c.callbacksReady && c.destinationConfigured && c.runIdConfigured && c.amount);
    const coreReady = result.coreReady !== undefined
      ? Boolean(result.coreReady)
      : Boolean(c.amount && c.currency && c.paymentMethod);
    byId('jpmCertificationSubmit').disabled = !ready;
    state(ready ? 'Ready for authorization' : (coreReady ? 'Core controls passed' : 'Locked'), ready
      ? `Enter the exact phrase: ${confirmationText}`
      : (coreReady
        ? 'Certification amount, currency, method, and server workflow are ready. Provider callback registration, destination, run authorization, or production enablement remains pending.'
        : 'Certification remains locked until the one-time server controls and verified callbacks are configured.'), ready || coreReady ? 'success' : '');
    return ready;
  }

  async function refreshStatus() {
    const output = byId('jpmCertificationResult');
    const result = await call('jpmorgan-certification-status', { method: 'GET' });
    const c = result.certification;
    if (!c) { output.textContent = 'No certification payment record exists for this signed-in profile.'; return; }
    const callback = c.callbackReceivedAt ? ` Callback verified at ${new Date(c.callbackReceivedAt).toLocaleString()}.` : ' Awaiting a verified provider callback.';
    output.textContent = `Status: ${c.status}. Amount: ${c.amount} ${c.currency}. Method: ${c.paymentMethod}.${callback}`;
    output.dataset.state = c.callbackReceivedAt ? 'success' : '';
  }

  byId('jpmLoadCertification')?.addEventListener('click', async (event) => {
    event.currentTarget.disabled = true;
    state('Loading…', 'Reading locked certification controls from the deployed server.');
    try { await loadConfiguration(); } catch (error) { state('Unavailable', error.message, 'error'); }
    finally { event.currentTarget.disabled = false; }
  });

  byId('jpmCertificationReconcile')?.addEventListener('click', async (event) => {
    const output = byId('jpmCertificationResult');
    event.currentTarget.disabled = true;
    output.textContent = 'Comparing the provider transaction with the SonoraPort certification ledger…';
    delete output.dataset.state;
    try {
      const result = await call('jpmorgan-certification-reconcile', { method: 'POST' });
      const r = result.reconciliation || {};
      const checks = r.checks || {};
      output.textContent = `Reconciliation: ${r.status}. Provider status: ${r.providerStatus}. Integrity: ${r.integrityPassed ? 'passed' : 'mismatch detected'}. Callback: ${r.callbackVerified ? 'verified' : 'not yet verified'}.`;
      output.dataset.state = r.settled ? 'success' : (r.integrityPassed ? '' : 'error');
      await refreshStatus();
    } catch (error) {
      output.textContent = `${error.message}${error.code ? ` (${error.code})` : ''}`;
      output.dataset.state = 'error';
    } finally { event.currentTarget.disabled = false; }
  });

  byId('jpmCertificationRefresh')?.addEventListener('click', async (event) => {
    event.currentTarget.disabled = true;
    try { await refreshStatus(); } catch (error) { byId('jpmCertificationResult').textContent = error.message; byId('jpmCertificationResult').dataset.state = 'error'; }
    finally { event.currentTarget.disabled = false; }
  });

  byId('jpmCertificationForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const output = byId('jpmCertificationResult');
    const button = byId('jpmCertificationSubmit');
    const entered = byId('jpmCertificationConfirmation').value.trim();
    if (!byId('jpmCertificationConfirmBox').checked || !confirmationText || entered !== confirmationText) {
      output.textContent = 'The checkbox and exact authorization phrase are required.';
      output.dataset.state = 'error';
      return;
    }
    button.disabled = true;
    output.textContent = 'Submitting the single controlled certification request…';
    delete output.dataset.state;
    try {
      const result = await call('jpmorgan-certification-payment', { method: 'POST', body: JSON.stringify({ confirmation: entered }) });
      const c = result.certification || {};
      output.textContent = c.duplicateBlocked
        ? `A duplicate was blocked. Existing certification status: ${c.status}.`
        : `Provider accepted the certification request. Status: ${c.status}. Refresh status after the verified callback arrives.`;
      output.dataset.state = 'success';
      await refreshStatus();
    } catch (error) {
      output.textContent = `${error.message}${error.code ? ` (${error.code})` : ''}`;
      output.dataset.state = 'error';
    } finally { button.disabled = false; }
  });
});

// Step 7 production cutover gate. This check never changes credentials or submits a payment.
document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('jpmVerifyProductionReadiness');
  const heading = document.getElementById('jpmProductionReadiness');
  const detail = document.getElementById('jpmProductionReadinessDetail');
  if (!button || !heading || !detail) return;

  const accessToken = () => {
    const session = window.LiveBackend?.getSession?.();
    return session?.session?.access_token || session?.access_token || '';
  };

  button.addEventListener('click', async () => {
    button.disabled = true;
    heading.textContent = 'Checking…';
    detail.textContent = 'Checking the production environment, credentials, callback controls, certification settlement, and reconciliation gates.';
    try {
      const headers = { Accept: 'application/json' };
      const token = accessToken();
      if (token) headers.Authorization = `Bearer ${token}`;
      const response = await fetch('/api/banking/readiness', { headers });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || `Readiness check failed (${response.status})`);
      if (result.ready) {
        heading.textContent = 'Cutover gates passed';
        heading.dataset.state = 'success';
        detail.textContent = 'Every configured production gate passed. No setting was changed and no funds were moved.';
      } else if (result.coreReady) {
        heading.textContent = 'Core controls passed';
        heading.dataset.state = 'success';
        const names = (result.blockers || []).map(jpmGateLabel);
        detail.textContent = `Application, authentication, endpoint, and product configuration gates passed. Final cutover remains pending: ${names.join(', ') || 'provider approval and signed-in certification'}. No setting was changed and no funds were moved.`;
      } else {
        heading.textContent = 'Locked';
        heading.dataset.state = 'error';
        const names = (result.blockers || []).map(jpmGateLabel);
        detail.textContent = `Remaining blockers: ${names.join(', ') || 'unknown configuration issue'}. No setting was changed.`;
      }
    } catch (error) {
      heading.textContent = 'Unavailable';
      heading.dataset.state = 'error';
      detail.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
});

// Step 8 operational health and emergency-stop gate. This check never changes server settings.
document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('jpmCheckOperationsHealth');
  const heading = document.getElementById('jpmOperationsHealth');
  const detail = document.getElementById('jpmOperationsHealthDetail');
  if (!button || !heading || !detail) return;

  const accessToken = () => {
    const session = window.LiveBackend?.getSession?.();
    return session?.session?.access_token || session?.access_token || '';
  };

  button.addEventListener('click', async () => {
    button.disabled = true;
    heading.textContent = 'Checking…';
    delete heading.dataset.state;
    detail.textContent = 'Checking server-side payment enablement, emergency stop, cutover authorization, callbacks, and provider configuration.';
    try {
      const headers = { Accept: 'application/json' };
      const token = accessToken();
      if (token) headers.Authorization = `Bearer ${token}`;
      const response = await fetch('/api/banking/health', { headers });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || `Operations check failed (${response.status})`);
      if (result.healthy && result.paymentsAllowed) {
        heading.textContent = 'Operational';
        heading.dataset.state = 'success';
        detail.textContent = `Payment operations are unlocked for ${result.environment}. Emergency stop is inactive. Checked ${new Date(result.checkedAt).toLocaleString()}.`;
      } else if (result.coreHealthy) {
        heading.textContent = 'Core controls passed';
        heading.dataset.state = 'success';
        const blockers = (result.blockers || []).map(jpmGateLabel);
        detail.textContent = `Provider connection, credentials, endpoint configuration, and emergency-stop controls passed. Final live operations remain pending: ${blockers.join(', ') || 'provider production activation and signed-in account access'}. No funds were moved.`;
      } else {
        heading.textContent = result.emergencyStop ? 'Emergency stop active' : 'Locked';
        heading.dataset.state = 'error';
        const blockers = (result.blockers || []).map(jpmGateLabel);
        detail.textContent = `Payment operations are blocked: ${blockers.join(', ') || 'health check failed'}.`;
      }
    } catch (error) {
      heading.textContent = 'Unavailable';
      heading.dataset.state = 'error';
      detail.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
});
