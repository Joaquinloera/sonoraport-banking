(()=>{
function nativeClient(){return window.supabase?.createClient('https://utnassdlhanlxbcovjmc.supabase.co','sb_publishable_aJ7UeCdanPHEbh3RlVOznA_RHf-StTA',{auth:{experimental:{passkey:true}}})}
async function register(){const sb=nativeClient();if(!sb)throw new Error('Supabase client unavailable.');const {data:session}=await sb.auth.getSession();if(!session?.session)throw new Error('Sign in before registering a passkey.');const {data,error}=await sb.auth.registerPasskey();if(error)throw error;return data}
window.TMMNativePasskey={client:nativeClient,register};
})();
