
const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>[...c.querySelectorAll(s)];
const menu=$('.menu-btn'), links=$('.links'); if(menu) menu.addEventListener('click',()=>links.classList.toggle('open'));
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12}); $$('.reveal').forEach(e=>io.observe(e));
const modal=$('#introModal'); $$('[data-modal="intro"]').forEach(b=>b.addEventListener('click',()=>modal?.classList.add('open'))); $$('.modal-close,[data-close-modal]').forEach(b=>b.addEventListener('click',()=>b.closest('.modal')?.classList.remove('open'))); document.addEventListener('keydown',e=>{if(e.key==='Escape') $$('.modal.open').forEach(m=>m.classList.remove('open'))});
const chat=$('#joshChat'), toggle=$('#chatToggle'), closeChat=$('#closeChat'), form=$('#chatForm'), input=$('#chatInput'), log=$('#chatLog');
function addBubble(text,user=false){if(!log)return;const d=document.createElement('div');d.className='bubble'+(user?' user':'');d.textContent=text;log.appendChild(d);log.scrollTop=log.scrollHeight}
if(toggle) toggle.addEventListener('click',()=>chat.classList.toggle('open')); if(closeChat) closeChat.addEventListener('click',()=>chat.classList.remove('open'));
const answers=[
[/apply|account|open/i,'I can guide you to the Application Center for personal, business, commercial, digital-asset, Visa, or Mastercard applications.'],
[/leviathan|crypto|digital asset|wallet/i,'LEVIATHAN is the digital-assets platform for cryptocurrency services, custody, tokenization, wallets, and blockchain operations.'],
[/behemoth|commercial|treasury|payment|lending/i,'BEHEMOTH is the commercial banking and treasury platform for accounts, payments, lending inquiries, and corporate financial operations.'],
[/ziz|research|forecast|intelligence/i,'ZIZ is the research and intelligence platform for analytics, forecasting, risk insights, and executive reporting.'],
[/queen|command/i,'Queen of the South is the strategic command platform connecting leadership, banking, digital assets, and intelligence.'],
[/faith|god|mission/i,'SonoraPort is a God-fearing, family-led organization grounded in faith, integrity, stewardship, innovation, and service.'],
[/leadership|ceo|president|coo|jeffery|christopher/i,'The Leadership page contains the complete approved executive and division leadership structure.'],
];
if(form) form.addEventListener('submit',async e=>{e.preventDefault();const q=input.value.trim();if(!q)return;addBubble(q,true);input.value='';let reply=answers.find(([r])=>r.test(q))?.[1]||'I can help you navigate the banking platforms, applications, leadership, mission, and parent-company website.';try{const r=await fetch('/api/assistant',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:q})});if(r.ok){const j=await r.json();if(j.reply)reply=j.reply}}catch{}setTimeout(()=>addBubble(reply),250)});
$$('[data-application]').forEach(card=>card.addEventListener('click',()=>{const type=card.dataset.application;location.href='apply.html?type='+encodeURIComponent(type)}));
const params=new URLSearchParams(location.search); const appType=$('#applicationType'); if(appType&&params.get('type')) appType.value=params.get('type');

// Guided banking application
const applicationForm=document.querySelector('#bankingApplication');
if(applicationForm){
  const choices=[...document.querySelectorAll('.application-choice')];
  const typeInput=document.querySelector('#applicationType');
  const referenceInput=document.querySelector('#applicationReference');
  const referenceDisplay=document.querySelector('#referenceDisplay');
  const heading=document.querySelector('#applicationHeading');
  const intro=document.querySelector('#applicationIntro');
  const placeholder=document.querySelector('#applicationPlaceholder');
  const steps=[...document.querySelectorAll('.form-step')];
  const actions=document.querySelector('#formActions');
  const prev=document.querySelector('#previousStep');
  const next=document.querySelector('#nextStep');
  const submit=document.querySelector('#submitApplication');
  const stepLabel=document.querySelector('#stepLabel');
  const progress=document.querySelector('#progressBar');
  const feedback=document.querySelector('#formFeedback');
  const review=document.querySelector('#applicationReview');
  let current=0;

  const names={
    checking:'Checking Account', savings:'Savings Account', 'personal-loan':'Personal Loan',
    business:'Business Banking', 'business-loan':'Business Loan', commercial:'Commercial Banking',
    'commercial-loan':'Commercial Loan', crypto:'Cryptocurrency Account',
    'visa-credit':'Visa Credit Card', 'mastercard-credit':'Mastercard Credit Card',
    'business-credit':'Business Credit Card', 'digital-assets':'Institutional Digital Assets'
  };

  const aliases={
    personal:'checking', visa:'visa-credit', mastercard:'mastercard-credit',
    behemoth:'commercial', leviathan:'crypto', ziz:'checking', 'queen-of-the-south':'commercial'
  };

  function makeReference(type){
    const stamp=new Date().toISOString().slice(0,10).replaceAll('-','');
    const random=Math.floor(100000+Math.random()*900000);
    return `SP-${type.toUpperCase().replaceAll('-','').slice(0,5)}-${stamp}-${random}`;
  }

  function setRequired(selector,required){
    document.querySelectorAll(selector).forEach(el=>{el.required=required});
  }

  function setType(rawType,scroll=true){
    const type=aliases[rawType]||rawType;
    if(!names[type]) return;
    typeInput.value=type;
    if(!referenceInput.value){
      referenceInput.value=makeReference(type);
      referenceDisplay.textContent=referenceInput.value;
    }
    choices.forEach(c=>c.classList.toggle('selected',c.dataset.application===type));
    heading.textContent=names[type]+' Application';
    intro.textContent='Complete all five steps, review your information, and submit your '+names[type]+' application.';
    placeholder.hidden=true;
    actions.hidden=false;
    applicationForm.className=applicationForm.className.replace(/\btype-[^\s]+/g,'').trim();
    applicationForm.classList.add('type-'+type);

    setRequired('.personal-fields select, .personal-fields input',false);
    setRequired('.business-fields select, .business-fields input',false);
    setRequired('.commercial-only select, .commercial-only input',false);
    setRequired('.digital-fields select, .digital-fields input',false);
    setRequired('.card-fields select, .card-fields input',false);
    setRequired('.checking-fields select, .checking-fields input',false);
    setRequired('.savings-fields select, .savings-fields input',false);
    setRequired('.loan-fields select, .loan-fields input, .loan-fields textarea',false);
    setRequired('.credit-fields select, .credit-fields input',false);
    setRequired('.business-credit-fields select, .business-credit-fields input',false);
    if(type==='checking'){setRequired('#personalAccount,#checkingStyle',true);}
    if(type==='savings'){setRequired('#personalAccount,#savingsGoal,#openingDeposit',true);}
    if(type==='personal-loan'){setRequired('#loanAmount,#loanPurpose,#loanTerm,#monthlyDebt',true);}
    if(type==='business'||type==='commercial'||type==='business-loan'||type==='commercial-loan'||type==='business-credit') setRequired('#legalBusinessName,#businessType,#businessIndustry,#annualRevenue',true);
    if(type==='commercial') setRequired('#treasuryServices',true);
    if(type==='business-loan'||type==='commercial-loan') setRequired('#loanAmount,#loanPurpose,#loanTerm,#monthlyDebt',true);
    if(type==='crypto'||type==='digital-assets') setRequired('#digitalService,#digitalExperience',true);
    if(type==='visa-credit'||type==='mastercard-credit'||type==='business-credit') setRequired('#cardRelationship,#cardTier,#cardUse,#creditLimit',true);
    if(type==='business-credit') setRequired('#monthlyCardSpend,#businessCardUsers',true);

    showStep(0);
    if(scroll) document.querySelector('#application-form').scrollIntoView({behavior:'smooth',block:'start'});
  }

  function visibleFields(step){
    return [...step.querySelectorAll('input,select,textarea')].filter(el=>!el.disabled && el.offsetParent!==null);
  }

  function validateStep(){
    feedback.textContent='';
    for(const field of visibleFields(steps[current])){
      if(!field.checkValidity()){
        field.reportValidity();
        feedback.textContent='Please complete every required field before continuing.';
        return false;
      }
    }
    return true;
  }

  function formatLabel(name){
    return name.replaceAll('_',' ').replace(/\b\w/g,m=>m.toUpperCase());
  }

  function buildReview(){
    review.innerHTML='';
    const data=new FormData(applicationForm);
    const excluded=new Set(['form-name','bot-field','electronic_signature','accuracy_consent','electronic_consent','verification_consent','terms_consent']);
    for(const [key,value] of data.entries()){
      if(excluded.has(key)||!String(value).trim()) continue;
      const item=document.createElement('div');
      item.className='review-item';
      const small=document.createElement('small');
      const strong=document.createElement('strong');
      small.textContent=formatLabel(key);
      strong.textContent=key==='application_type'?(names[value]||value):value;
      item.append(small,strong);
      review.appendChild(item);
    }
  }

  function showStep(index){
    current=Math.max(0,Math.min(index,steps.length-1));
    steps.forEach((step,i)=>step.classList.toggle('active',i===current));
    prev.hidden=current===0;
    next.hidden=current===steps.length-1;
    submit.hidden=current!==steps.length-1;
    stepLabel.textContent=`Step ${current+1} of ${steps.length}`;
    progress.style.width=((current+1)/steps.length*100)+'%';
    feedback.textContent='';
    if(current===steps.length-1) buildReview();
    document.querySelector('#application-form').scrollIntoView({behavior:'smooth',block:'start'});
  }

  choices.forEach(card=>card.addEventListener('click',()=>setType(card.dataset.application,true)));
  next.addEventListener('click',()=>{
    if(!typeInput.value){
      feedback.textContent='Choose an application type above first.';
      document.querySelector('#application-options').scrollIntoView({behavior:'smooth'});
      return;
    }
    if(validateStep()) showStep(current+1);
  });
  prev.addEventListener('click',()=>showStep(current-1));
  applicationForm.addEventListener('submit',async e=>{
    e.preventDefault();
    if(!typeInput.value){
      feedback.textContent='Choose an application type before submitting.';
      document.querySelector('#application-options').scrollIntoView({behavior:'smooth'});
      return;
    }
    if(current!==steps.length-1){
      feedback.textContent='Complete all five application steps before submitting.';
      return;
    }
    if(!validateStep()) return;

    submit.disabled=true;
    submit.textContent='Submitting…';
    const ref=referenceInput.value||makeReference(typeInput.value||'application');
    referenceInput.value=ref;
    const data=new FormData(applicationForm);
    const names={checking:'Checking Account',savings:'Savings Account','personal-loan':'Personal Loan',business:'Business Banking','business-loan':'Business Loan',commercial:'Commercial Banking','commercial-loan':'Commercial Loan',crypto:'Cryptocurrency Account','visa-credit':'Visa Credit Card','mastercard-credit':'Mastercard Credit Card','business-credit':'Business Credit Card','digital-assets':'Institutional Digital Assets'};
    const record={reference:String(ref),type:String(typeInput.value),product:names[typeInput.value]||String(typeInput.value),email:String(data.get('email')||''),name:[data.get('first_name'),data.get('last_name')].filter(Boolean).join(' '),submitted:new Date().toISOString(),status:'submitted'};

    try{
      if(!window.supabase) throw new Error('The secure database service did not load. Please refresh and try again.');
      const sb=window.supabase.createClient(
        'https://utnassdlhanlxbcovjmc.supabase.co',
        'sb_publishable_aJ7UeCdanPHEbh3RlVOznA_RHf-StTA',
        {auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}
      );
      const {data:sessionData,error:sessionError}=await sb.auth.getSession();
      if(sessionError) throw sessionError;
      const signedInUser=sessionData.session?.user;
      if(!signedInUser) throw new Error('Your secure session expired. Sign in again, then return to the application.');

      const {error:insertError}=await sb.from('applications').insert({
        profile_id:signedInUser.id,
        title:record.product,
        reference:record.reference,
        status:'submitted'
      });
      if(insertError) throw insertError;

      try{
        const prior=JSON.parse(localStorage.getItem('sonoraportApplications')||'[]');
        if(!prior.some(x=>x.reference===record.reference)) prior.unshift(record);
        localStorage.setItem('sonoraportApplications',JSON.stringify(prior.slice(0,50)));
      }catch{}
      window.location.assign('application-received.html?ref='+encodeURIComponent(ref));
    }catch(error){
      console.error('Application submission failed',error);
      feedback.textContent=String(error?.message||'The application could not be saved. Please try again.');
      submit.disabled=false;
      submit.textContent='Submit Application';
    }
  });

  const requested=new URLSearchParams(location.search).get('type');
  if(requested) setType(requested,false);
  else{
    steps.forEach(step=>step.classList.remove('active'));
    progress.style.width='0%';
    stepLabel.textContent='Choose an application';
  }
}


// Application confirmation barcode (Code 39)
(function(){
  const target=document.querySelector('#dynamicBarcode');
  const label=document.querySelector('#confirmationReference');
  if(!target||!label) return;
  const ref=new URLSearchParams(location.search).get('ref')||'SP-APPLICATION-RECEIVED';
  label.textContent=ref;
  const patterns={
    '0':'nnnwwnwnn','1':'wnnwnnnnw','2':'nnwwnnnnw','3':'wnwwnnnnn','4':'nnnwwnnnw','5':'wnnwwnnnn','6':'nnwwwnnnn','7':'nnnwnnwnw','8':'wnnwnnwnn','9':'nnwwnnwnn',
    'A':'wnnnnwnnw','B':'nnwnnwnnw','C':'wnwnnwnnn','D':'nnnnwwnnw','E':'wnnnwwnnn','F':'nnwnwwnnn','G':'nnnnnwwnw','H':'wnnnnwwnn','I':'nnwnnwwnn','J':'nnnnwwwnn',
    'K':'wnnnnnnww','L':'nnwnnnnww','M':'wnwnnnnwn','N':'nnnnwnnww','O':'wnnnwnnwn','P':'nnwnwnnwn','Q':'nnnnnnwww','R':'wnnnnnwwn','S':'nnwnnnwwn','T':'nnnnwnwwn',
    'U':'wwnnnnnnw','V':'nwwnnnnnw','W':'wwwnnnnnn','X':'nwnnwnnnw','Y':'wwnnwnnnn','Z':'nwwnwnnnn','-':'nwnnnnwnw','.':'wwnnnnwnn',' ':'nwwnnnwnn','*':'nwnnwnwnn'};
  const safe=('*'+ref.toUpperCase().replace(/[^0-9A-Z. -]/g,'-')+'*');
  let html='',black=true;
  for(const ch of safe){
    const pattern=patterns[ch]||patterns['-'];
    for(const unit of pattern){
      const width=unit==='w'?5:2;
      html+=`<span style="width:${width}px;${black?'background:#111':''}"></span>`;
      black=!black;
    }
    html+='<span style="width:2px"></span>'; black=true;
  }
  target.innerHTML='<div class="barcode-bars">'+html+'</div><small>'+ref+'</small>';
})();


