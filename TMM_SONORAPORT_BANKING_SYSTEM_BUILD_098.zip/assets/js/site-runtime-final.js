(()=>{
  "use strict";
  document.documentElement.dataset.spBuild="20260730-auth-access-v1";


  // Global secure-access navigation. This is injected on every page so login is never hidden.
  const authPages=new Set(["sign-in.html","create-account.html","forgot-password.html","reset-password.html","client-portal.html","client-login.html"]);
  const currentPage=(location.pathname.split("/").pop()||"index.html").toLowerCase();
  if(!document.querySelector(".sp-auth-access-bar")){
    const bar=document.createElement("nav");
    bar.className="sp-auth-access-bar";
    bar.setAttribute("aria-label","Secure client access");
    const returnTo=encodeURIComponent((location.pathname.split("/").pop()||"index.html")+location.search+location.hash);
    bar.innerHTML=`<span>SECURE CLIENT ACCESS</span><a href="sign-in.html?next=${returnTo}">Client Login</a><a href="create-account.html">Create Account</a><a href="client-portal.html">Client Portal</a>`;
    document.body.prepend(bar);
  }

  // Correct older links that labeled the portal itself as the login destination.
  document.querySelectorAll('a[href="client-portal.html"]').forEach(a=>{
    const label=(a.textContent||"").trim().toLowerCase();
    if(label.includes("login")||label.includes("sign in")||label.includes("signin")) a.href="sign-in.html";
    else if(!authPages.has(currentPage)) a.href="sign-in.html?next=%2Fclient-portal.html&reauth=1";
  });

  document.querySelectorAll("button:not([type])").forEach(b=>b.type=b.closest("form")?"submit":"button");
  document.querySelectorAll("button, a").forEach(el=>el.style.touchAction="manipulation");

  document.querySelectorAll("[data-application]").forEach(el=>{
    if(el.tagName==="A" && el.getAttribute("href")) return;
    el.setAttribute("role","link"); el.tabIndex=0;
    const go=()=>{const t=el.dataset.application;if(t) location.href="apply.html?type="+encodeURIComponent(t)};
    el.addEventListener("click",go);
    el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();go()}});
  });

  // Home JoshGPT panel
  const panel=document.getElementById("joshPanel");
  const messages=document.getElementById("joshMessages");
  const input=document.getElementById("joshInput");
  const openHome=()=>{panel?.classList.add("open");document.documentElement.classList.add("josh-open");document.body.classList.add("josh-open");syncJoshViewport();setTimeout(()=>input?.focus(),80)};
  document.getElementById("joshLaunch")?.addEventListener("click",openHome);
  document.getElementById("askJoshTop")?.addEventListener("click",openHome);
  const closeHome=()=>{panel?.classList.remove("open");document.documentElement.classList.remove("josh-open");document.body.classList.remove("josh-open");input?.blur()};
  document.getElementById("joshClose")?.addEventListener("click",closeHome);
  const answer=q=>{
    const x=q.toLowerCase();
    if(x.includes("personal")) return "Open the Personal Application from the Application Center.";
    if(x.includes("business")) return "Business Banking includes accounts, business loans, commercial lending, and document submission.";
    if(x.includes("crypto")||x.includes("digital")) return "Open Digital Assets for cryptocurrency research and account applications.";
    if(x.includes("gold")||x.includes("metal")||x.includes("silver")) return "Open the Gold, Silver, or Precious Metals center for market information.";
    if(x.includes("login")||x.includes("portal")) return "Use Client Portal for applications, account activity, cards, and status tracking.";
    return "I can guide you to banking, cards, loans, digital assets, precious metals, partners, licenses, or the client portal.";
  };
  let joshBusy=false;
  const JOSH_HISTORY_KEY="sonoraport_josh_history_v1";
  const loadJoshHistory=()=>{try{const saved=JSON.parse(sessionStorage.getItem(JOSH_HISTORY_KEY)||"[]");return Array.isArray(saved)?saved.slice(-10):[]}catch{return []}};
  const joshHistory=loadJoshHistory();
  const saveJoshHistory=()=>{try{sessionStorage.setItem(JOSH_HISTORY_KEY,JSON.stringify(joshHistory.slice(-10)))}catch{}};
  const syncJoshViewport=()=>{
    if(!panel||!window.visualViewport)return;
    const h=Math.max(320,Math.floor(window.visualViewport.height-16));
    panel.style.setProperty('--josh-vh',h+'px');
  };
  window.visualViewport?.addEventListener('resize',syncJoshViewport);
  window.visualViewport?.addEventListener('scroll',syncJoshViewport);
  const appendJosh=(text,kind="bot")=>{
    if(!messages)return null;
    const p=document.createElement("p"); p.className=kind==="user"?"josh-user":"josh-bot"; p.textContent=text;
    messages.append(p); messages.scrollTop=messages.scrollHeight; return p;
  };
  if(messages&&joshHistory.length){
    messages.innerHTML="";
    joshHistory.forEach(item=>appendJosh(item.text,item.role==="user"?"user":"bot"));
  }
  const sendHome=async q=>{
    q=(q||"").trim();
    if(!q||!messages||joshBusy)return;
    appendJosh(q,"user");
    joshHistory.push({role:'user',text:q});
    if(joshHistory.length>10)joshHistory.splice(0,joshHistory.length-10);
    saveJoshHistory();
    const pending=appendJosh("JoshGPT is thinking…","bot");
    joshBusy=true;
    const submit=document.querySelector("#joshForm button[type=submit]");
    if(submit){submit.disabled=true;submit.textContent="Wait"}
    try{
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),28000);
      let response;
      try{response=await fetch("/api/assistant",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:q,history:joshHistory.slice(0,-1)}),signal:controller.signal})}
      finally{clearTimeout(timer)}
      const data=await response.json().catch(()=>({}));
      if(!response.ok) throw new Error(data.error||"JoshGPT is temporarily unavailable.");
      const reply=data.reply||answer(q);
      if(pending) pending.textContent=reply;
      joshHistory.push({role:'assistant',text:reply});
      if(joshHistory.length>10)joshHistory.splice(0,joshHistory.length-10);
      saveJoshHistory();
    }catch(error){
      const msg=(error?.message||"JoshGPT is temporarily unavailable.");
      if(pending) pending.textContent=msg+" Tap Send to retry or use a quick option below.";
    }finally{
      joshBusy=false;
      if(submit){submit.disabled=false;submit.textContent="Send"}
      messages.scrollTop=messages.scrollHeight;
    }
  };
  document.getElementById("joshForm")?.addEventListener("submit",e=>{e.preventDefault();const q=input?.value||"";if(input)input.value="";sendHome(q)});
  document.querySelectorAll(".josh-prompts button").forEach(b=>b.addEventListener("click",()=>{openHome();sendHome(b.textContent||"")}));

  // Legacy Josh assistant shown on informational pages
  const legacy=document.getElementById("joshChat");
  document.getElementById("chatToggle")?.addEventListener("click",()=>legacy?.classList.add("open"));
  document.getElementById("closeChat")?.addEventListener("click",()=>legacy?.classList.remove("open"));
  const legacyInput=document.getElementById("chatInput");
  const legacyLog=document.getElementById("chatLog");
  document.getElementById("chatForm")?.addEventListener("submit",async e=>{
    e.preventDefault(); const q=(legacyInput?.value||"").trim(); if(!q||!legacyLog||joshBusy)return;
    const u=document.createElement("div");u.className="bubble user";u.textContent=q;
    const a=document.createElement("div");a.className="bubble";a.textContent="JoshGPT is thinking…";
    legacyLog.append(u,a); if(legacyInput)legacyInput.value=""; legacyLog.scrollTop=legacyLog.scrollHeight;
    joshBusy=true;
    try{
      const response=await fetch("/api/assistant",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:q,history:joshHistory.slice(-8)})});
      const data=await response.json().catch(()=>({}));
      if(!response.ok)throw new Error(data.error||"JoshGPT is temporarily unavailable.");
      a.textContent=data.reply||answer(q);
    }catch(error){a.textContent=error?.message||"JoshGPT is temporarily unavailable."}
    finally{joshBusy=false;legacyLog.scrollTop=legacyLog.scrollHeight}
  });
  document.querySelectorAll("#introModal .modal-close").forEach(b=>b.addEventListener("click",()=>document.getElementById("introModal")?.classList.remove("open")));

  document.addEventListener("click",e=>{
    const a=e.target.closest("a[href]"); if(!a)return;
    const h=a.getAttribute("href"); if(!h||h==="#")e.preventDefault();
  });
  document.addEventListener("click",e=>{if(panel?.classList.contains("open")&&!panel.contains(e.target)&&!e.target.closest("#joshLaunch,#askJoshTop")) closeHome()});
  document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeHome();legacy?.classList.remove("open");document.getElementById("introModal")?.classList.remove("open")}});
})();


/* Always-visible institutional and market access bar */
(() => {
  const start = () => {
    if (document.querySelector('.sp-restored-access')) return;
    const current = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    const links = [
      ['partners.html', 'Partnerships'],
      ['blackrock.html', 'BlackRock'],
      ['jpmorgan.html', 'J.P. Morgan'],
      ['bloomberg.html', 'Bloomberg'],
      ['gold.html', 'Gold'],
      ['silver.html', 'Silver'],
      ['licenses.html', 'Licenses'],
      ['charter.html', 'Charter']
    ];
    const bar = document.createElement('nav');
    bar.className = 'sp-restored-access';
    bar.setAttribute('aria-label', 'Institutional and market access');
    bar.innerHTML = links.map(([href, label]) =>
      `<a href="${href}"${current === href ? ' aria-current="page"' : ''}>${label}</a>`
    ).join('');
    const first = document.body.firstElementChild;
    if (first) document.body.insertBefore(bar, first); else document.body.appendChild(bar);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();


// Functional same-page navigation — 2026-07-30
(function(){
  document.addEventListener('click', function(event){
    var link = event.target.closest('a[href^="#"]');
    if (!link) return;
    var href = link.getAttribute('href');
    if (!href || href === '#') return;
    var target;
    try { target = document.querySelector(href); } catch (_) { return; }
    if (!target) return;
    event.preventDefault();
    var menu = link.closest('details');
    if (menu) menu.removeAttribute('open');
    target.scrollIntoView({behavior:'smooth',block:'start'});
    target.classList.remove('sp-anchor-flash');
    void target.offsetWidth;
    target.classList.add('sp-anchor-flash');
    window.setTimeout(function(){ target.classList.remove('sp-anchor-flash'); }, 1100);
    if (history && history.replaceState) history.replaceState(null,'',href);
  });
})();
