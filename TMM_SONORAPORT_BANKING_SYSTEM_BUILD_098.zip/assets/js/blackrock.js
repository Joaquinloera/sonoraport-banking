(async () => {
  const q = (id) => document.getElementById(id);
  try {
    const r = await fetch('/api/integrations/blackrock/status');
    const s = await r.json();
    q('brRelationship').textContent = s.relationshipStatus;
    q('brEnvironment').textContent = s.environment;
    q('brEnabled').textContent = s.enabled && s.configured ? 'Configured' : 'Locked';
    q('brProduct').textContent = s.product;
  } catch {
    q('brEnabled').textContent = 'Unavailable';
  }
})();
