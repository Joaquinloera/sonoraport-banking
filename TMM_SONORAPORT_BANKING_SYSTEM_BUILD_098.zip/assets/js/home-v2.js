(()=>{
  const menu=document.querySelector('.v2-menu');
  const nav=document.querySelector('.v2-nav');
  menu?.addEventListener('click',()=>nav.classList.toggle('open'));
  nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));

  const panel=document.getElementById('joshPanel');
  const launch=document.getElementById('joshLaunch');
  const top=document.getElementById('askJoshTop');
  const close=document.getElementById('joshClose');
  const form=document.getElementById('joshForm');
  const input=document.getElementById('joshInput');
  const messages=document.getElementById('joshMessages');
  const open=()=>panel?.classList.add('open');
  launch?.addEventListener('click',open); top?.addEventListener('click',open); close?.addEventListener('click',()=>panel.classList.remove('open'));
  const answer=q=>{
    const x=q.toLowerCase();
    if(x.includes('personal')) return 'Open the Personal Application from the Application Center. You can save progress and continue through the client portal.';
    if(x.includes('business')) return 'Business Banking includes account requests, business loans, commercial lending, treasury workflows, and document submission.';
    if(x.includes('crypto')||x.includes('digital')) return 'The Digital Asset section provides crypto education, market-watch tools, portfolio organization, and a digital-asset interest application.';
    if(x.includes('gold')||x.includes('metal')||x.includes('silver')) return 'The Precious Metals center covers gold, silver, platinum, and palladium research, portfolio tracking, and future provider integrations.';
    if(x.includes('login')||x.includes('portal')) return 'Use Client Login to access applications, private documents, messages, notifications, and JoshGPT guidance.';
    return 'I can guide you to personal banking, business banking, loans, credit cards, cryptocurrency, precious metals, security, or the client portal.';
  };
  const send=q=>{if(!q.trim())return;messages.insertAdjacentHTML('beforeend',`<p class="josh-user"></p><p class="josh-bot"></p>`);const ps=messages.querySelectorAll('p');ps[ps.length-2].textContent=q;ps[ps.length-1].textContent=answer(q);messages.scrollTop=messages.scrollHeight;};
  form?.addEventListener('submit',e=>{e.preventDefault();send(input.value);input.value='';});
  document.querySelectorAll('.josh-prompts button').forEach(b=>b.addEventListener('click',()=>{open();send(b.textContent)}));
})();
