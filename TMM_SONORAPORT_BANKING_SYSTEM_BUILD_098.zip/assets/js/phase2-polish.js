(() => {
  'use strict';
  const current = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  document.querySelectorAll('nav a, .desktop-nav a, .links a, .v2-nav a, .mobile-menu a').forEach((a) => {
    const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].toLowerCase();
    if (href && !href.startsWith('http') && href === current) {
      a.classList.add('active');
      a.setAttribute('aria-current', 'page');
    }
  });

  const targets = document.querySelectorAll('main section, .card, .service-card, .intelligence-card, .form-shell, .cta');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('sp-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px' });
    targets.forEach((el) => { el.classList.add('sp-reveal'); observer.observe(el); });
  }

  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', () => {
      const nav = document.querySelector('.v2-nav.open, .links.open, .mobile-menu.open');
      if (nav) nav.classList.remove('open');
    });
  });
})();
