(() => {
  'use strict';

  const all = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function findMenu(button) {
    const header = button.closest('header, nav.nav, .site-header') || document;
    if (button.classList.contains('v2-menu')) {
      return header.querySelector('.v2-nav') || document.querySelector('.v2-nav');
    }
    return header.querySelector('.mobile-menu, .links') || document.querySelector('.mobile-menu, .links');
  }

  function setMenu(button, menu, open) {
    if (!button || !menu) return;
    const header = button.closest('header, .site-header, .v2-header, .nav') || document.querySelector('header');
    const top = header ? Math.max(0, Math.round(header.getBoundingClientRect().bottom)) : 86;
    document.documentElement.style.setProperty('--sp-menu-top', `${top}px`);
    menu.classList.toggle('open', open);
    menu.hidden = false;
    menu.setAttribute('aria-hidden', String(!open));
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    document.body.classList.toggle('menu-open', open);
  }

  function closeAll(except = null) {
    all('.v2-nav.open, .mobile-menu.open, .links.open').forEach((menu) => {
      if (menu === except) return;
      const scope = menu.closest('header, nav.nav, .site-header') || document;
      const button = scope.querySelector('.v2-menu, .menu-btn');
      setMenu(button, menu, false);
    });
  }

  function initializeMenus() {
    all('button.v2-menu, button.menu-btn').forEach((oldButton, index) => {
      // Cloning removes conflicting legacy click listeners already attached by older scripts.
      const button = oldButton.cloneNode(true);
      oldButton.replaceWith(button);
      const menu = findMenu(button);
      if (!menu) return;

      const menuId = menu.id || `site-menu-${index + 1}`;
      menu.id = menuId;
      button.setAttribute('aria-controls', menuId);
      button.setAttribute('aria-expanded', 'false');
      menu.setAttribute('aria-hidden', 'true');

      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const opening = !menu.classList.contains('open');
        closeAll(menu);
        setMenu(button, menu, opening);
      });
    });

    document.addEventListener('click', (event) => {
      const openMenu = event.target.closest('.v2-nav.open, .mobile-menu.open, .links.open');
      if (openMenu && event.target.closest('a')) {
        const scope = openMenu.closest('header, nav.nav, .site-header') || document;
        setMenu(scope.querySelector('.v2-menu, .menu-btn'), openMenu, false);
        return;
      }
      if (!openMenu && !event.target.closest('.v2-menu, .menu-btn')) closeAll();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeAll();
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 1050) closeAll();
    });
  }

  function initializeInteractions() {
    all('button').forEach((button) => {
      if (!button.type) button.type = button.closest('form') ? 'submit' : 'button';
      button.style.touchAction = 'manipulation';
    });

    all('a[href^="#"]:not([href="#"])').forEach((link) => {
      link.addEventListener('click', (event) => {
        const target = document.querySelector(link.getAttribute('href'));
        if (!target) return;
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        history.replaceState(null, '', link.getAttribute('href'));
      });
    });

    const homePanel = document.querySelector('#joshPanel');
    all('#joshLaunch, #askJoshTop').forEach((button) => button.addEventListener('click', () => homePanel?.classList.add('open')));
    document.querySelector('#joshClose')?.addEventListener('click', () => homePanel?.classList.remove('open'));

    const legacyChat = document.querySelector('#joshChat');
    document.querySelector('#chatToggle')?.addEventListener('click', () => legacyChat?.classList.add('open'));
    document.querySelector('#closeChat')?.addEventListener('click', () => legacyChat?.classList.remove('open'));
  }

  function start() {
    initializeMenus();
    initializeInteractions();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();

/* Unified banking + markets system bar */
(()=>{const pages=['banking.html','cards.html','stocks.html','bloomberg.html','blackrock.html','jpmorgan.html','precious-metals.html','gold.html','tokenized-assets.html','cryptocurrency-account.html','bitcoin-research.html','ethereum-research.html'];const current=location.pathname.split('/').pop()||'index.html';if(!pages.includes(current)||document.querySelector('.sp-system-bar'))return;const style=document.createElement('style');style.textContent='.sp-system-bar{position:relative;z-index:15;display:flex;justify-content:center;gap:8px;flex-wrap:wrap;padding:9px 12px;background:#05080d;border-bottom:1px solid #4b402b}.sp-system-bar a{color:#ead39a;text-decoration:none;border:1px solid #5d4d2c;padding:7px 10px;font:700 10px Arial;letter-spacing:.08em}.sp-system-bar a:hover{background:#c8a052;color:#080a0d}';document.head.appendChild(style);const bar=document.createElement('div');bar.className='sp-system-bar';bar.innerHTML='<a href="client-portal.html">ACCOUNT DASHBOARD</a><a href="banking.html">BANKING</a><a href="cards.html">CARDS</a><a href="stocks.html">MARKETS</a><a href="apply.html">APPLICATIONS</a><a href="verify.html">STATUS</a>';document.body.prepend(bar)})();
