# Step 20 — Production Monitoring and Incident Response

Install `supabase/SONORAPORT-JPMORGAN-STEP20-MONITORING-INCIDENTS.sql` after Step 19.

Netlify variables:

- `JPMORGAN_AUTO_OPEN_INCIDENTS=true`
- `JPMORGAN_REQUIRE_OPERATOR_SECURE_SESSION=true` after operator MFA/session enrollment is complete.

Endpoints:

- `POST /.netlify/functions/jpmorgan-monitoring` — records a health snapshot and opens an incident when a required gate fails.
- `GET /.netlify/functions/jpmorgan-incident-admin` — lists incidents for authorized operations staff.
- `PATCH /.netlify/functions/jpmorgan-incident-admin` — moves an incident to investigating, contained, or resolved.

This step records and controls incidents. It does not replace external uptime monitoring or provider-issued production alerts.
