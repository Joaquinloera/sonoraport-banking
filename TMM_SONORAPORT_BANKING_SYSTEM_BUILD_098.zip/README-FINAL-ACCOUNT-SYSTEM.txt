SONORAPORT AI BANKING — FINAL CONNECTED BUILD

Included:
- Supabase email/password sign-in, account creation, recovery, and sign-out
- Unified client dashboard
- Accounts and balance display
- Transaction history
- Transfer request workflow
- Card request workflow
- Application submission and status tracking
- Connected banking, cards, and market navigation
- Local fallback when the new database tables have not been installed

REQUIRED BACKEND STEP:
Run supabase/SONORAPORT-ACCOUNT-SYSTEM.sql in the existing Supabase SQL Editor.
The website will use local fallback storage until those tables and RLS policies exist.

IMPORTANT:
This build does not create real bank balances, issue cards, or move money by itself.
Those functions require an authorized banking/payment provider, server-side transaction processing, compliance controls, and production credentials.
