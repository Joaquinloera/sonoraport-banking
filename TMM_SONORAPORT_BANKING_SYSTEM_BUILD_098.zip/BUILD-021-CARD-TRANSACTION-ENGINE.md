# Build 021 — Card transaction lifecycle

Adds a provider-confirmed, signed webhook ingestion boundary for authorization, decline, capture, clearing, reversal, and refund events. Events are idempotent on provider + provider event ID. PAN/CVV are not accepted or stored by this endpoint. Ledger mutation remains separated from webhook ingestion until a provider event is reconciled against an owned provider card/account.

Required runtime configuration: CARD_ISSUER_WEBHOOK_SECRET, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY. Apply SONORAPORT-V24-CARD-TRANSACTION-LIFECYCLE.sql before enabling the webhook.
