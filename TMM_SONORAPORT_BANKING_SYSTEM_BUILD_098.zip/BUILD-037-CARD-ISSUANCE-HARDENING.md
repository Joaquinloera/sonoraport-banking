# Build 037 — Card Issuance Hardening

- Hardened Card Center so activation is only offered after an issuer-backed card record exists.
- Pending card requests remain visibly pending instead of exposing an activation action prematurely.
- Existing issuer-backed activation and lock/unlock flows remain unchanged.
- Preserved Build 036 customer portal, payment/card brand rail, tabs, and banking routes.
- Cache-bumped customer portal assets to Build 037.
