# BUILD 089 — J.P. Morgan certification schema fix

- Fixes the production-cutover blocker caused by missing `public.jpmorgan_payment_certifications`.
- STEP5 migration now references the deployed `public.money_provider_account_links(id)` table.
- STEP6 reconciliation fields remain included.
- Live connected Supabase project was migrated and verified during this build.
