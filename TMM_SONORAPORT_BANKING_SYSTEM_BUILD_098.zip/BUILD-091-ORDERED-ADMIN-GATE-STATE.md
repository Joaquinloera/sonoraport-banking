# BUILD 091 — Ordered Admin Gate State

Refresh runs status, auth, account, payment, callback, cutover, and operations in order instead of racing them in parallel. Admin automatically reconstructs the gate cards after load.
