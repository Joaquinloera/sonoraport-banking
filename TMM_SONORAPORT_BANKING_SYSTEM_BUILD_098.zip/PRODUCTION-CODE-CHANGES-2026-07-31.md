# SonoraPort production code changes

This package changes code only. It does not alter the currently deployed Netlify site.

## Josh / Codex backend
- Replaced the one-line `josh.js` function with structured `josh.mjs`.
- Added correlation IDs, request timeouts, safe JSON responses, input limits, origin checks, configurable model and output-token settings, and useful server configuration errors.
- Prevents the assistant from requesting or exposing banking secrets and from claiming unconfirmed payment success.

Environment variables:
- `OPENAI_API_KEY`
- `OPENAI_MODEL` (optional; default `gpt-4.1-mini`)
- `OPENAI_MAX_OUTPUT_TOKENS` (optional; default `500`)
- `SITE_URL` or Netlify-provided `URL`

## JPMorgan payment backend
- Added an explicit Node crypto import for payment idempotency IDs.
- Added server-side maximum payment limits.
- Added currency and payment-method allowlists.

Environment variables:
- `JPMORGAN_MAX_PAYMENT_AMOUNT` (optional; default `100000`)
- `JPMORGAN_ALLOWED_CURRENCIES` (optional; default `USD`)
- `JPMORGAN_ALLOWED_PAYMENT_METHODS` (optional; default `ACH,WIRE`)

These controls are enforced on the server and cannot be bypassed by editing browser HTML.

## Step 10 — Audit Logging
- Added tamper-evident JPMorgan audit event chain.
- Added service-role-only Supabase audit table.
- Added authenticated compliance-admin JSON export endpoint.
- Added audit events for risk blocks, approval holds, provider submissions, controlled certification, and verified callbacks.

## Step 11 — Ledger integrity
- Added atomic ownership, balance freshness, available-funds, and duplicate-reservation checks.
- Added payment holds and double-entry journals before provider submission.
- Added automatic hold release when provider submission fails.

## Step 13 — Statements, reconciliation, and disputes
- Added monthly customer statements in JSON and downloadable CSV.
- Added customer-owned dispute submission and status retrieval.
- Added administrator-only provider-to-ledger reconciliation reports.
- Added report hashes and tamper-evident audit events.
- Added Supabase RLS policies for customer dispute records.
