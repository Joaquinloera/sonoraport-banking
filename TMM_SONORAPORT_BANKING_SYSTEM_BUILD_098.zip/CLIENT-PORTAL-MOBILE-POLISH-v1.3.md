# Client Portal Mobile Polish v1.3

Only the Client Portal presentation was changed.

- Styled the injected secure-access links so they no longer appear as raw purple browser links.
- Improved mobile header wrapping and Sign Out alignment.
- Improved tab scrolling and touch behavior.
- Prevented left-edge clipping and horizontal page overflow.
- Kept wide data tables inside horizontal scroll containers.
- Improved card, title, action, metric, and account-card spacing on phones.
- No authentication, account, application, balance, transfer, card, or banking logic was changed.
