# J.P. Morgan Step 5 — Controlled Transaction Certification

This step adds a locked, one-time payment certification workflow. It can submit a provider payment only after the signed-in operator enters the exact authorization phrase. The destination is never sent to the browser.

## Before enabling

1. Run `supabase/SONORAPORT-JPMORGAN-STEP5-CERTIFICATION.sql` in the Supabase SQL Editor.
2. Confirm Steps 1–4 pass on the deployed site.
3. Add these Netlify environment variables using values issued/approved for the same provider environment:

- `JPMORGAN_ENABLE_CONTROLLED_TEST_PAYMENT=true`
- `JPMORGAN_CERTIFICATION_DESTINATION_ID=<approved destination identifier>`
- `JPMORGAN_CERTIFICATION_AMOUNT=<smallest permitted amount>`
- `JPMORGAN_CERTIFICATION_CURRENCY=USD`
- `JPMORGAN_CERTIFICATION_PAYMENT_METHOD=ACH`
- `JPMORGAN_CERTIFICATION_MAX_AMOUNT=1.00` (or another deliberately low server cap)
- `JPMORGAN_CERTIFICATION_RUN_ID=<new random one-time label>`

Callbacks must also be enabled and verified from Step 4.

## Safety behavior

- Requires a valid Supabase user session.
- Destination remains server-side.
- Exact authorization phrase is required.
- Amount cannot exceed the server-side certification cap.
- A deterministic idempotency key prevents the same run from being submitted twice.
- Provider response and verified callback status are saved separately.
- Change `JPMORGAN_CERTIFICATION_RUN_ID` only when intentionally authorizing a new certification run.
- Set `JPMORGAN_ENABLE_CONTROLLED_TEST_PAYMENT=false` immediately after the test.
