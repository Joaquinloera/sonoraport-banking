# BUILD 041 — CARD API ROUTER SWARM

- Parent: Build 040
- Customer Card Center now consumes stable `/api/cards/*` aliases for issuance, activation, and control.
- Netlify aliases continue routing server-side to the existing authenticated card functions.
- Provider fail-closed behavior is unchanged.
- No provider responses, PANs, CVVs, balances, or settlement results are synthesized.
