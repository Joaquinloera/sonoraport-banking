# BUILD 055 — Browser API Boundary

- Removed direct `/.netlify/functions/*` implementation URLs from active browser banking assets.
- Added stable `/api/function/:name` boundary before the site catch-all.
- Preserved existing function names, authentication headers, methods, payloads, and fail-closed provider behavior.
- Synchronized authenticated release cache references to Build 055.
- No provider credentials, balances, settlement results, card numbers, or issuer responses were synthesized.
