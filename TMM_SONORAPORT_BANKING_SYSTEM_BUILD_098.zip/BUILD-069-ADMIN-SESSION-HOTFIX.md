# Build 069 — Admin Session Persistence Hotfix

Parent: BUILD 068

## Fixes
- Preserves the explicit fresh admin sign-in requirement without globally destroying the browser session before the admin login form can complete.
- Admin reauthentication now signs out the local browser session immediately before the submitted credential exchange, then persists the newly authenticated session.
- Admin authorization boot uses `supabase.auth.getUser()` to verify the authenticated user against Supabase Auth before evaluating the operations role.
- Admin role lookup errors are distinguished from legitimate unauthorized-role results.
- Admin entry routes consistently target `/admin-portal.html`.
- Browser code still cannot promote a customer to an operations role.

## Authorized roles
`owner`, `admin`, `staff`, `reviewer`.

If a valid admin login remains denied after this hotfix, the production `profiles.role` row for that authenticated user must be assigned one of the authorized roles by an authorized database administrator. Build 069 does not create a browser-side authorization bypass.

## Regression note
The BUILD 068 customer-portal surface test still asserted the pre-routing direct Netlify function URL. The live portal had already moved to the stable `/api/cards/issuance` boundary through `netlify.toml`. BUILD 069 updates the stale assertion only; issuance implementation is unchanged.
