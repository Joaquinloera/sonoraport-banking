# BUILD 074 — Card lifecycle schema alignment

- Preserves BUILD 073 Black/Business card contrast improvements.
- Aligns customer card issuance with the connected Supabase authority: `bank_accounts`, `debit_cards`, `credit_cards`, and `card_issuance_requests`.
- Removes runtime dependency from the card lifecycle on legacy generic `accounts` / `cards` records.
- Activation, lock/unlock, and status synchronization resolve ownership by `user_id` and use provider-backed `external_card_id` only.
- Provider PAN/CVV is never generated or stored. Last-four is accepted only from the authenticated issuer response.
- Portal Card Center combines debit + credit records into one customer view and maps `is_locked`, `last_four`, and `linked_account_id` to the existing UI.
- Provider authentication and production cutover gates remain intact; this build does not claim a provider is live without provider evidence.
