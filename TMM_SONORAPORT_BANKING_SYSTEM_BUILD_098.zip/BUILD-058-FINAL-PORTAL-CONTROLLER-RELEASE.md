# Build 058 — Final Portal Controller Release

- Consolidated customer tab activation so the inline delegated controller is authoritative.
- Removed duplicate per-tab onclick binding from live-portal.js.
- Synchronized active state, aria-selected, roving tabindex, hidden state, and panel class in fallback activation.
- Removed stale mobile grid navigation declarations from customer-main-theme.css; compact horizontal rail is now consistent across customer stylesheets.
- Bumped authenticated release assets to v58.
- Final regression covers 13/13 customer panels, quick actions, duplicate IDs, local assets, browser API routes, JS/MJS syntax, and ZIP integrity.
