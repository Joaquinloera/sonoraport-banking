SONORAPORT J.P. MORGAN STATUS FIX

What was wrong:
The prior jpmorgan-status function marked products false only because optional
JPMORGAN_*_PATH variables were absent. It did not test the API.

What this build changes:
- Uses Embedded Payments default paths when custom path variables are absent.
- Shows embeddedPayments, balances, and payments as code-ready when the core
  J.P. Morgan integration is enabled.
- Keeps mTLS and Configuration ID truthful; they become true only when their
  actual Netlify variables are present.
- Adds a real token verification mode:
  /.netlify/functions/jpmorgan-status?verify=token

Meaning of results:
- products.* = deployed code readiness
- security.* = required security values present
- provider.token = actual token request succeeded when verification is requested
