# Build 077 — Card lifecycle request hardening

Parent: Build 076.

- Fixes the browser in-flight guard for Lock/Unlock so repeated taps cannot launch parallel requests for the same card.
- Adds authenticated, ownership-checked `/api/cards/lifecycle-request` for Replace and Close requests.
- Replace/Close only record pending lifecycle state; they do not synthesize provider completion.
- Customer Card Center displays replacement/closure pending state and suppresses conflicting lifecycle actions.
- Existing issuer activation, controls, status sync, webhooks, reconciliation, and production cutover protections remain intact.
