# BUILD 078 — Server-side card lifecycle race protection

Parent: BUILD 077.

- Reject conflicting Replace/Close requests when a card has pending lifecycle timestamps or pending/terminal lifecycle status.
- Apply ownership-scoped compare-and-set on lifecycle_status in the database to prevent simultaneous requests from both being accepted.
- Return HTTP 409 with CARD_LIFECYCLE_STALE if the card changed between read and write; customer should refresh status.
- Preserve pending-only lifecycle semantics. No external issuer replacement/closure completion is claimed.
- Preserve previous card visual fixes, frontend guards, activation, status sync and production cutover lock.
