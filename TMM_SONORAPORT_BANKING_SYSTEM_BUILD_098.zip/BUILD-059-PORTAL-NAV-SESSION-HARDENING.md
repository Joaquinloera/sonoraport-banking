# Build 059 — Portal Navigation & Session Hardening

- Customer tab selection now hides the Overview quick-action rail outside Overview and scrolls the selected panel into view.
- Panel state remains synchronized across active class, hidden state, ARIA selection, and keyboard tabindex.
- Explicit Sign Out now requests global Supabase sign-out, clears portal redirect state, and uses location.replace to prevent returning to the authenticated page via browser Back.
- Public Client Portal links now require a fresh authentication step (`reauth=1`) instead of silently reusing a persisted browser session.
- Authenticated/recovery asset cache tokens advanced to Build 059.
