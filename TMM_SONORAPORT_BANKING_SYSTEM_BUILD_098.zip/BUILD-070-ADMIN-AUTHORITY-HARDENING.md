# Build 070 — Admin Authority Hardening

Parent: BUILD 069

- Moves the decisive admin role lookup to a server-side Netlify function.
- Validates the submitted Supabase access token against Supabase Auth.
- Reads the production profile with the server-only service role; the key is never exposed to the browser.
- Keeps authorized roles limited to owner, admin, staff, reviewer.
- Returns distinct diagnostics for expired auth, missing profile, missing role, and server configuration/lookup failures.
- Does not create or promote administrator roles from the browser.
- Existing production cutover and card issuer readiness gates remain intact.
