SONORAPORT V14 — TRANSACTIONS & BALANCE MOVEMENT

Added:
- Sandbox test deposits and withdrawals
- Balance validation
- Running balance display
- Account names in transaction history
- Immediate internal transfers remain supported
- Notifications after sandbox activity

Before deploying the final consolidated build, run:
supabase/SONORAPORT-V14-TRANSACTIONS-PATCH.sql

This is a sandbox ledger only. It does not move real money.
