# Step 15 — Refunds, Reversals, and Returned Payments

This step adds controlled customer refund requests and an administrator workflow for review, approval, provider submission, completion, rejection, or failure.

## Install

1. Run `supabase/SONORAPORT-JPMORGAN-STEP15-REFUNDS-RETURNS.sql` after Step 14.
2. Add `JPMORGAN_REFUND_ADMIN_EMAILS` in Netlify as a comma-separated list of authorized administrators.
3. Deploy the package only after the SQL succeeds.

## Endpoints

- `GET|POST /.netlify/functions/jpmorgan-refunds`
- `GET|PATCH /.netlify/functions/jpmorgan-refund-admin`

## Important

The administrator endpoint records provider request IDs and statuses but does not invent a provider reversal endpoint. The actual JPMorgan refund/reversal call must use the endpoint and payload assigned to the enabled product. A completed provider result posts a balanced refund journal exactly once.
