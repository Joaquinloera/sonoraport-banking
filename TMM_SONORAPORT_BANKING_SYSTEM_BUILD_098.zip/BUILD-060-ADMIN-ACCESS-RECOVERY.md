# Build 060 — Admin Access Recovery

- Preserves server/database-backed operations-role enforcement.
- Replaces the low-contrast denial state with a clear Admin Command Center access screen.
- Adds a dedicated `/admin/login.html` entry point requiring fresh admin authentication.
- Keeps `/admin/index.html` as the secure command-center route.
- Customer sessions are not promoted from browser code.
- Admin sign-out now requests global sign-out and replacement redirect.
- Authenticated release cache advanced to v60.
