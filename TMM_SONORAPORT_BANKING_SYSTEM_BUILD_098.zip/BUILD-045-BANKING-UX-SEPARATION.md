# BUILD 045 — Banking UX Separation

- Removed payment/network/accreditation brand rail from authenticated customer portal.
- Kept public-facing brand presentation on the main/public banking pages.
- Removed unrelated swarm/hive presentation from Admin Command Center.
- Admin remains operations-focused: applications, customers, accounts, cards, transfers, messages, audit, provider health, payments, security.
- Customer portal remains task-focused: accounts, activity, money movement, cards, applications, statements, alerts/messages, disputes, beneficiaries, profile and security.
- Cache versions advanced to 45 for edited authenticated surfaces.

UX basis: current major-bank digital banking patterns prioritize account summary, recent activity, payments/transfers, cards, statements, alerts, security, and self-service; operational/provider tooling is separated from customer banking.
