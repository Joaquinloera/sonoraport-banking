# BUILD 038 — FOUR HORSEMEN SERVER + ROUTER SWARM

Parent: Build 037

- WHITE HORSE: audited Netlify redirects, 42 serverless functions, portal function calls, and card router.
- RED HORSE: added clean admin routes and stable `/api/cards/*` aliases ahead of the 404 catch-all.
- BLACK HORSE: unified single-issuer readiness with the same priority/failover router used by card issuance, eliminating configuration drift between readiness and issuance.
- PALE HORSE: syntax validation, function-call inventory, route ordering, ZIP integrity and SHA-256 release gate.

No provider success, card identifiers, PANs, CVVs, balances, or settlement results are synthesized by this build.
