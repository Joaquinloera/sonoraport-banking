# JPMorgan Step 16 — Beneficiary and Payee Controls

This release prevents payments from being submitted to arbitrary browser-supplied destination IDs.

## Install
1. Run `supabase/SONORAPORT-JPMORGAN-STEP16-BENEFICIARY-CONTROLS.sql`.
2. Add Netlify variables:
   - `JPMORGAN_BENEFICIARY_ADMIN_EMAILS=authorized@email.com`
   - `JPMORGAN_BENEFICIARY_COOLING_OFF_HOURS=24`
   - `JPMORGAN_BLOCKED_BENEFICIARY_COUNTRIES=`
3. Redeploy after all prior step migrations are installed.

## Endpoints
- `GET|POST /.netlify/functions/jpmorgan-beneficiaries`
- `GET|PATCH /.netlify/functions/jpmorgan-beneficiary-admin`

## Payment API change
`jpmorgan-create-payment` now requires `beneficiaryId` rather than accepting an arbitrary `destinationId`. Only an active beneficiary owned by the signed-in customer and matching the payment currency is accepted.
