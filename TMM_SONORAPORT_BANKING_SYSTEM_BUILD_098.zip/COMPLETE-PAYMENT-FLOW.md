# SonoraPort J.P. Morgan Complete Payment Flow

This build wires the existing controls into one consistent flow:

1. OAuth provider verification
2. Online Payments product configuration verification
3. Payment readiness validation
4. Callback HMAC self-test and verified callback handler
5. Customer onboarding gate
6. Beneficiary enrollment, approval, cooling-off, and active-beneficiary selection
7. Linked provider account ownership check
8. Available-balance reservation and overdraft prevention
9. Risk review and dual-approval holds
10. Idempotent payment submission
11. Provider callback settlement or failure release
12. Certification payment, status refresh, and reconciliation
13. Production cutover and operations health gates
14. Audit logging and incident monitoring

## Required Netlify configuration

Provider and product:
- ENABLE_JPMORGAN=true
- JPMORGAN_PRODUCT_MODE=online_payments
- JPMORGAN_ENVIRONMENT=<provider-issued environment>
- JPMORGAN_CLIENT_ID=<provider-issued value>
- JPMORGAN_CLIENT_SECRET=<provider-issued secret>
- JPMORGAN_TOKEN_URL=<provider-issued URL>
- JPMORGAN_SCOPE=<provider-issued scope>
- JPMORGAN_API_BASE_URL=<provider-issued API origin>
- JPMORGAN_CREATE_PAYMENT_PATH=<provider-issued payment path>
- JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE=<path containing {paymentId}>
- JPMORGAN_MERCHANT_ID=<provider-issued value when required>

Callbacks:
- ENABLE_JPMORGAN_CALLBACKS=true
- JPMORGAN_CALLBACK_VERIFICATION_MODE=hmac-sha256
- JPMORGAN_CALLBACK_HMAC_SECRET=<provider-issued or mutually configured secret>

Operations:
- JPMORGAN_PAYMENT_OPERATIONS_ENABLED=true
- JPMORGAN_PRODUCTION_CUTOVER_APPROVED=true when your internal cutover is approved
- JPMORGAN_EMERGENCY_STOP=false

Certification:
- JPMORGAN_ENABLE_CONTROLLED_TEST_PAYMENT=true
- JPMORGAN_CERTIFICATION_AMOUNT=<small approved amount>
- JPMORGAN_CERTIFICATION_MAX_AMOUNT=<hard maximum>
- JPMORGAN_CERTIFICATION_CURRENCY=USD
- JPMORGAN_CERTIFICATION_PAYMENT_METHOD=<enabled rail>
- JPMORGAN_CERTIFICATION_DESTINATION_ID=<approved provider destination>
- JPMORGAN_CERTIFICATION_RUN_ID=<unique one-time run ID>

The software cannot generate provider credentials, activate payment rails, approve beneficiaries, or create provider account identifiers. Those values and approvals must match the provider-side configuration.
