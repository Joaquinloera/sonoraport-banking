SONORAPORT V12 COMPLETE PLATFORM

This package combines the public website, customer portal, operations portal, application workflow, sandbox accounts, transaction ledger, internal transfers, card requests, statements, notifications, and admin review tools.

IMPORTANT
- Do not upload until the included SQL has been run successfully in Supabase.
- The platform is a sandbox workflow and internal ledger. It does not connect to banking rails, move real money, issue real payment cards, or provide regulatory approval.

SETUP
1. Open Supabase SQL Editor.
2. Run supabase/SONORAPORT-V12-COMPLETE-PLATFORM.sql.
3. In the last commented line, replace YOUR-EMAIL-HERE with the email of the account that should access admin-portal.html, remove the comment marks, and run that one update statement.
4. Test sign-in, client-portal.html, and admin-portal.html.
5. Upload this single ZIP to Netlify only after testing.

CUSTOMER FEATURES
- Applications and decisions
- Approved account creation
- Balances and transaction history
- Atomic internal sandbox transfers
- Card requests and lock/unlock controls
- Statements, CSV export, notifications

ADMIN FEATURES
- Customer directory
- Review/approve/decline applications
- Automatic sandbox account creation after approval
- Sandbox card issuance
- Accounts, cards, and transfer views
