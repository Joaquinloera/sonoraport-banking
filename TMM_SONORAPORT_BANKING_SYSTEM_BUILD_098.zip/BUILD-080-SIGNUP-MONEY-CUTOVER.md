# BUILD 080 — Signup + Current Money Cutover

- Fixes admin authority mismatch: the live `executive` profile role is now accepted by the server-side admin authority gate.
- Customer product applications use `/api/applications` and `bank_account_applications`, not retired `applications` RPCs.
- Customer portal reads current `bank_accounts`, `debit_cards`, `credit_cards`, `transactions`, `transfer_requests`, `debit_card_authorizations`, and current secure messages.
- Internal transfers call the installed current-schema `internal_transfer` RPC.
- Admin dashboard data comes through an authenticated server-side endpoint and current banking tables.
- Admin account-application decisions call installed `sp_review_account_application`, preserving provider readiness requirements before provider-backed account approval.
- Removes the broken notification/card guard cross-reference.
- No legacy balances are copied or manufactured. Provider-backed money remains authoritative.
- Live Supabase inspection confirmed current money functions already installed, including USD funding and debit authorization/capture/reversal flows; no replacement legacy money migration is included.
