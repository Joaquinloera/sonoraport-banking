import fs from 'node:fs';
import assert from 'node:assert/strict';
const js=fs.readFileSync(new URL('../portal-assets/live-portal.js', import.meta.url),'utf8');
assert.equal(js.includes('post_sandbox_activity'), false, 'sandbox activity RPC must not exist in customer portal');
assert.equal(js.includes('Deposit / Withdraw'), false, 'sandbox deposit/withdraw controls must not be customer-facing');
assert.equal(js.includes("$('#activityForm')"), false, 'removed activity form must not be dereferenced');
assert.equal(js.includes("/api/cards/issuance"), true, 'provider card issuance boundary must remain wired');
console.log('CUSTOMER_PORTAL_PRODUCTION_SURFACE::PASS');
