import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
const lib=read('netlify/functions/lib/admin-authority.mjs');
for(const role of ['owner','admin','staff','reviewer']) if(!lib.includes(`'${role}'`)) throw new Error('missing role '+role);
if(!lib.includes('SUPABASE_SERVICE_ROLE_KEY')) throw new Error('server role lookup missing');
for(const f of ['admin-session-status.mjs','production-cutover-summary.mjs','card-issuer-readiness.mjs','card-issuer-router-readiness.mjs']){
 const s=read('netlify/functions/'+f); if(!s.includes('requireAdminAuthority')) throw new Error(f+' does not use canonical admin authority');
}
const note=read('BUILD-071-AUTHORITY-AND-EVIDENCE-PROVENANCE.md');
if(!note.includes('not converted into live balances')) throw new Error('provenance guard missing');
console.log('BUILD071_AUTHORITY_PROVENANCE_PASS');
