import crypto from 'node:crypto';
import { getBearer, getSupabaseUser, json, methodNotAllowed, requestId, serverError, unauthorized } from './lib/shared.mjs';
import { appendAuditEvent } from './lib/audit-log.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

function monthRange(value) {
  const match = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(String(value || ''));
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  return { label: `${match[1]}-${match[2]}`, start: new Date(Date.UTC(year, month - 1, 1)).toISOString(), end: new Date(Date.UTC(year, month, 1)).toISOString() };
}

async function loadRows(range) {
  const base = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!base || !key) throw Object.assign(new Error('Reconciliation database configuration is missing.'), { status: 503, code: 'RECON_DATABASE_MISSING' });
  const select = 'id,profile_id,amount,currency,status,provider_status,provider_payment_id,created_at,settled_at,released_at';
  const url = `${base}/rest/v1/payment_reservations?select=${encodeURIComponent(select)}&created_at=gte.${encodeURIComponent(range.start)}&created_at=lt.${encodeURIComponent(range.end)}&order=created_at.asc`;
  const response = await fetch(url, { headers: { Authorization: `Bearer ${key}`, apikey: key, Accept: 'application/json' } });
  const rows = await response.json().catch(() => null);
  if (!response.ok) throw Object.assign(new Error(rows?.message || 'Unable to build reconciliation report.'), { status: response.status, code: 'RECON_QUERY_FAILED' });
  return { rows: Array.isArray(rows) ? rows : [], base, key };
}

function classify(rows) {
  const report = { totalTransactions: rows.length, totalSettled: 0, totalFailed: 0, totalHeld: 0, mismatchCount: 0, mismatches: [] };
  const finalProvider = new Set(['completed','complete','settled','paid','succeeded','success']);
  for (const row of rows) {
    const amount = Number(row.amount || 0);
    if (row.status === 'settled') report.totalSettled += amount;
    else if (['failed','released'].includes(row.status)) report.totalFailed += amount;
    else report.totalHeld += amount;
    const providerStatus = String(row.provider_status || '').toLowerCase();
    const mismatch = (row.status === 'settled' && providerStatus && !finalProvider.has(providerStatus)) || (row.status === 'settled' && !row.provider_payment_id);
    if (mismatch) {
      report.mismatchCount += 1;
      report.mismatches.push({ paymentId: row.id, status: row.status, providerStatus: row.provider_status || null, missingProviderId: !row.provider_payment_id });
    }
  }
  return report;
}

async function saveReport({ range, report, userId, correlationId, base, key, hash }) {
  await fetch(`${base}/rest/v1/reconciliation_reports`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, apikey: key, 'content-type': 'application/json', Prefer: 'resolution=ignore-duplicates' },
    body: JSON.stringify({ report_month: `${range.label}-01`, generated_by: userId, total_transactions: report.totalTransactions, total_settled: report.totalSettled, total_failed: report.totalFailed, total_held: report.totalHeld, mismatch_count: report.mismatchCount, report_hash: hash, correlation_id: correlationId }),
  });
}

export async function handler(event) {
  const correlationId = requestId(event);
  if (event.httpMethod !== 'GET') return methodNotAllowed(['GET']);
  try {
    const user = await getSupabaseUser(getBearer(event));
    if (!user) return unauthorized('Sign in to generate a reconciliation report.', 'AUTH_REQUIRED', correlationId);
    await requireAdminAuthority(user);
    const now = new Date();
    const defaultMonth = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
    const range = monthRange(event.queryStringParameters?.month || defaultMonth);
    if (!range) return json(400, { error: 'Month must use YYYY-MM format.', code: 'INVALID_RECON_MONTH', correlationId });
    const { rows, base, key } = await loadRows(range);
    const report = classify(rows);
    const hash = crypto.createHash('sha256').update(JSON.stringify({ month: range.label, report, rows })).digest('hex');
    await saveReport({ range, report, userId: user.id, correlationId, base, key, hash });
    await appendAuditEvent({ correlationId, actorUserId: user.id, action: 'reconciliation.report_generated', outcome: report.mismatchCount ? 'mismatches_detected' : 'balanced', resourceId: range.label, details: { reportHash: hash, ...report, mismatches: undefined } });
    return json(200, { month: range.label, reportHash: hash, generatedAt: new Date().toISOString(), ...report, correlationId }, { 'cache-control': 'no-store' });
  } catch (error) {
    return serverError(error, correlationId);
  }
}
