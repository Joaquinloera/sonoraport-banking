# BUILD 092 — Configuration Contract Compatibility

Parent: BUILD 091

- Preserves BUILD 089 certification/reconciliation schema work.
- Preserves BUILD 090 Admin refresh behavior.
- Preserves BUILD 091 ordered gate execution and automatic Admin refresh.
- Fixes Admin capability cards so `Configured` means the local capability wiring is present, independently of whether provider authentication has succeeded.
- Bank Payments configuration is derived from the existing API base + payment path + scope contract.
- Balances capability recognizes the existing provider API plus an account/balance/payment capability path, rather than incorrectly coupling the card to the global provider-enabled flag.
- Provider Auth, Account Access, Payment Readiness, Cutover, and Operations remain live verification gates; this build does not manufacture successful provider responses.
