-- BUILD 108
-- Prepared but intentionally NOT auto-applied.
-- Existing grants observed: postgres + service_role only.
-- Enabling RLS preserves service-role backend access while adding defense-in-depth.
ALTER TABLE public.provider_evidence_source_quality_receipts ENABLE ROW LEVEL SECURITY;
