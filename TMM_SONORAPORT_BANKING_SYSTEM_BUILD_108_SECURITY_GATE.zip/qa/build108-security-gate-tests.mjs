import fs from 'node:fs';
const p='supabase/BUILD-108-PROVIDER-EVIDENCE-RLS-HARDENING.sql';
const s=fs.readFileSync(p,'utf8');
if(!s.includes('ENABLE ROW LEVEL SECURITY')) throw new Error('RLS hardening statement missing');
if(/CREATE POLICY/i.test(s)) throw new Error('BUILD 108 must not invent client access policies');
console.log('BUILD_108_SECURITY_GATE::PASS');
