import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const fn=read('netlify/functions/production-cutover-summary.mjs');
const toml=read('netlify.toml');
const html=read('admin-portal.html');
const js=read('portal-assets/admin-portal.js');
const checks=[
 ['admin auth',fn.includes('getSupabaseUser')&&fn.includes('CUTOVER_ADMIN_REQUIRED')],
 ['production environment',fn.includes("['production','prod','live']")],
 ['payment provider gates',fn.includes('JPMORGAN_PRODUCTION_CUTOVER_APPROVED')&&fn.includes('JPMORGAN_CALLBACK_HMAC_SECRET')],
 ['database gates',fn.includes('SUPABASE_SERVICE_ROLE_KEY')&&fn.includes('SUPABASE_ANON_KEY')],
 ['card issuer gates',fn.includes('CARD_ISSUER_WEBHOOK_SECRET')&&fn.includes('MASTERCARD_CREDIT')&&fn.includes('VISA_CREDIT')&&fn.includes('VISA_DEBIT')],
 ['stable cutover route',toml.includes('/api/admin/production-cutover')&&toml.includes('production-cutover-summary')],
 ['admin UI control',html.includes('checkProductionCutover')&&html.includes('productionCutoverOutput')],
 ['admin UI API call',js.includes("fetch('/api/admin/production-cutover'")],
 ['existing admin reauth',toml.includes('from = "/admin"')&&fs.existsSync('admin/login.html')],
 ['card lifecycle continuity',[29,30,31,32].every(n=>fs.existsSync(`supabase/SONORAPORT-V${n}-${({29:'VISA-DEBIT-FUNDED-LIFECYCLE',30:'VISA-DEBIT-SETTLEMENT-RECONCILIATION',31:'VISA-CREDIT-LIFECYCLE',32:'MASTERCARD-CREDIT-LIFECYCLE'})[n]}.sql`))]
];
const failed=checks.filter(([,ok])=>!ok);if(failed.length){console.error(failed);process.exit(1)}console.log('BUILD_068_PRODUCTION_CLOSEOUT_CONTRACT::PASS');
