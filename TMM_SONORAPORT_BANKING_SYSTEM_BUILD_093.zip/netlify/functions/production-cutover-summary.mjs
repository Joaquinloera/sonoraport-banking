import { getBearer, getSupabaseUser, json, methodNotAllowed, requestId, unauthorized, serverError } from './lib/shared.mjs';
import { envValue } from './lib/jpmorgan.mjs';
import { configuredIssuers, issuerConfigurationState } from './lib/card-issuer-router.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';

const yes=v=>String(v||'').trim().toLowerCase()==='true';
const has=n=>Boolean(String(envValue(n)||process.env[n]||'').trim());

export async function handler(event){
  const correlationId=requestId(event);
  if(event.httpMethod!=='GET') return methodNotAllowed(['GET']);
  try{
    const user=await getSupabaseUser(getBearer(event));
    if(!user) return unauthorized('Administrator authentication required.','AUTH_REQUIRED',correlationId);
    await requireAdminAuthority(user);

    const environment=String(envValue('JPMORGAN_ENVIRONMENT')||'').trim().toLowerCase();
    const paymentChecks={
      providerEnabled:yes(envValue('ENABLE_JPMORGAN')),
      productionEnvironment:['production','prod','live'].includes(environment),
      cutoverApproved:yes(envValue('JPMORGAN_PRODUCTION_CUTOVER_APPROVED')),
      credentialsConfigured:has('JPMORGAN_CLIENT_ID')&&has('JPMORGAN_CLIENT_SECRET'),
      tokenEndpointConfigured:has('JPMORGAN_TOKEN_URL')||has('JPM_TOKEN_URL')||(has('JPMORGAN_API_BASE_URL')&&has('JPMORGAN_TOKEN_PATH')),
      apiBaseConfigured:has('JPMORGAN_API_BASE_URL'),
      paymentPathConfigured:has('JPMORGAN_CREATE_PAYMENT_PATH'),
      callbackSecurityConfigured:yes(envValue('ENABLE_JPMORGAN_CALLBACKS'))&&has('JPMORGAN_CALLBACK_VERIFICATION_MODE')&&has('JPMORGAN_CALLBACK_HMAC_SECRET'),
      transactionStatusConfigured:has('JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE')
    };

    const issuers=configuredIssuers().map(i=>{const state=issuerConfigurationState(i);return {issuer:i.name,enabled:i.enabled,configured:state.configured,missing:state.missing,products:i.products};});
    const productCoverage={VISA_DEBIT:false,VISA_CREDIT:false,MASTERCARD_CREDIT:false};
    for(const issuer of issuers.filter(x=>x.configured)) for(const p of issuer.products) if(p in productCoverage) productCoverage[p]=true;
    const cardChecks={
      webhookSecretConfigured:has('CARD_ISSUER_WEBHOOK_SECRET'),
      configuredIssuerAvailable:issuers.some(x=>x.configured),
      visaDebitIssuerConfigured:productCoverage.VISA_DEBIT,
      visaCreditIssuerConfigured:productCoverage.VISA_CREDIT,
      mastercardCreditIssuerConfigured:productCoverage.MASTERCARD_CREDIT
    };
    const databaseChecks={
      supabaseUrlConfigured:has('SUPABASE_URL'),
      supabaseAnonKeyConfigured:has('SUPABASE_ANON_KEY'),
      supabaseServiceRoleConfigured:has('SUPABASE_SERVICE_ROLE_KEY')
    };
    const checks={...databaseChecks,...paymentChecks,...cardChecks};
    const blockers=Object.entries(checks).filter(([,v])=>!v).map(([k])=>k);
    return json(200,{
      readyForControlledProductionVerification:blockers.length===0,
      environment:environment||'not_configured',
      checks,blockers,issuers,
      note:blockers.length?'Configuration gates remain before controlled production verification.':'Configuration gates are present. Provider authentication, webhook registration, database migrations, and controlled transaction reconciliation must still be verified against deployed production services.',
      correlationId
    });
  }catch(e){return serverError(e,correlationId)}
}
