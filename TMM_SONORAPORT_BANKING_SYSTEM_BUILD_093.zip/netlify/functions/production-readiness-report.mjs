import { getBearer, getSupabaseUser, json, methodNotAllowed, requestId, unauthorized, serverError } from './lib/shared.mjs';
import { requireAdminAuthority } from './lib/admin-authority.mjs';
import { configuredIssuers, issuerConfigurationState, authenticateIssuer } from './lib/card-issuer-router.mjs';

const has=n=>Boolean(String(process.env[n]||'').trim());
const yes=n=>String(process.env[n]||'').trim().toLowerCase()==='true';
const productSet=issuers=>new Set(issuers.filter(x=>x.configuration.configured).flatMap(x=>x.products));

export async function handler(event){
  const correlationId=requestId(event);
  if(event.httpMethod!=='GET') return methodNotAllowed(['GET']);
  try{
    const user=await getSupabaseUser(getBearer(event));
    if(!user) return unauthorized('Administrator authentication required.','AUTH_REQUIRED',correlationId);
    const authority=await requireAdminAuthority(user);

    const issuers=[];
    for(const issuer of configuredIssuers()){
      const configuration=issuerConfigurationState(issuer);
      let authentication={ok:false,reason:configuration.configured?'not_checked':'not_configured'};
      if(configuration.configured) authentication=await authenticateIssuer(issuer);
      issuers.push({issuer:issuer.name,products:issuer.products,configuration,authentication:{ok:Boolean(authentication.ok),reason:authentication.ok?'pass':authentication.reason}});
    }
    const products=productSet(issuers);
    const checks={
      adminAuthorityVerified:true,
      supabaseConfigured:has('SUPABASE_URL')&&has('SUPABASE_ANON_KEY')&&has('SUPABASE_SERVICE_ROLE_KEY'),
      issuerConfigured:issuers.some(x=>x.configuration.configured),
      issuerAuthenticated:issuers.some(x=>x.authentication.ok),
      visaDebitCoverage:products.has('VISA_DEBIT'),
      visaCreditCoverage:products.has('VISA_CREDIT'),
      mastercardCreditCoverage:products.has('MASTERCARD_CREDIT'),
      issuerWebhookSecretConfigured:has('CARD_ISSUER_WEBHOOK_SECRET'),
      paymentProviderEnabled:yes('ENABLE_JPMORGAN'),
      productionCutoverApproved:yes('JPMORGAN_PRODUCTION_CUTOVER_APPROVED'),
      paymentWebhookVerificationConfigured:yes('ENABLE_JPMORGAN_CALLBACKS')&&has('JPMORGAN_CALLBACK_VERIFICATION_MODE')&&has('JPMORGAN_CALLBACK_HMAC_SECRET')
    };
    const blockers=Object.entries(checks).filter(([,ok])=>!ok).map(([name])=>name);
    return json(200,{
      readyForControlledIssuanceVerification:blockers.length===0,
      checks,blockers,issuers,
      evidencePolicy:{documentsMayDescribeRelationships:true,documentsDoNotEstablishLiveBalancesOrSettlement:true,liveStateRequiresProviderOrReconciliationEvidence:true},
      authority:{verified:true,role:authority?.role||authority?.profile?.role||'authorized'},
      correlationId
    });
  }catch(e){return serverError(e,correlationId);}
}
