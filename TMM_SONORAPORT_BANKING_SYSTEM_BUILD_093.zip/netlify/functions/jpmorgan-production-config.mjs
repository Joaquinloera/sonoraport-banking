import { ok } from './lib/shared.mjs';
import { envValue, normalizedApiOrigin } from './lib/jpmorgan.mjs';

const has = (name) => Boolean(envValue(name));
const isTrue = (value) => String(value || '').toLowerCase() === 'true';

export async function handler() {
  const authMode = String(envValue('JPMORGAN_AUTH_MODE') || 'client_secret').toLowerCase();
  const environment = String(envValue('JPMORGAN_ENVIRONMENT') || '').toLowerCase();
  const production = /production|prod|live/.test(environment);
  const checks = {
    productionEnvironmentSelected: production,
    clientIdConfigured: has('JPMORGAN_CLIENT_ID'),
    tokenUrlConfigured: has('JPMORGAN_TOKEN_URL'),
    apiOriginConfigured: Boolean(normalizedApiOrigin()),
    scopeConfigured: has('JPMORGAN_SCOPE'),
    merchantOrConfigurationIdConfigured: has('JPMORGAN_MERCHANT_ID') || has('JPMORGAN_CONFIGURATION_ID'),
    callbackUrlConfigured: has('JPMORGAN_CALLBACK_URL'),
    callbackVerificationConfigured: isTrue(envValue('ENABLE_JPMORGAN_CALLBACKS')) && (
      has('JPMORGAN_CALLBACK_HMAC_SECRET') || has('JPMORGAN_CALLBACK_PUBLIC_KEY') || has('JPMORGAN_CALLBACK_CERTIFICATE')
    ),
    paymentPathConfigured: has('JPMORGAN_CREATE_PAYMENT_PATH'),
    transactionStatusPathConfigured: has('JPMORGAN_TRANSACTION_STATUS_PATH_TEMPLATE'),
    operationsLockedForHandoff: !isTrue(envValue('JPMORGAN_PAYMENT_OPERATIONS_ENABLED')),
    emergencyStopInactive: !isTrue(envValue('JPMORGAN_EMERGENCY_STOP')),
  };

  if (authMode.includes('client_secret')) checks.clientSecretConfigured = has('JPMORGAN_CLIENT_SECRET');
  if (authMode.includes('private_key_jwt')) {
    checks.jwtAudienceConfigured = has('JPMORGAN_AUDIENCE');
    checks.jwtKeyIdConfigured = has('JPMORGAN_JWT_KEY_ID');
    checks.jwtPrivateKeyConfigured = has('JPMORGAN_JWT_PRIVATE_KEY');
  }
  if (authMode.includes('mtls')) {
    checks.mtlsCertificateConfigured = has('JPMORGAN_MTLS_CERT');
    checks.mtlsPrivateKeyConfigured = has('JPMORGAN_MTLS_KEY');
  }

  const missing = Object.entries(checks).filter(([, value]) => !value).map(([name]) => name);
  return ok({
    authMode,
    environment: environment || 'not configured',
    readyForProviderHandoff: missing.length === 0,
    checks,
    missing,
    note: 'This endpoint checks configuration presence only. Provider activation and live authorization remain controlled by J.P. Morgan.',
  });
}
